sap.ui.define("sap/ui/ce/generic/Dashboard", [],
    function () {
        "use strict";
        var Dashboard = {
            showCEODB:function (view) {
                view.pg.removeAllContents();

            }

        };


        return Dashboard;
    });