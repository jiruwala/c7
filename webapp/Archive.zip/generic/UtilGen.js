sap.ui.define("sap/ui/ce/generic/UtilGen", [],
    function () {
        "use strict";
        var UtilGen = {
            chartHtmlText: '  <style type="text/css"> ' +
                '#chart-container { ' +
                'position: absolute; ' +
                'top: 10%; ' +
                'padding-left: 20vw;!important;' +
                //            'left:20%; ' +
                'height: auto; ' +
                'transform: translate(-50%, -50%)' +
                //        'width: calc(100% - 80px); ' +
                'z-index: 1; ' +
                'border-color: rgba(217, 83, 79, 0.9); ' +
                '}' +
                '.orgchart {' +
                'background: rgba(255,255,255,0.75);' +
                '}' +
                '@media screen and (max-width: 400px) { ' +
                ' #chart-container {' +
                'padding-left: 20px;' +
                '}' +
                '</style>' +
                ' <div id="chart-container"></div>'
            ,
            ajaxPre: "",
            createToolbar: function () {
                var that = this;
                var menuBar = new sap.m.Bar({
                    contentLeft: [new sap.m.Button({
                        icon: "sap-icon://home",
                        text: "",
                        press: function () {
                            document.location.href = "/?clearCookies=true";
                        }
                    }),
                    new sap.m.Button({
                        icon: "sap-icon://product",
                        text: "",
                        press: function () {
                            that.showApps();
                        }

                    }),
                    ],
                    contentMiddle: [new sap.m.Label({
                        text: "{selectedP>/name}",
                        textAlign: "Center",
                        design: "Bold"
                    })],

                    contentRight: [new sap.m.Button({
                        icon: "sap-icon://drop-down-list",
                        tooltip: "Select another role !",
                        press: function (e) {
                            oController.select_profile(e);
                        }
                    })
                    ]

                });
                menuBar.addStyleClass("sapContrast sapMIBar");
                return menuBar;
            },
            nvl: function (val1, val2) {
                return ((val1 == null || val1 == undefined || val1.length == 0) ? val2 : val1);
            },
            nvlObjToStr: function (val1, val2) {
                return ((val1 == null || val1 == undefined || val1.length == 0) ? val2 + "" : val1 + "");
            },
            clearPage: function (pg) {
                var xx = [];
                for (var i in pg.getContent())
                    xx.push(pg.getContent()[i]);
                for (var i in xx) {
                    pg.removeContent(xx[i]);
                    // if (xx[i].hasOwnProperty("getItems")) {
                    //     for (var ii in xx[i].getItems())
                    //         xx[i].getItems()[ii].destroy();
                    // }
                    // if (xx[i].hasOwnProperty("getContent")) {
                    //     for (var ii in xx[i].getContent())
                    //         xx[i].getContent()[ii].destroy();
                    // }

                    xx[i].destroy();
                }

                pg.removeAllContent();
            },
            showApps: function () {
                var dlg = new sap.m.Dialog({
                    title: "Select the App",
                    contentWidth: "100%",
                    contentHeight: "60%"
                });
                var flx = new sap.m.FlexBox();
                dlg.addContent();
                dlg.open();
            },
            initProdListModel: function (view) {
                var ResourceModel = sap.ui.model.resource.ResourceModel;
                var sLangu =
                    sap.ui.getCore().getConfiguration().getLanguage();
                var oLangu = new ResourceModel(
                    {
                        bundleUrl: "../i18n/i18n.properties",

                        "bundleLocale": sLangu
                    });
                view.setModel(oLangu, "i18n");
            },
            getProdList2Data: function (i18nMdl) {
                var data = {
                    "prods": [
                        {
                            "code": "01",
                            "name": i18nMdl.getProperty("fin_1")
                        },
                        {
                            "code": "02",
                            "name": i18nMdl.getProperty("fin_2")
                        },
                        {
                            "code": "03",
                            "name": i18nMdl.getProperty("fin_3")
                        },
                        {
                            "code": "04",
                            "name": i18nMdl.getProperty("fin_4")
                        },
                        {
                            "code": "04",
                            "name": i18nMdl.getProperty("fin_6")
                        },
                        {
                            "code": "05",
                            "name": i18nMdl.getProperty("fin_7")
                        },
                        {
                            "code": "06",
                            "name": i18nMdl.getProperty("fin_8")
                        },
                        {
                            "code": "07",
                            "name": i18nMdl.getProperty("fin_9")
                        },
                        {
                            "code": "08",
                            "name": i18nMdl.getProperty("fin_10")
                        }
                    ]
                };
                return data;
            },
            createProdListPage: function (view) {
                var data = this.getProdList2Data(view.getModel('i18n'));
                var oModel = new sap.ui.model.json.JSONModel();
                oModel.setData(data);
                view.setModel(oModel);
                view.txt = new sap.m.Label({ text: "" });

                var oList = new sap.m.List({
                    headerText: "Product Lists",
                    id: "mainList", // sap.ui.core.ID
                    inset: false, // boolean
                    visible: true, // boolean
                    mode: sap.m.ListMode.None, // sap.m.ListMode
                    width: '100%', // sap.ui.core.CSSSize
                    showSeparators: sap.m.ListSeparators.All, // sap.m.ListSeparators
                }).addStyleClass("sapContrast");

                var actionListItem = new sap.m.ActionListItem("action",
                    {
                        text: "{name}",
                        customData: [{ key: "{code}" }],
                        press: function (oControlEvent) {
                            view.splitApp.to("detailPage", "slide");
                            var oPressedItem = view.getModel().getProperty(this.getBindingContext().getPath());
                            var cod = oControlEvent.getSource().getCustomData()[0].getKey();
                            var prod = "products/";
                            if (typeof callFromProd2 == 'undefined')
                                prod = "";
                            if (cod == "01")
                                document.location.href = prod + "gl.html";
                            if (cod == "02")
                                document.location.href = prod + "construction.html";
                            if (cod == "03")
                                document.location.href = prod + "pursale.html";
                            if (cod == "04")
                                document.location.href = prod + "inventory.html";
                            if (cod == "05")
                                document.location.href = prod + "fa.html";
                            if (cod == "06")
                                document.location.href = prod + "pmr.html";
                            if (cod == "07")
                                document.location.href = prod + "pos.html";
                            if (cod == "08")
                                document.location.href = prod + "ia.html";
                            if (cod == "09")
                                document.location.href = prod + "lg.html";


                            // that.splitApp.to("detailPage", "slide");
                            // var oPressedItem = that.getModel().getProperty(view.getBindingContext().getPath());
                            // var cod = oControlEvent.getSource().getCustomData()[0].getKey();
                            //
                            // if (cod == "01")
                            //     that.showGraphGL();
                            // if (cod == "02")
                            //     that.showGraphRM();
                            // if (cod == "03")
                            //     that.showGraphPurSale();
                            //

                        }
                    });

                oList.bindItems("/prods", actionListItem);
                view.splitApp = new sap.m.SplitApp("prod2App", {});
                view.pg = new sap.m.Page({
                    showHeader: false,
                    content: [oList]
                });
                var bar1 = this.createBar(this.nvl(view.pageTitle, "-"), true);
                view.pg2 = new sap.m.Page("detailPage", {
                    customHeader: bar1,
                    showHeader: true,
                    content: []
                });

                view.splitApp.addMasterPage(view.pg);
                view.splitApp.addDetailPage(view.pg2);

                view.mainPage = new sap.m.Page({
                    showHeader: true,
                    customHeader: view.custBar,
                    content: [view.splitApp]
                }).addStyleClass("sapContrast");

            },
            createBar: function (lblId, pBackMaster) {
                var backMaster = this.nvl(pBackMaster, true);
                var b = new sap.m.Button({
                    icon: "sap-icon://full-screen",
                    press: function () {
                        var app = sap.ui.getCore().byId("prod2App");
                        if (app.getMode() == sap.m.SplitAppMode.HideMode)
                            app.setMode(sap.m.SplitAppMode.ShowHideMode);
                        else
                            app.setMode(sap.m.SplitAppMode.HideMode);

                    }
                });
                var flRight = new sap.m.FlexBox({ direction: sap.m.FlexDirection.Row, items: [b] });
                var flLeft = new sap.m.FlexBox({
                    direction: sap.m.FlexDirection.Row, items: [new sap.m.Button({
                        icon: "sap-icon://arrow-left",
                        press: function () {
                            var app = sap.ui.getCore().byId("prod2App");
                            if (!sap.ui.Device.system.phone) {
                                //app.toDetail(app.getDetailPages()[0]);
                                app.backDetail();
                                if (pBackMaster)
                                    app.toMaster(app.getMasterPages()[0]);
                            } else {
                                app.backMaster();
                                app.toMaster(app.getMasterPages()[0]);
                                // if (backMaster)
                                //     app.showMaster();
                            }
                        }
                    })]
                });
                var flMiddle = new sap.m.FlexBox({
                    direction: sap.m.FlexDirection.Row, items: [new sap.m.Label({
                        text: lblId,
                        textAlign: "Center",
                        design: "Bold"
                    })]
                });

                var oBar = new sap.m.Bar({
                    contentLeft: [flLeft],
                    contentMiddle: [flMiddle],

                    contentRight: [flRight]

                }).addStyleClass("sapContrast sapMIBar");
                return oBar;
            },
            select_screen: function (oController) {
                if (oController.oFragment === undefined)
                    oController.oFragment = sap.ui.jsfragment("bin.Screens", oController);
                oController.oFragment.open();

            },
            // get index no by key value in combbox
            getIndexByKey: function (cb, kyval) {
                for (var i = 0; i < cb.getItems().length; i++) {
                    if (cb.getItems()[i].getKey() == kyval)
                        return cb.getItems()[i];
                }
            },
            cookieGet: function (cname) {
                var name = cname + "=";
                var decodedCookie = decodeURIComponent(document.cookie);
                var ca = decodedCookie.split(';');
                for (var i = 0; i < ca.length; i++) {
                    var c = ca[i];
                    while (c.charAt(0) == ' ') {
                        c = c.substring(1);
                    }
                    if (c.indexOf(name) == 0) {
                        return c.substring(name.length, c.length);
                    }
                }
                return "";
            },
            cookieSet: function setCookie(cname, cvalue, exdays) {
                var d = new Date();
                d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                var expires = "expires=" + d.toUTCString();
                document.cookie = cname + "=" + cvalue + ";" + expires + ";path=/";
            },
            cookieDelete: function (cname) {
                document.cookie = cname + "=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
            },
            createControl: function (component, view, id, setting, fldtype, fldFormat, fnChange, sqlStr, cbModel) {

                var s = this.nvl(setting, {});
                if (Util.nvl(id, "") != "")
                    (view.byId(id) != undefined ? view.byId(id).destroy() : null);
                var c;
                if (Util.nvl(id, "") != "")
                    c = new component(view.createId(id), s).addStyleClass("sapUiSizeCondensed");
                else
                    c = new component(s).addStyleClass("sapUiSizeCondensed");
                if (fldtype != undefined)
                    c.field_type = fldtype;
                if (fnChange != undefined)
                    c.fnChange = fnChange;
                if (c instanceof sap.m.InputBase) {
                    c.attachChange(function (oEvent) {
                        var _oInput = oEvent.getSource();
                        var val = _oInput.getValue();
                        if (_oInput.getCustomData().length == 0)
                            _oInput.addCustomData(new sap.ui.core.CustomData({ key: val }))
                        else
                            _oInput.getCustomData()[0].setKey(val);

                    });
                    if (Util.nvl(c.getTooltip_AsString(), "") != "")
                        setTimeout(() => {
                            c.addEventDelegate({
                                onfocusin: function (e) {
                                    var oInput = e.srcControl;
                                    var sTooltip = oInput.getTooltip_AsString();
                                    UtilGen.DashboardWidget.statusBarText(sTooltip, false, undefined,
                                        //     function (msg) {
                                        //     UtilGen.showCustomMessageToast(msg, 100, "black",
                                        //         "lightgrey", "18px", {
                                        //         width: "50vw",
                                        //         offset: "0 20",
                                        //         my: sap.ui.core.Popup.Dock.CenterBottom,
                                        //         at: sap.ui.core.Popup.Dock.CenterBottom,
                                        //     });
                                        // }
                                    );
                                },
                                onfocusout: function (e) {
                                    UtilGen.DashboardWidget.statusBarText("", false, undefined);
                                }
                            });
                        });
                }
                if (c instanceof sap.m.SearchField)
                    c.attachChange(function (oEvent) {
                        var _oInput = oEvent.getSource();
                        var val = _oInput.getValue();
                        if (_oInput.getCustomData().length == 0)
                            _oInput.addCustomData(new sap.ui.core.CustomData({ key: val }))
                        else
                            _oInput.getCustomData()[0].setKey(val);

                    });
                if (fldtype == "number" && (c instanceof sap.m.Input)) {
                    c.setTextAlign(sap.ui.core.TextAlign.End);
                    c.attachLiveChange(function (oEvent) {
                        var _oInput = oEvent.getSource();
                        var val = _oInput.getValue();
                        val = val.replace(/[^\d\.-]/g, '');
                        //_oInput.setValue(val);
                        if (_oInput.getCustomData().length == 0)
                            _oInput.addCustomData(new sap.ui.core.CustomData({ key: val }))
                        else
                            _oInput.getCustomData()[0].setKey(parseFloat(val));
                    });
                    if (Util.nvl(fldFormat, "") != "") {
                        c.field_format = fldFormat;
                        c.attachChange(function (oEvent) {
                            var df = new DecimalFormat(fldFormat);
                            var _oInput = oEvent.getSource();
                            var val = _oInput.getCustomData()[0].getKey();
                            _oInput.setValue(df.format(parseFloat(val)));
                            if (_oInput.fnChange != undefined) {
                                fnChange(oEvent);
                            }
                        });
                    }
                }

                if (c instanceof sap.m.ComboBox && sqlStr != undefined) {
                    if (sqlStr.startsWith("@")) {
                        var dtxx = [];
                        var spt = sqlStr.substring(1).split(",");
                        for (var i1 in spt) {
                            var dttt = { CODE: "", NAME: "" };
                            var sx = spt[i1].split("/");
                            dttt.CODE = "" + sx[0];
                            dttt.NAME = "" + Util.getLangText(sx[1]);
                            dtxx.push(dttt);
                        }
                        if (Util.nvl(cbModel, "") != "") {
                            dtxx = { lists: dtxx };
                            c.setModel(new sap.ui.model.json.JSONModel(dtxx), cbModel);
                        }
                        else
                            c.setModel(new sap.ui.model.json.JSONModel(dtxx));
                    } else {
                        var dat = Util.execSQL(sqlStr);
                        if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                            var dtx = JSON.parse("{" + dat.data + "}").data;
                            if (Util.nvl(cbModel, "") != "") {
                                dtx = { lists: dtx };
                                c.setModel(new sap.ui.model.json.JSONModel(dtx), cbModel);
                            }
                            else
                                c.setModel(new sap.ui.model.json.JSONModel(dtx));
                        }
                    }
                    c.attachSelectionChange(function (oEvent) {
                        var _oInput = oEvent.getSource();
                        var val = _oInput.getSelectedKey();
                        if (_oInput.getCustomData().length == 0)
                            _oInput.addCustomData(new sap.ui.core.CustomData({ key: val }))
                        else
                            _oInput.getCustomData()[0].setKey(val);

                    });
                    c.attachChange(function () {
                        if (c.getItems().length > 0 && c.getValue() != "" && !Util.isCBValValid(c))
                            setTimeout(() => { c.focus(); c.setValue(""); c.setSelectedKey(""); }, 150);
                    })
                }
                if (c instanceof sap.m.MultiComboBox && sqlStr != undefined) {
                    if (sqlStr.startsWith("@")) {
                        var dtxx = [];
                        var spt = sqlStr.substring(1).split(",");
                        for (var i1 in spt) {
                            var dttt = { CODE: "", NAME: "" };
                            var sx = spt[i1].split("/");
                            dttt.CODE = "" + sx[0];
                            dttt.NAME = "" + Util.getLangText(sx[1]);
                            dtxx.push(dttt);
                        }
                        if (Util.nvl(cbModel, "") != "") {
                            dtxx = { lists: dtxx };
                            c.setModel(new sap.ui.model.json.JSONModel(dtxx), cbModel);
                        }
                        else
                            c.setModel(new sap.ui.model.json.JSONModel(dtxx));
                    } else {
                        var dat = Util.execSQL(sqlStr);
                        if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                            var dtx = JSON.parse("{" + dat.data + "}").data;
                            if (Util.nvl(cbModel, "") != "") {
                                dtx = { lists: dtx };
                                c.setModel(new sap.ui.model.json.JSONModel(dtx), cbModel);
                            }
                            else
                                c.setModel(new sap.ui.model.json.JSONModel(dtx));
                        }
                    }
                    // c.attachSelectionChange(function (oEvent) {
                    //     var _oInput = oEvent.getSource();
                    //     var val = _oInput.getSelectedKey();
                    //     if (_oInput.getCustomData().length == 0)
                    //         _oInput.addCustomData(new sap.ui.core.CustomData({ key: val }))
                    //     else
                    //         _oInput.getCustomData()[0].setKey(val);

                    // });
                }
                if (c instanceof sap.m.ListBase && sqlStr != undefined) {
                    if (sqlStr.startsWith("@")) {
                        var dtxx = [];
                        var spt = sqlStr.substring(1).split(",");
                        for (var i1 in spt) {
                            var dttt = { CODE: "", NAME: "" };
                            var sx = spt[i1].split("/");
                            dttt.CODE = "" + sx[0];
                            dttt.NAME = "" + sx[1];
                            dtxx.push(dttt);
                        }
                        c.setModel(new sap.ui.model.json.JSONModel(dtxx));
                    } else {
                        var dat = Util.execSQL(sqlStr);
                        if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                            var dtx = JSON.parse("{" + dat.data + "}").data;
                            c.setModel(new sap.ui.model.json.JSONModel(dtx));
                        }
                    }
                }

                if (c.getCustomData().length == 0)
                    c.addCustomData(new sap.ui.core.CustomData({ key: "" }));

                if (c instanceof sap.m.DatePicker) {
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    c.setValueFormat(sett["ENGLISH_DATE_FORMAT"]);
                    c.setDisplayFormat(sett["ENGLISH_DATE_FORMAT"]);
                    if (this.nvl(fldFormat, "") != "") {
                        c.setValueFormat(fldFormat);
                        c.setDisplayFormat(fldFormat);
                    }

                }
                return c;

            },
            getControlValue(comp) {
                var customVal = "";
                if (comp instanceof sap.m.InputBase && comp.getCustomData != undefined && comp.getCustomData().length > 0)
                    customVal = comp.getCustomData()[0].getKey();
                if (comp instanceof sap.m.SearchField && comp.getCustomData != undefined && comp.getCustomData().length > 0)
                    customVal = comp.getCustomData()[0].getKey();

                if (customVal == "NaN")
                    customVal = "";
                if (customVal == "false" && !(comp instanceof sap.m.CheckBox))
                    customVal = "";
                if (comp instanceof sap.m.Text)
                    return this.nvl(customVal, comp.getText());
                if (comp instanceof sap.m.Label)
                    return comp.getText();
                if (comp instanceof sap.m.SearchField)
                    return this.nvl(customVal, comp.getValue());
                if (comp instanceof sap.m.DatePicker)
                    return comp.getDateValue();
                if (comp instanceof sap.m.DateTimePicker)
                    return comp.getDateValue();
                if (comp instanceof sap.m.TimePicker)
                    return comp.getDateValue();
                if (comp instanceof sap.m.ComboBox)
                    return this.nvl(comp.getSelectedKey(), comp.getValue());
                if (comp instanceof sap.m.MultiComboBox) {
                    var vl = "";
                    var kys = comp.getSelectedKeys();
                    // if (kys.length == 1) return kys[0];
                    for (var k in kys)
                        vl += "\"" + kys[k] + "\""
                    return vl;
                }
                if (comp instanceof sap.m.ListBase)
                    return (Util.nvl(comp.getSelectedItem(), undefined) != undefined ?
                        this.nvl(comp.getSelectedItem().getCustomData()[0], "") : "");
                if (comp instanceof sap.m.CheckBox)
                    if (comp.trueValues != undefined)
                        return (comp.getSelected() ? comp.trueValues[0] : comp.trueValues[1]);
                    else
                        return (comp.getSelected() ? "Y" : "N");
                if (comp instanceof sap.m.InputBase)
                    return this.nvl(customVal, comp.getValue());

            }
            ,
            setControlValue: function (comp, pVal, pCustomVal, executeChange) {
                var val = this.nvl(pVal, "") + "";
                var customVal = Util.nvl(pCustomVal, Util.nvl(pVal, ""));
                if ((!comp instanceof sap.m.InputBase) && comp.field_type != undefined && comp.field_type == "number") {
                    val = val.replace(/[^\d\.-]/g, '');
                    if (comp.getCustomData().length == 0)
                        comp.addCustomData(new sap.ui.core.CustomData({ key: val }))
                    else
                        comp.getCustomData()[0].setKey(parseFloat(val));

                    if (comp.setText != undefined)
                        comp.setText(val);

                    if (comp.setValue != undefined)
                        comp.setValue(val);


                    if (executeChange && comp.hasOwnProperty("fireChange"))
                        comp.fireChange();
                    // return;
                } else if (comp instanceof sap.m.ComboBox) {
                    comp.setSelectedItem(this.getIndexByKey(comp, Util.nvl(pCustomVal, val)));
                    if (comp.getCustomData().length == 0)
                        comp.addCustomData(new sap.ui.core.CustomData({ key: customVal }))
                    else
                        comp.getCustomData()[0].setKey(customVal);

                    if (executeChange)
                        comp.fireChange();

                } else if (comp instanceof sap.m.MultiComboBox) {
                    // console.log(Util.nvl(pCustomVal, val));
                    var sp = Util.nvl(pCustomVal, val);
                    var kys = Util.extractQuotedStrings(sp);
                    comp.removeAllSelectedItems();
                    comp.setSelectedKeys(kys);

                    //for (var k in kys)



                    // comp.setSelectedItem(this.getIndexByKey(comp, Util.nvl(pCustomVal, val)));
                    // if (comp.getCustomData().length == 0)
                    //     comp.addCustomData(new sap.ui.core.CustomData({ key: customVal }))
                    // else
                    //     comp.getCustomData()[0].setKey(customVal);

                    // if (executeChange)
                    //     comp.fireChange();

                } else if (comp instanceof sap.m.ListBase) {
                    comp.setSelectedItem(this.getIndexByKey(comp, Util.nvl(pCustomVal, val)));
                    if (executeChange)
                        comp.fireChange();

                } else if (comp instanceof sap.m.Text) {
                    comp.setText(val);
                    // if (customVal.length > 0)
                    if (comp.getCustomData().length == 0)
                        comp.addCustomData(new sap.ui.core.CustomData({ key: customVal }))
                    else
                        comp.getCustomData()[0].setKey(customVal);


                } else if ((comp instanceof sap.m.DatePicker) ||
                    (comp instanceof sap.m.TimePicker)) {

                    if (this.nvl(pVal, "").length == 0)
                        comp.setDateValue(null);
                    else {
                        var pvx = (typeof pVal == "string" ? pVal.replaceAll(".", ":") : pVal);
                        comp.setDateValue(new Date(pvx));
                    }

                    if (executeChange)
                        comp.fireChange();

                } else if (comp instanceof sap.m.CheckBox) {
                    if (comp.trueValues != undefined)
                        (val == comp.trueValues[0] ? comp.setSelected(true) : comp.setSelected(false));
                    if (executeChange)
                        comp.fireSelect();

                } else if ((!(comp instanceof sap.m.ComboBoxBase)) &&
                    comp instanceof sap.m.InputBase || comp instanceof sap.m.SearchField
                ) {
                    comp.setValue(val);
                    // if (customVal.length > 0)
                    if (comp.getCustomData().length == 0)
                        comp.addCustomData(new sap.ui.core.CustomData({ key: customVal }))
                    else
                        comp.getCustomData()[0].setKey(customVal);
                    if (comp instanceof sap.m.InputBase && executeChange)
                        comp.fireChange();
                }
                else if (comp != undefined && comp.hasOwnProperty("value")) {
                    comp.value = pVal;
                }

                if (comp != undefined && comp.hasOwnProperty("onSetField")) {
                    comp.onSetField(pVal);
                }


            },
            formCreate2: function (title, editable, content, pHbSet, classCont, contSetting, contCssClass, lastAddVB) {
                var cc = Util.nvl(contCssClass, "");
                cc = contSetting != undefined ? Util.nvl(contSetting["class"], cc) : cc;
                if (contSetting != undefined && contSetting.hasOwnProperty("width")) {
                    if (typeof contSetting.width == "object") {
                        var newr = "L";
                        if (sap.ui.Device.resize.width <= 768)
                            newr = "S";
                        if (sap.ui.Device.resize.width > 768 && sap.ui.Device.resize.width <= 992)
                            newr = "M";
                        if (sap.ui.Device.resize.width > 992)
                            newr = "L";
                        if (sap.ui.Device.resize.width > 1200)
                            newr = "XL";
                        contSetting.width = Util.nvl(contSetting.width[newr], contSetting.width["L"]) + "px";
                        console.log("DEVICE " + newr + " -width=" + sap.ui.Device.resize.width + " records=" + contSetting.width);
                    }
                }

                var sc = new classCont(Util.nvl(contSetting, {})).addStyleClass(cc);
                if (contSetting != undefined && contSetting.hasOwnProperty("height"))
                    sc.setHeight(contSetting.height);

                if (Util.nvl(contSetting, {}).hasOwnProperty("cssText")) {
                    setTimeout(function () {
                        var ar = [].concat(contSetting["cssText"]);
                        for (var ix in ar)
                            sc.$().css("cssText", ar);
                    }, 50);
                }

                if (Util.nvl(contSetting, {}).hasOwnProperty("css")) {
                    setTimeout(function () {
                        var ar = {}.concat(contSetting["css"]);
                        sc.$().css(contSetting["css"]);
                    }, 50);
                }

                var totWd = Util.nvl(Util.nvl(contSetting, {})["width"], "600px").replace("px", "");

                var fnAdd = function (cnt) {
                    if (typeof sc.addItem == "function")
                        sc.addItem(cnt);
                    else if (typeof sc.addContent == "function")
                        sc.addContent(cnt);
                };

                var cnt = [];
                var hz = [];
                var hbSet = Util.nvl(pHbSet, {});
                // if (hbSet.hasOwnProperty("width"))
                //     hbSet["width"] = "100%";
                if (hbSet.hasOwnProperty("height"))
                    hbSet["height"] = "24px";
                var hb = new sap.m.HBox(hbSet);

                for (var i in content) {
                    if (content[i] == undefined) {
                        console.log("form element " + i + " is undefined !");
                        continue;
                    }
                    fnAdd(hb);
                    if (typeof content[i] === "string" && !content[i].startsWith("@") &&
                        !content[i].startsWith("#")) {
                        var cn = {};
                        try {
                            cn = JSON.parse(content[i]);
                        } catch (e) {
                            cn = { text: content[i] };
                        }
                        var setx = cn;
                        if (setx.hasOwnProperty("width") && setx["width"].endsWith("%")) {
                            var wd = (totWd / 100) * Util.extractNumber(setx["width"]);
                            setx["width"] = wd + "px";
                        }
                        if (Util.isCamelCase(setx["text"])) setx["text"] = Util.getLangText(setx["text"]);
                        var lbl = new sap.m.Label(setx);
                        if (setx.hasOwnProperty("styleClass"))
                            lbl.addStyleClass(setx["styleClass"]);
                        hb = new sap.m.HBox(hbSet);
                        fnAdd(hb);
                        hb.addItem(lbl);

                    } else if (typeof content[i] === "string" && content[i].startsWith("@")) {
                        var cn = {};
                        try {
                            cn = JSON.parse(content[i].substr(1));
                        } catch (e) {
                            cn = { text: content[i].substr(1) };
                        }

                        var setx = cn;
                        if (setx.hasOwnProperty("width") && setx["width"].endsWith("%")) {
                            var wd = (totWd / 100) * Util.extractNumber(setx["width"]);
                            setx["width"] = wd + "px";
                        }
                        if (setx.hasOwnProperty("wrapping")) {
                            setx["wrapping"] = setx["wrapping"] == "true";
                        } else
                            setx["wrapping"] = true;

                        if (Util.isCamelCase(setx["text"])) setx["text"] = Util.getLangText(setx["text"]);
                        var lbl = new sap.m.Label(setx);
                        if (setx.hasOwnProperty("styleClass"))
                            lbl.addStyleClass(setx["styleClass"]);
                        hb.addItem(lbl);
                        // cnt.push(new sap.m.Text(setx));
                    } else if (typeof content[i] === "string" && content[i].startsWith("#")) {
                        var cn = {};
                        try {
                            cn = JSON.parse(content[i].substr(1));
                        } catch (e) {
                            cn = { text: content[i].substr(1) };
                        }
                        var setx = cn;
                        if (setx.hasOwnProperty("width") && setx["width"].endsWith("%")) {
                            var wd = (totWd / 100) * Util.extractNumber(setx["width"]);
                            setx["width"] = wd + "px";
                        }
                        var lbl = new sap.m.Title(setx);
                        if (setx.hasOwnProperty("styleClass"))
                            lbl.addStyleClass(setx["styleClass"]);
                        if (setx.hasOwnProperty("style"))
                            lbl.$().attr("style", setx["style"]);
                        if (Util.isCamelCase(setx["text"])) setx["text"] = Util.getLangText(setx["text"]);
                        hb = new sap.m.HBox(hbSet);
                        fnAdd(hb);
                        hb.addItem(lbl);
                        // hb.addItem(new sap.m.Title({text: content[i].substr(1)}));
                        // hb = new sap.m.HBox(hbSet);
                        // fnAdd(hb);
                        // hb.addItem(new sap.m.Title({text: content[i].substr(1)}));
                    }
                    else {
                        if (typeof content[i].setWidth == "function" && content[i].getWidth().endsWith("%")) {
                            var wd = (totWd / 100) * Util.extractNumber(content[i].getWidth());
                            content[i].setWidth(wd + "px");
                        }
                        hb.addItem(content[i]);

                    }
                    hb.addStyleClass("formRow");

                }
                if (lastAddVB != undefined)
                    fnAdd(new sap.m.VBox({ height: lastAddVB }));
                return sc;
            }
            ,
            //---------------------------------------------------------------------------------------------------------
            // all value labelspan , emptyspan == small, medium , large, xlarge-----------------
            //---------------------------------------------------------------------------------------------------------
            formCreate: function (title, editable, content, labelSpan, emptySpan, columns, spanForLabel) {
                var ls = labelSpan;
                var es = emptySpan;
                var cs = columns;
                var ed = false;
                var cnt = [];
                var prev_span = Util.nvl(spanForLabel, "");
                if (editable)
                    ed = true;
                if (labelSpan == undefined || labelSpan.length == 0)
                    ls = [12, 3, 3, 2];
                if (emptySpan == undefined || emptySpan.length == 0)
                    es = [0, 2, 2, 2];
                if (columns == undefined || columns.length == 0)
                    cs = [1, 2, 2];
                for (var i in content) {
                    if (content[i] == undefined) {
                        console.log("form element " + i + " is undefined !");
                        continue;
                    }
                    if (typeof content[i] === "string" && !content[i].startsWith("@") &&
                        !content[i].startsWith("#")) {

                        var cn = {};
                        try {
                            cn = JSON.parse(content[i]);
                        } catch (e) {
                            cn = { text: content[i] };
                        }
                        var setx = cn;
                        setx["width"] = "auto";
                        delete cn.width;
                        delete cn.textAlign;
                        if (prev_span != "")
                            setx["layoutData"] = new sap.ui.layout.GridData({ span: prev_span });

                        if (Util.isCamelCase(setx["text"])) setx["text"] = Util.getLangText(setx["text"]);
                        cnt.push(new sap.m.Label(setx));
                    }
                    else if (typeof content[i] === "string" && content[i].startsWith("@")) {
                        var setx = { text: content[i].substr(1), /* textAlign: sap.ui.core.TextAlign.Right*/ };
                        var cn = {};
                        try {
                            cn = JSON.parse(content[i].substr(1));

                        } catch (e) {
                            cn = { text: content[i].substr(1) };
                        }

                        var setx = cn;
                        if (prev_span != "")
                            setx["layoutData"] = new sap.ui.layout.GridData({ span: prev_span });
                        setx["width"] = "auto";
                        delete cn.width;
                        delete cn.textAlign;
                        if (Util.isCamelCase(setx["text"])) setx["text"] = Util.getLangText(setx["text"]);
                        cnt.push(new sap.m.Text(setx));
                    }
                    else if (typeof content[i] === "string" && content[i].startsWith("#")) {
                        var str = content[i].substr(1);
                        if (Util.isCamelCase(str)) str = Util.getLangText(str);
                        cnt.push(new sap.ui.core.Title({ text: str }));
                    } else {
                        if (typeof content[i].setWidth == "function")
                            content[i].setWidth("auto");
                        cnt.push(content[i]);
                    }
                    // if (cnt[cnt.length - 1].getLayoutData() != undefined)
                    //     prev_span = cnt[cnt.length - 1].getLayoutData().getSpan();
                    // else prev_span = "";
                }

                return new sap.ui.layout.form.SimpleForm({

                    editable: ed,
                    layout: sap.ui.layout.form.SimpleFormLayout.ResponsiveGridLayout,
                    labelSpanXL: ls[3],
                    labelSpanL: ls[2],
                    labelSpanM: ls[1],
                    labelSpanS: ls[0],
                    adjustLabelSpan: false,
                    emptySpanXL: es[3],
                    emptySpanL: es[2],
                    emptySpanM: es[1],
                    emptySpanS: es[0],
                    columnsXL: cs[2],
                    columnsL: cs[1],
                    columnsM: cs[0],
                    singleContainerFullSize: false,
                    content: cnt,
                    toolbar: new sap.m.Toolbar({
                        content: [
                            new sap.m.Title({ text: title, level: "H4", titleStyle: "H4" }),
                        ]
                    })
                });
            },
            addControl: function (ar, lbl, cntClass, id, sett, dataType, fldFormat, view, fnchange, sqlStr) {
                var setx = sett;
                var idx = id;
                if (Util.nvl(id, "") == "")
                    idx = lbl.replace(/[ ||,||.||\/||@||#]/g, "");
                if (Util.nvl(id, "").endsWith("_")) {
                    idx = id + lbl.replace(/[ ||,||.||\/||@||#]/g, "");
                    if (lbl.startsWith("@") || lbl.startsWith("#"))
                        idx = lbl.substr(1, 1) + idx;
                }
                var cnt = this.createControl(cntClass, view, idx, setx, dataType, fldFormat, fnchange, sqlStr);
                var vb = true;
                if (cnt.getVisible != undefined)
                    vb = cnt.getVisible();
                if (vb && lbl.length != 0)
                    ar.push(lbl);
                if (vb) ar.push(cnt);
                return cnt;
            }
            ,
            formAddItem: function (frm, label, controls) {
                frm.addContent(new sap.m.Label({ text: label }));
                if (controls instanceof Array)
                    for (var i in controls)
                        frm.addContent(controls[i]);
                else
                    frm.addContent(controls);
            }
            ,
            getSQLInsertString: function (tbl, flds, excFlds, datesWithTime) {

                var hma = "";
                var ohma = "";
                var hms = " h mm a";
                if (datesWithTime) {
                    hma = " h mm a";
                    ohma = " HH MI AM"
                }
                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"] + hma);
                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                var sdft = new simpleDateFormat(hms);

                var kys = [];
                var str = "";
                var vl = "";

                // add additional fields and values to vls.
                if (flds != undefined)
                    for (var key in flds) {
                        str += (str.length == 0 ? "" : ",") + key;
                        vl += (vl.length == 0 ? "" : ",") + flds[key];
                    }

                for (var key in tbl) {
                    if (!key.startsWith("_") && (excFlds == undefined || excFlds.indexOf(key) < 0)) {
                        str += (str.length == 0 ? "" : ",") + key;
                        var val = this.getControlValue(tbl[key]);

                        // if (tbl[key].getCustomData().length > 0 &&
                        //     tbl[key].getCustomData()[0].getKey().trim().length > 0
                        // )
                        //     val = this.nvl(tbl[key].getCustomData()[0].getKey().trim(), tbl[key].getValue());


                        // if (tbl[key] instanceof sap.m.SearchField &&
                        //     tbl[key].getCustomData().length > 0)
                        //     val = this.nvl(tbl[key].getCustomData()[0].getKey(), tbl[key].getValue());
                        //
                        val = "'" + (val + "").replace("'", "''") + "'";

                        if (tbl[key] instanceof sap.m.DatePicker && tbl[key].getDateValue() != undefined)
                            val = "to_date('" + sdf.format(tbl[key].getDateValue()) + "','" + sett["ENGLISH_DATE_FORMAT"] + ohma + "')";
                        if (tbl[key] instanceof sap.m.DatePicker && tbl[key].getDateValue() == undefined)
                            val = "null";

                        if (tbl[key] instanceof sap.m.TimePicker && tbl[key].getDateValue() != undefined)
                            val = "to_date('" + sdft.format(tbl[key].getDateValue()) + "','HH12 MI am')";
                        if (tbl[key] instanceof sap.m.TimePicker && tbl[key].getDateValue() == undefined)
                            val = "null";

                        if (tbl[key].field_type != undefined && tbl[key].field_type == "number")
                            val = tbl[key].getValue();
                        if (tbl[key].field_type != undefined && tbl[key].field_type == "money")
                            val = df.parse(tbl[key].getValue());

                        vl += (vl.length == 0 ? "" : ",") + val;
                    }
                }

                return "(" + str + ') values (' + vl + ")";

            }
            ,
            getSQLUpdateString: function (tbl, tbl_name, flds, where, excFlds, datesWithTime) {

                var hma = "";
                var ohma = "";
                var hms = " h mm a";
                if (datesWithTime) {
                    hma = " h mm a";
                    ohma = " HH MI AM"
                }

                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"] + hma);
                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                var sdft = new simpleDateFormat(hms);
                var kys = [];
                var str = "";
                var vl = "";



                // add additional fields and values to vls.
                if (flds != undefined)
                    for (var key in flds)
                        str += (str.length == 0 ? "" : ",") + key + "=" + flds[key];

                // put field=value in string
                for (var key in tbl) {
                    if (!key.startsWith("_") && (excFlds == undefined || excFlds.indexOf(key) < 0)) {
                        var val = this.getControlValue(tbl[key]);

                        val = "'" + (val + "").replace("'", "''") + "'";

                        if (tbl[key] instanceof sap.m.DatePicker && tbl[key].getDateValue() != undefined)
                            val = "to_date('" + sdf.format(tbl[key].getDateValue()) + "','" + sett["ENGLISH_DATE_FORMAT"] + ohma + "')";
                        if (tbl[key] instanceof sap.m.DatePicker && tbl[key].getDateValue() == undefined)
                            val = "null";
                        if (tbl[key] instanceof sap.m.TimePicker && tbl[key].getDateValue() != undefined)
                            val = "to_date('" + sdft.format(tbl[key].getDateValue()) + "','HH12 MI am')";
                        if (tbl[key] instanceof sap.m.TimePicker && tbl[key].getDateValue() == undefined)
                            val = "null";
                        if (tbl[key].field_type != undefined && tbl[key].field_type == "number")
                            val = tbl[key].getValue();
                        if (tbl[key].field_type != undefined && tbl[key].field_type == "money")
                            val = df.parse(tbl[key].getValue());

                        str += (str.length == 0 ? "" : ",") + key + "=" + val;

                    }
                }

                return "update " + tbl_name + " set " + str + (this.nvl(where, "").length == 0 ? "" : " where ") + this.nvl(where, "");

            }
            ,
            loadDataFromJson(subs, dtx, executeChange) {
                for (var key in subs) {
                    var vl = dtx[key.toUpperCase()];
                    if (subs[key] != undefined && vl != undefined)
                        this.setControlValue(subs[key], vl, vl, this.nvl(executeChange, false));

                }
            }
            ,
            resetDataJson(subs) {
                for (var key in subs)
                    this.setControlValue(subs[key], "", false);

            }
            ,
            doFilterLiveTable(event, qv, flcol) {
                var flts = [];
                var val = event.oSource.getValue();
                if (Util.nvl(val, "") == "") return;
                for (var i in qv.mLctb.cols) {
                    var f = sap.ui.model.FilterOperator.Contains;
                    if (qv.mLctb.cols[i].getMUIHelper().data_type == "NUMBER")
                        f = sap.ui.model.FilterOperator.EQ;
                    if (flcol.indexOf(qv.mLctb.cols[i].mColName) > -1)
                        flts.push(new sap.ui.model.Filter({
                            path: qv.mLctb.cols[i].mColName,
                            operator: f,
                            value1: val
                        }));
                }
                var f = new sap.ui.model.Filter({
                    filters: flts,
                    and: false
                });
                var lst = qv.getControl();

                var filter = new sap.ui.model.Filter(f, false);
                var binding = lst.getBinding("rows");
                binding.filter(filter);
                setTimeout(function () {
                    qv.colorRows();
                });
            }
            ,
            parseDefaultValue: function (vl) {
                var fisc = sap.ui.getCore().getModel("fiscalData").getData();

                var retVal = Util.nvl(vl, "");
                if (retVal.startsWith("#DATE_"))
                    retVal = new Date(vl.replace("#DATE_", ""));
                if (typeof retVal == "string" && retVal.startsWith("#NUMBER_"))
                    retVal = parseFloat(vl.replace("#NUMBER_", ""));
                if (typeof retVal == "string" && retVal == "$TODAY") {
                    retVal = Util.nvl(UtilGen.DBView.today_date.getDateValue(), new Date());
                    if (retVal > fisc.fiscal_to)
                        retVal = fisc.fiscal_to;
                }
                if (typeof retVal == "string" && retVal == "$FIRSTDATEOFMONTH") {
                    retVal = new Date();
                    retVal.setDate(1);
                }
                if (typeof retVal == "string" && retVal == "$FIRSTDATEOFYEAR") {
                    retVal = fisc.fiscal_from//new Date();
                    // retVal.setDate(1);
                    // retVal.setMonth(1);

                }


                return retVal;
            }
            ,
            // this function should be executed before load data in localtabledata model.
            applyCols: function (grp, qv, frag) {
                var cls = {
                    "TEXTFIELD": "sap.m.Input",
                    "DATEFIELD": "sap.m.DatePicker",
                    "DATETIMEFIELD": "sap.m.DateTimePicker",
                    "TIMEFIELD": "sap.m.TimePicker",
                    "COMBOBOX": "sap.m.ComboBox",
                    "CHECKBOX": "sap.m.CheckBox",
                    // "SEARCHFIELD": "SearchText",
                    "SEARCHFIELD": "sap.m.Input",
                    "LABLE": "sap.m.Label",
                    "ICON": "sap.ui.core.Icon"
                };
                var aligns = {
                    "ALIGN_LEFT": "left",
                    "ALIGN_RIGHT": "right",
                    "ALIGN_CENTER": "center"
                };

                var visibleCol = [], invisibleCol = []; // visible and invisible column to arrange first visible and then invisible in localtabledata
                var sqlStr = "select *from cp_setcols where profile=0 and setgrpcode='" + grp + "'  order by POSITION"
                var dat = Util.execSQL(sqlStr);
                if (dat.ret == "SUCCESS") {
                    var dtx = JSON.parse("{" + dat.data + "}").data;
                    //invisible all columns first and then only visible which is available.
                    for (var col in qv.mLctb.cols)
                        qv.mLctb.cols[col].mHideCol = true;
                    for (var col in dtx) {
                        var cx = qv.mLctb.getColByName(dtx[col].ITEM_NAME);
                        if (cx == undefined)
                            FormView.err("Not found column ! " + dtx[col].ITEM_NAME);
                        if (dtx[col].DISPLAY_TYPE != "INVISIBLE") {
                            cx.mHideCol = false;
                            visibleCol.push(cx);
                        }
                        cx.mEnabled = dtx[col].DISPLAY_TYPE == "DISABLED" ? false : true;
                        cx.mColClass = Util.nvl(cls[dtx[col].EDITOR_CLASS], "sap.m.Text");
                        cx.mUIHelper.display_align = Util.nvl(aligns[dtx[col].ALIGN], "center");
                        cx.mUIHelper.display_format = Util.nvl(dtx[col].USE_FORMAT, "");
                        cx.mUIHelper.display_width = Util.nvl(dtx[col].DISPLAY_WIDTH, "30");
                        cx.mUIHelper.display_style = Util.nvl(dtx[col].OTHER_STYLES, "");
                        cx.mTitle = Util.nvl(dtx[col].DESCR, dtx[col].ITEM_NAME);
                        cx.mSearchSQL = Util.nvl(dtx[col].LOV_SQL, "");
                        cx.mLookUpCols = Util.nvl(dtx[col].LOOKUP_COLUMN, "");
                        cx.mRetValues = Util.nvl(dtx[col].RETURN_VALUES, "");
                        cx.eOther = Util.nvl(dtx[col].VALIDATE_EVENT, "");
                        cx.mDefaultValue = Util.nvl(UtilGen.parseDefaultValue(dtx[col].DEFAULT_VALUE), '');

                        var paras = Util.nvl(dtx[col].PARAMS, "");
                        if (paras != "") {
                            var ps = paras.split(",");
                            for (var pi in ps) {
                                var p1 = ps[pi].split("=");
                                if (p1[0] == "parent")
                                    cx.mSearchColParent = p1[1];
                                if (p1[0] == "code")
                                    cx.mSearchColCode = p1[1];
                                if (p1[0] == "title")
                                    cx.mSearchColTitle = p1[1];
                                if (p1[0] == "childcount")
                                    cx.mSearchColChildCount = p1[1];
                            }
                        }

                        if (cx.eValidateColumn != undefined) {

                        }

                        if (cx.eOther != undefined && (cx.eOther.length > 0 || cx.whenValidate != undefined)) {
                            cx.eValidateColumn = function (evtx) {

                                var sett = sap.ui.getCore().getModel("settings").getData();
                                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);
                                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                                var qf = new DecimalFormat(sett["FORMAT_QTY_1"]);
                                var row = evtx.getSource().getParent();
                                var column_no = evtx.getSource().getParent().indexOfCell(evtx.getSource());
                                var columns = evtx.getSource().getParent().getParent().getColumns();
                                var table = evtx.getSource().getParent().getParent(); // get table control.
                                var oModel = table.getModel();
                                var rowStart = table.getFirstVisibleRow(); //starting Row index
                                var currentRowoIndexContext = table.getContextByIndex(rowStart + table.indexOfRow(row));
                                var newValue = evtx.getSource().getValue();//evtx.getParameter("value");

                                var tm = -1;
                                var clx = -1;
                                for (clx in columns) {
                                    if (columns[clx].getVisible()) tm++;
                                    if (tm == column_no) {
                                        break;
                                    }
                                }
                                if (clx < 0) return;
                                var cx = columns[clx].tableCol;
                                if (Util.nvl(cx.eOther, "") != "") {
                                    var evl = cx.eOther.replace(/:newValue/g, "\"'" + newValue + "'\"");
                                    evl = evl.replace(/:nwValue/g, "\"" + newValue + "\"");

                                    if (!eval(evl))
                                        evtx.getSource().focus();
                                    else table.fireRowsUpdated();
                                }
                                if (cx.whenValidate != undefined)
                                    if (!cx.whenValidate(table, currentRowoIndexContext, cx, table.indexOfRow(row), column_no)) {
                                        evtx.getSource().focus();
                                        FormView.err('');
                                    }
                                    else table.fireRowsUpdated();

                                if (cx.eventCalc != undefined)
                                    if (!cx.eventCalc(qv, cx, table.indexOfRow(row), true))
                                        evtx.getSource().focus();

                            }

                        }
                        if (cx.mSearchSQL.length > 0) {
                            cx.eOnSearch = function (evtx) {
                                var tbl = evtx.getSource().getParent().getParent(); // get table control.
                                var input = evtx.getSource();
                                if ((evtx.getParameters != undefined)
                                    && (evtx.getParameters().clearButtonPressed || evtx.getParameters().refreshButtonPressed)) {
                                    return;
                                }
                                //// get visible column no
                                var clno = evtx.getSource().getParent().indexOfCell(evtx.getSource());
                                var cls = evtx.getSource().getParent().getParent().getColumns();
                                var tm = -1;
                                var clx = -1;
                                for (clx in cls) {
                                    if (cls[clx].getVisible()) tm++;
                                    if (tm == clno) {
                                        break;
                                    }
                                }
                                if (clx < 0) return;
                                var cx = cls[clx].tableCol;
                                //// end getting visible column no

                                var row = evtx.getSource().getParent();
                                var table = evtx.getSource().getParent().getParent(); // get table control.
                                var column_no = evtx.getSource().getParent().indexOfCell(evtx.getSource());
                                var sq = cx.mSearchSQL;
                                var lk = Util.nvl(cx.mLookUpCols, "").split(",");
                                var rt = Util.nvl(cx.mRetValues, "").split(",");

                                var oModel = tbl.getModel();
                                var rowStart = tbl.getFirstVisibleRow();
                                var currentRowoIndexContext = tbl.getContextByIndex(rowStart + tbl.indexOfRow(row));

                                if (cx.beforeSearchEvent != undefined) {
                                    // var oModel = tbl.getModel();
                                    // var rowStart = tbl.getFirstVisibleRow();
                                    // var currentRowoIndexContext = tbl.getContextByIndex(rowStart + tbl.indexOfRow(row));
                                    oModel.setProperty(currentRowoIndexContext.sPath + "/" + cx.mColName, evtx.getSource().getValue(), undefined, true);
                                    sq = cx.beforeSearchEvent(sq, currentRowoIndexContext, oModel);
                                }
                                var pms = {
                                    parent: cx.mSearchColParent,
                                    code: cx.mSearchColCode,
                                    title: cx.mSearchColTitle,
                                };
                                var bv = Util.extractBindVariables(sq);
                                for (var bi in bv) {
                                    var vl = Util.getCellColValue(tbl, rowStart + tbl.indexOfRow(row), bv[bi], true, tbl.indexOfRow(row));
                                    // if (vl.indexOf("%") < 0)
                                    //     vl = "%" + vl + "%";
                                    sq = sq.replaceAll(":" + bv[bi], Util.nvl(vl, ""));
                                }
                                Util.show_list(sq, lk, rt, function (data) {
                                    // console.log(data);

                                    if (rt.length == 0)
                                        return;
                                    var oModel = tbl.getModel();
                                    var rowStart = tbl.getFirstVisibleRow(); //starting Row index
                                    var currentRowoIndexContext = tbl.getContextByIndex(rowStart + tbl.indexOfRow(row));
                                    if (cx.onSearchSelection != undefined) {
                                        var oModel = tbl.getModel();
                                        var currentRowoIndexContext = tbl.getContextByIndex(rowStart + tbl.indexOfRow(row));
                                        if (!cx.onSearchSelection(currentRowoIndexContext, oModel, data)) {
                                            // sap.m.MessageToast.show("Invalid selection !");
                                            return false;
                                        }
                                    }
                                    for (var i in rt) {
                                        var rts = rt[i].split("=");
                                        oModel.setProperty(currentRowoIndexContext.sPath + "/" + rts[0], data[rts[1]], undefined, true);
                                        if (cx.mColName == rts[0])
                                            input.fireChange({ value: data[rts[1]] });

                                        if (cx.whenValidate != undefined)
                                            if (!cx.whenValidate(table, currentRowoIndexContext, cx, table.indexOfRow(row), column_no))
                                                try {
                                                    evtx.getSource().focus();
                                                }
                                                catch (e) {
                                                    console.log(e);
                                                }


                                        if (cx.eventCalc != undefined)
                                            if (!cx.eventCalc(qv, cx, table.indexOfRow(row), true))
                                                try {
                                                    evtx.getSource().focus();
                                                }
                                                catch (e) {
                                                    console.log(e);
                                                }

                                    }
                                    return true;
                                }, "100%", "100%", undefined, false, undefined, pms, undefined, undefined, undefined, cx.btnsx, cx.listPara
                                );

                            }
                                ;
                        }
                    }
                    for (var col in qv.mLctb.cols)
                        if (qv.mLctb.cols[col].mHideCol)
                            invisibleCol.push(qv.mLctb.cols[col]);
                    qv.mLctb.cols = [];
                    for (var i in visibleCol) {
                        visibleCol[i].mColpos = parseInt(i) + 1;
                        qv.mLctb.cols.push(visibleCol[i]);
                    }
                    var tr = qv.mLctb.cols.length - 1;
                    for (var i in invisibleCol) {
                        invisibleCol[i].mColpos = tr + parseInt(i) + 1;
                        qv.mLctb.cols.push(invisibleCol[i]);
                    }
                }

            }
            ,
            getInsertRowString: function (mLctb, tblName, rowno, excludeCols, colValues, onlyVisibleCol) {
                var ov = Util.nvl(onlyVisibleCol, false);
                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);

                var sq1 = "insert into " + tblName;
                var sq2 = "";
                var sq3 = "";
                for (var c in mLctb.cols) {
                    // only add to insert which is visible but even if hidden but added in colValues then add it.
                    if (ov && mLctb.cols[c].mHideCol && !Util.nvl(colValues, []).hasOwnProperty(mLctb.cols[c].mColName))
                        continue;
                    var val = Util.nvl(mLctb.getFieldValue(rowno, mLctb.cols[c].mColName), "");
                    // if any value to be override by colValues object
                    if (colValues != undefined && colValues.hasOwnProperty(mLctb.cols[c].mColName))
                        val = colValues[mLctb.cols[c].mColName];

                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1)
                        sq2 += (sq2.length > 0 ? "," : "") + mLctb.cols[c].mColName;
                    if (mLctb.cols[c].getMUIHelper().display_format == "SHORT_DATE_FORMAT") // if date then to_date() in sql
                        val = Util.toOraDateString(val);
                    else if (mLctb.cols[c].getMUIHelper().data_type == "DATE" && mLctb.cols[c].getMUIHelper().display_format != "SHORT_DATE_FORMAT")
                        try {
                            val = (val != "" ? Util.toOraDateTimeString(new Date(val)) : "");
                        } catch (er) {
                        }
                    else {
                        val = "'" + val + "'";
                    }
                    // if number then val variable should have number value to store in database.
                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1
                        && mLctb.cols[c].getMUIHelper().data_type == "NUMBER") {
                        if (colValues != undefined && colValues.hasOwnProperty(mLctb.cols[c].mColName))
                            val = (Util.nvl(Util.nvl(colValues[mLctb.cols[c].mColName], val), "") + "").replace(/[^\d\.],/g, '').replace(/,/g, '');
                        else
                            val = (Util.nvl(Util.nvl(mLctb.getFieldValue(rowno, mLctb.cols[c].mColName), val), "") + "").replace(/[^\d\.],/g, '').replace(/,/g, '');
                        var dfs = Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE");
                        var df;
                        if (Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE") == "QTY_FORMAT")
                            dfs = sett["FORMAT_QTY_1"];
                        if (Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE") == "MONEY_FORMAT")
                            dfs = sett["FORMAT_MONEY_1"];
                        if (dfs != "NONE") {
                            df = new DecimalFormat(dfs);
                            val = parseFloat(df.formatBack(val.replace(/'/g, '')))
                        }
                    }
                    // exclude col
                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1)
                        sq3 += (sq3.length > 0 ? "," : "") + Util.nvl(val, 'null');
                }
                for (var key in colValues)
                    if (mLctb.getColPos(key) < 0) {
                        sq2 += (sq2.length > 0 ? "," : "") + key;
                        sq3 += (sq3.length > 0 ? "," : "") + Util.nvl(colValues[key], 'null');
                    }

                sq3 = mLctb.parseColValues(sq3, rowno, sett);
                return sq1 + "(" + sq2 + ") values (" + sq3 + ")";

            },

            getUpdateRowString: function (mLctb, tblName, rowno, excludeCols, colValues, onlyVisibleCol) {
                var ov = Util.nvl(onlyVisibleCol, false);
                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);

                var sq1 = "update " + tblName + " set ";
                var sq2 = "";
                var sq3 = "";
                for (var c in mLctb.cols) {
                    // only add to insert which is visible but even if hidden but added in colValues then add it.
                    if (ov && mLctb.cols[c].mHideCol && !Util.nvl(colValues, []).hasOwnProperty(mLctb.cols[c].mColName))
                        continue;
                    var val = Util.nvl(mLctb.getFieldValue(rowno, mLctb.cols[c].mColName), "");
                    // if any value to be override by colValues object
                    if (colValues != undefined && colValues.hasOwnProperty(mLctb.cols[c].mColName))
                        val = colValues[mLctb.cols[c].mColName];

                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1)
                        sq2 += (sq2.length > 0 ? "," : "") + mLctb.cols[c].mColName;
                    if (mLctb.cols[c].getMUIHelper().display_format == "SHORT_DATE_FORMAT") // if date then to_date() in sql
                        val = Util.toOraDateString(val);
                    else if (mLctb.cols[c].getMUIHelper().data_type == "DATE" && mLctb.cols[c].getMUIHelper().display_format != "SHORT_DATE_FORMAT")
                        val = (val != "" ? Util.toOraDateTimeString(new Date(val)) : "");
                    else {
                        val = "'" + val + "'";
                    }
                    // if number then val variable should have number value to store in database.
                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1
                        && mLctb.cols[c].getMUIHelper().data_type == "NUMBER") {
                        if (colValues != undefined && colValues.hasOwnProperty(mLctb.cols[c].mColName))
                            val = (Util.nvl(Util.nvl(colValues[mLctb.cols[c].mColName], val), "") + "").replace(/[^\d\.],/g, '').replace(/,/g, '');
                        else
                            val = (Util.nvl(Util.nvl(mLctb.getFieldValue(rowno, mLctb.cols[c].mColName), val), "") + "").replace(/[^\d\.],/g, '').replace(/,/g, '');
                        var dfs = Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE");
                        var df;
                        if (Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE") == "QTY_FORMAT")
                            dfs = sett["FORMAT_QTY_1"];
                        if (Util.nvl(mLctb.cols[c].getMUIHelper().display_format, "NONE") == "MONEY_FORMAT")
                            dfs = sett["FORMAT_MONEY_1"];
                        if (dfs != "NONE") {
                            df = new DecimalFormat(dfs);
                            val = parseFloat(df.formatBack(val.replace(/'/g, '')))
                        }
                    }
                    // exclude col
                    if (excludeCols != undefined && excludeCols.indexOf(mLctb.cols[c].mColName) <= -1)
                        sq3 += (sq3.length > 0 ? "," : "") + Util.nvl(val, 'null');
                }
                for (var key in colValues)
                    if (mLctb.getColPos(key) < 0) {
                        sq2 += (sq2.length > 0 ? "," : "") + key + "=" + Util.nvl(colValues[key], 'null');
                        // sq3 += (sq3.length > 0 ? "," : "") + Util.nvl(colValues[key], 'null');
                    }


                return sq1 + "(" + sq2 + " where " + w;

            }
            ,
            getInsertRowStringByObj: function (tblName, colValues) {
                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);

                var sq1 = "insert into " + tblName;
                var sq2 = "";
                var sq3 = "";

                for (var key in colValues) {
                    // if (mLctb.getColPos(key) < 0) {
                    sq2 += (sq2.length > 0 ? "," : "") + key;
                    sq3 += (sq3.length > 0 ? "," : "") + Util.nvl(colValues[key], 'null');
                }
                // sq3 = mLctb.parseColValues(sq3, rowno, sett);
                return sq1 + "(" + sq2 + ") values (" + sq3 + ")";

            },
            getUpdateRowStringByObj: function (tblName, colValues, pWhere) {
                var sett = sap.ui.getCore().getModel("settings").getData();
                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);

                var sq1 = "update " + tblName + " ";
                var sq2 = "";
                var sq3 = "";

                for (var key in colValues)
                    sq2 += (sq2.length > 0 ? "," : "") + key + " = " + Util.nvl(colValues[key], 'null');

                return sq1 + " set " + sq2 + " where " + Util.nvl(pWhere, "");
            },

            showErrorNoVal: function (obj, msg) {
                var ob = [];
                var fnd = 0;
                var errobjs = [];
                if (!Array.isArray(obj))
                    ob = [obj];
                else ob = obj;
                for (var i in ob) {
                    var objj = ob[i];
                    if ((this.nvl(this.getControlValue(objj), "") + "").length == 0) {
                        fnd++;
                        errobjs.push(objj);
                    }
                }
                if (fnd > 0) {
                    // sap.m.MessageToast.show();
                    UtilGen.DashboardWidget.statusBarText(fnd + " Field(s)  must have value !", false, undefined, false);
                    setTimeout(function () {
                        for (var i in errobjs) {
                            errobjs[i].addStyleClass("errBack");
                        }
                        setTimeout(function () {
                            for (var i in errobjs)
                                errobjs[i].removeStyleClass("errBack");

                        }, 10000);
                    }, 100);
                }
                return fnd;
            },
            errorObj: function (obj, tm, doFocus) {
                setTimeout(function () {
                    obj.addStyleClass("errBack");
                    setTimeout(function () {
                        obj.removeStyleClass("errBack");
                        if (doFocus)
                            obj.focus();
                    }, Util.nvl(tm, 10000));
                }, 100);
            }
            ,
            openForm: function (frag, frm, ocAdd, view, app) {
                var oC = {};
                if (view != undefined)
                    oC = {
                        getView:
                            function () {
                                return view;
                            },
                        getForm: function () {
                            return frm;
                        }
                    };
                if (ocAdd != undefined)
                    for (var xx in ocAdd)
                        oC[xx] = ocAdd[xx];

                var sp = sap.ui.jsfragment(frag, oC);
                if (app != undefined)
                    sp.app = app;

                return sp;
            }
            ,

            doSearch: function (event, sql, obj, fnAfter, tit, obj2) {
                if (event != undefined
                    && (event.getParameters().clearButtonPressed
                        || event.getParameters().refreshButtonPressed)) {
                    UtilGen.setControlValue(obj, "", "", true);
                    if (obj2 != undefined)
                        UtilGen.setControlValue(obj, "", "", true);
                    return;
                }

                Util.showSearchList(sql, "TITLE", "CODE", function (valx, val) {
                    if (obj2 == undefined)
                        UtilGen.setControlValue(obj, val, valx, true);
                    else {
                        UtilGen.setControlValue(obj, valx, valx, true);
                        UtilGen.setControlValue(obj2, val, val, true);
                    }
                    if (fnAfter != undefined)
                        fnAfter();
                }, tit);

            }
            ,
            editableContent: function (frm, b) {
                for (var i = 0; i < frm.getContent().length; i++) {
                    if (frm.getContent()[i] instanceof sap.m.InputBase)
                        frm.getContent()[i].setEditable(b);
                    if (frm.getContent()[i] instanceof sap.m.SearchField)
                        frm.getContent()[i].setEnabled(b);

                }
            }
            ,
            setFormDisableForEditing: function (frm) {
                var cnts = frm.getContent();
                for (var i in cnts) {
                    if (cnts[i] instanceof sap.m.InputBase)
                        cnts[i].setEditable(false);
                    if (cnts[i] instanceof sap.m.SearchField)
                        cnts[i].setEnabled(false);
                    if (cnts[i] instanceof sap.m.CheckBox)
                        cnts[i].setEditable(false);
                    if (cnts[i] instanceof sap.m.ComboBox)
                        cnts[i].setEditable(false);

                }

            }
            ,

            execCmd: function (txt, view, obj, pg1, pOnWndClose) {

                if (txt == "")
                    return;
                var txt2 = (Util.nvl(txt, "") + "").trim();
                var cm = txt2.split(" ")[0].toUpperCase();
                var pms = (txt2.indexOf(" ") <= -1 ? "" : txt2.substring(txt2.indexOf(" ") + 1).trim());
                // cmdData
                if (view != undefined && view.cmdData != undefined && view.cmdData.length > 0)
                    for (var i in view.cmdData)
                        if (view.cmdData[i].COMMAND.toUpperCase() == cm) {
                            var cmd = view.cmdData[i].EXEC_LINE;
                            cmd = cmd.replaceAll('**', ':');
                            cmd = cmd.replaceAll('*.', "'");
                            cmd = cmd.replaceAll(/\\n/g, '\n');
                            txt2 = cmd + (pms.length > 0 ? " " : "") + pms;

                        }
                if (txt2.toLowerCase().startsWith("main")) {
                    view.app.toDetail(view.pg, "slide");
                    return;
                }
                if (txt2.toLowerCase().startsWith("reload_menus")) {
                    view.loadData();
                    return;
                }
                if (txt2.toLowerCase().startsWith("execbatch")) {
                    view.execBatch(txt2);
                    return;
                }
                if (txt2.toLowerCase().startsWith("show_list")) {
                    view.show_list_cmd(txt2);
                    return;
                }
                if (txt2.toLowerCase().startsWith("alert")) {
                    Util.AlertSettings.cmdAlert(txt2);
                    return;
                }
                if (!txt2.startsWith("#") && !txt2.startsWith("http")) {
                    var tokens = txt2.split(" ");
                    var openNew = false;
                    var formnm = "";
                    var formtit = "";
                    for (var i in tokens) {
                        if (i == 0) {
                            formnm = tokens[i];
                            continue;
                        }
                        if (tokens[i].split("=")[0] == "formTitle")
                            formtit = tokens[i].split("=")[1];

                        if ((tokens[i].split("=")[0] == "openNew" && tokens[i].split("=")[1] == "true")
                            || (tokens[i].split("=")[0] == "formType" && tokens[i].split("=")[1].toLowerCase() != "page"))
                            openNew = true;

                    }
                    if (openNew)
                        UtilGen.cmdOpenForm(txt2, view, obj, pg1, pOnWndClose);
                    else {
                        if (UtilGen.getIndexByKey(view.lstPgs, formnm) != undefined || UtilGen.getIndexByKey(view.lstPgs, "bin.forms." + formnm) != undefined) {
                            if (formnm == UtilGen.getControlValue(view.lstPgs)) {
                                UtilGen.setControlValue(view.lstPgs, "main");
                                view.lstPgs.fireSelectionChange();
                                UtilGen.setControlValue(view.lstPgs, formnm);
                                view.lstPgs.fireSelectionChange();
                                return;
                            }
                            UtilGen.setControlValue(view.lstPgs, formnm);
                            view.lstPgs.fireSelectionChange();
                            /*
                            if (sap.m.MessageBox == undefined)
                                jQuery.sap.require("sap.m.MessageBox");
                            sap.m.MessageBox.confirm("Already form is opened, Open new " + Util.nvl(formtit, formnm) + " again ?  ", {
                                title: "Confirm",                                    // default
                                onClose: function (oAction) {
                                    if (oAction == sap.m.MessageBox.Action.YES) {
                                        UtilGen.cmdOpenForm(txt2, view, obj, pg1, pOnWndClose);
                                    }
                                    if (oAction == sap.m.MessageBox.Action.NO) {
                                        UtilGen.setControlValue(view.lstPgs, formnm);
                                        view.lstPgs.fireSelectionChange();
                                    }
                                },                                       // default
                                actions: [sap.m.MessageBox.Action.YES, sap.m.MessageBox.Action.NO],
                                emphasizedAction: sap.m.MessageBox.Action.NO,
                                styleClass: "",                                      // default
                                initialFocus: sap.m.MessageBox.Action.NO, // default
                                textDirection: sap.ui.core.TextDirection.Inherit     // default
                            });
                            */
                        } else
                            UtilGen.cmdOpenForm(txt2, view, obj, pg1, pOnWndClose);
                    }
                    return;
                }
            }
            ,
            cmdOpenForm: function (txt, view, obj, pg1, pOnWndClose) {
                var that = this;
                // var formName = "", formType = "popover", formSize = "100%,100%", formModal = "true";
                var dtx = { formName: "", formType: "popover", formSize: "100%,100%", formModal: "true" };
                var tokens = txt.split(" ");
                for (var i in tokens) {

                    if (i == 0) {
                        dtx["formName"] = tokens[i];
                        continue;
                    }
                    var tkn = tokens[i].split("=");
                    dtx[tkn[0]] = tkn[1];

                }
                // validate the command and setting default values .......
                // opening form
                var con = pg1;
                var dlg = undefined;
                if (pg1 == undefined && dtx.formType == "page")
                    dtx.formType = "dialog";

                if (dtx.formType == "dialog") {
                    var sp = dtx.formSize.split(",");
                    var width = "400px", height = "500px";
                    if (sp.length >= 1) width = sp[0];
                    if (sp.length >= 2) height = sp[1];
                    con = new sap.m.Page({ showHeader: false, content: [] });
                    dlg = new sap.m.Dialog({
                        title: Util.nvl(dtx.TILE_TITLE_1, ""),
                        content: con,
                        contentHeight: height,
                        contentWidth: width,
                    }).addStyleClass("sapUiSizeCompact");
                }
                if (dtx.formType == "popover") {
                    var sp = dtx.formSize.split(",");
                    var width = "400px", height = "500px";
                    if (sp.length >= 1) width = sp[0];
                    if (sp.length >= 2) height = sp[1];
                    con = new sap.m.Page({ showHeader: false, content: [] });
                    dlg = new sap.m.Popover({
                        title: "",
                        showTitle: false,
                        showHeader: false,
                        contentHeight: height,
                        contentWidth: width,
                        modal: (dtx.formModal == "true" ? true : false),
                        content: [con],
                        // footer: [hb],
                        placement: sap.m.PlacementType.Auto
                    }).addStyleClass("sapUiSizeCompact");
                }

                if (dtx.formType == "dialog" || dtx.formType == "page" || dtx.formType == "popover") {
                    var pms = {};
                    for (var i in dtx)
                        if (!(i == "formType" || i == "formName" || i == "formSize" || i == "formModal"))
                            pms[i] = dtx[i].replaceAll("%20", " ");


                    var sp = undefined;
                    try {
                        sp = UtilGen.openForm(dtx.formName, con, pms, view);
                    }
                    catch (err) {
                        console.log(err);
                        // err.message;throw
                    }


                    if (sp == undefined)
                        try {

                            sp = UtilGen.openForm("bin.forms." + dtx.formName, con, pms, view);
                        }
                        catch (err) {
                            // sap.m.MessageToast.show("Err ! opening form " + "bin.forms." + dtx.formName);
                            UtilGen.DashboardWidget.statusBarText("Err ! opening form " + "bin.forms." + dtx, true, undefined, true);
                            throw err;
                            return;
                        }

                    if (sp == undefined) {
                        // sap.m.MessageToast.show(dtx.formName + " fragment not found !");
                        UtilGen.DashboardWidget.statusBarText(dtx.formName + " fragment not found !", true, undefined, true);
                        return;
                    }
                    sp.backFunction = function () {
                        if (dlg != undefined) {
                            dlg.close();
                            // UtilGen.DBView.autoShowHideMenu(true);
                            return;
                        }
                        view.app.toDetail(view.pg, "show");
                        if (sp.onWndClose != undefined)
                            sp.onWndClose();
                        if (pOnWndClose != undefined)
                            pOnWndClose();
                        sp.destroy();
                        // that.loadData();
                        if (view.lstPgs.getItems().length == 1)
                            that.show_main_menus();
                    };
                    if (dtx.formType != "page") {
                        UtilGen.clearPage(con);
                        con.addContent(sp);

                    }
                    if (dtx.formType == "page") {
                        if (con instanceof sap.m.Page) {
                            UtilGen.clearPage(con);
                            con.addContent(sp);
                            view.app.toDetail(con, "slide");
                            sp.backFunction = function () {
                                view.destroyPage(con);
                                if (sp.onWndClose != undefined)
                                    sp.onWndClose();
                                if (pOnWndClose != undefined)
                                    pOnWndClose();
                                sp.destroy();
                                UtilGen.DashboardWidget.statusBarText("Removing this page..", false, undefined, true);
                                view.app.toDetail(view.pg, "show");
                                // view.loadData();
                                if (view.lstPgs.getItems().length == 1)
                                    view.loadData_main();
                                UtilGen.DBView.autoShowHideMenu(true, con);
                            };

                        }
                        if (typeof (con) == "function") {
                            var pgx = con(dtx);
                            if (pgx != undefined) {
                                UtilGen.clearPage(pgx);
                                pgx.addContent(sp);
                                view.app.toDetail(pgx, "slide");
                                sp.backFunction = function () {
                                    view.destroyPage(pgx);
                                    UtilGen.DashboardWidget.statusBarText("Removing this page..", false, undefined, true);
                                    sp.destroy();
                                    view.app.toDetail(view.pg, "show");
                                    // view.loadData();
                                    // if (view.lstPgs.getItems().length == 1) 
                                    //     view.loadData_main();
                                    UtilGen.DBView.autoShowHideMenu(true, pgx);
                                };
                            }
                            else {
                                // sap.m.MessageToast.show();
                                UtilGen.DashboardWidget.statusBarText(dtx.formName + " Can't open...!", true, undefined, true);
                                return;
                            }

                        }
                    }
                    else if (dtx.formType == "dialog") {
                        dlg.open();
                        dlg.attachBeforeClose(undefined, function () {

                            if (sp.onWndClose != undefined)
                                sp.onWndClose();
                            if (pOnWndClose != undefined)
                                pOnWndClose();
                            sp.destroy();
                            // UtilGen.DBView.autoShowHideMenu(true);
                        })
                    }
                    else if (dtx.formType == "popover") {
                        dlg.openBy(obj);
                        dlg.attachBeforeClose(undefined, function () {

                            if (sp.onWndClose != undefined)
                                sp.onWndClose();
                            if (pOnWndClose != undefined)
                                pOnWndClose();
                            // UtilGen.DBView.autoShowHideMenu(true);
                        })

                    }
                }
            }
            ,
            addDelRowCmd: function (qv, fnAfterAdd, fnAfterDel
            ) {
                var vb = new sap.m.HBox({
                    items: [
                        new sap.m.Button({
                            icon: "sap-icon://add", press: function () {
                                qv.addRow();
                                if (fnAfterAdd)
                                    fnAfterAdd();
                            }
                        }),
                        new sap.m.Button({
                            icon: "sap-icon://sys-minus", press: function () {
                                if (that.qv.getControl().getSelectedIndices().length == 0) {
                                    sap.m.MessageToast.show("Select a row to delete. !");
                                    return;
                                }

                                var r = that.qv.getControl().getSelectedIndices()[0] + that.qv.getControl().getFirstVisibleRow();
                                qv.deleteRow(r);
                                if (fnAfterDel)
                                    fnAfterDel(false);
                                // that.do_summary(false);

                            }
                        })
                    ]
                });
                return vb;
            },
            toHTMLTableFromData: function (dtx11, pexcCols, fnHeaderAdd, fnDetailAdd) {
                var h = "";
                var hasSpan = false;
                var tmpv1 = "", tmpv2 = "", hCol = "", classadd = "", styleadd = "";
                var excCols = Util.nvl(pexcCols, []);
                var dtx = dtx11.data;
                var mdtx = dtx11.metadata;
                for (var x in mdtx) {
                    if (excCols.indexOf(mdtx[x].colname) > -1)
                        continue;

                    tmpv1 = mdtx[x].colname;
                    var tmp;
                    if (fnHeaderAdd != undefined)
                        tmp = fnHeaderAdd(tmpv1, tmpv2);

                    if (tmp != undefined) {
                        tmpv1 = Util.nvl(tmp.title, tmpv1);
                        tmpv2 = Util.nvl(tmp.prop, "\"text-align:Center\"");
                    }
                    // tmpv2 = "\"text-align:Center\"";
                    h += "<th " + tmpv2 + ">" + Util.htmlEntities(tmpv1) + "</th>";
                }
                hCol = "<tr>" + hCol + "</tr>";
                h = "<thead>" + (hasSpan ? hCol : "") +
                    "<tr>" + h + "</tr></thead>";
                var rs = "";
                var rows = "";
                for (var j in dtx) {
                    rs = "";
                    for (var x in mdtx) {
                        if (excCols.indexOf(mdtx[x].colname) > -1)
                            continue;
                        var tmp;
                        var cv = dtx[j][mdtx[x].colname];

                        if (fnDetailAdd != undefined)
                            tmp = fnDetailAdd(mdtx[x].colname, tmpv2, cv);

                        if (tmp != undefined) {
                            tmpv2 = Util.nvl(tmp.prop, "style=\"text-align:center\"");
                            cv = Util.nvl(tmp.val, cv);
                        }


                        rs += "<td " + tmpv2 + " > " + Util.nvl(Util.htmlEntities(cv), "") + "</td>";
                    }
                    rows += "<tr>" + rs + "</tr>";
                }

                return "<table class='fl-table'>" + h + rows + "</table>";
            },
            showWorking: function (wnd, pstr) {
                if ($('#content').parent().find('.sapMMessageToast').length == 0)
                    sap.m.MessageToast.show(Util.nvl(pstr + "..", "Working.."), {
                        duration: 9999999,
                        width: "15em",
                        my: "center top",
                        at: "top top",
                        of: this.nvl(wnd, window),
                        offset: "0 0",                    // default
                        collision: "fit fit",            // default
                        onClose: null,                   // default
                        autoClose: false,                 // default
                        animationTimingFunction: "ease", // default
                        animationDuration: 1000,         // default
                        closeOnBrowserNavigation: true   // default
                    });
                var oMessageToastDOM = $('#content').parent().find('.sapMMessageToast');
                oMessageToastDOM.css('color', "maroon");
                oMessageToastDOM.css('background-color', "#00a4eb");
            },
            showCustomMessageToast: function (msg, dispAfterdelay, textColor, backColor, fontSize, sett) {
                if (Util.nvl(dispAfterdelay, 0) > 0)
                    setTimeout(() => {
                        sap.m.MessageToast.show(Util.getLangText(msg), {
                            ...{
                            }, ...Util.nvl(sett, {})
                        });
                        var oMessageToastDOM = $('#content').parent().find('.sapMMessageToast');
                        oMessageToastDOM.css('color', Util.nvl(textColor, "#fff"));
                        oMessageToastDOM.css('background-color', Util.nvl(backColor, "#008080"));
                        oMessageToastDOM.css('font-size', Util.nvl(fontSize, "18px"));

                        setTimeout(function () {
                            $(".sapMMessageToast").css({
                                "width": "auto",
                                "max-width": "none",
                                "white-space": "normal",
                                "text-align": "left"
                            });
                        }, 10);
                        UtilGen.DashboardWidget.statusBarText(Util.getLangText(msg).substr(0, 200), false, undefined, false);
                    }, dispAfterdelay);
                else {
                    sap.m.MessageToast.show(Util.getLangText(msg), {
                        ...{
                        }, ...Util.nvl(sett, {})
                    });
                    var oMessageToastDOM = $('#content').parent().find('.sapMMessageToast');
                    oMessageToastDOM.css('color', Util.nvl(textColor, "#fff"));
                    oMessageToastDOM.css('background-color', Util.nvl(backColor, "#008080"));
                    oMessageToastDOM.css('font-size', Util.nvl(fontSize, "18px"));

                    setTimeout(function () {
                        $(".sapMMessageToast").css({
                            "width": "auto",
                            "max-width": "none",
                            "white-space": "normal",
                            "text-align": "left"
                        });
                    }, 10);
                    UtilGen.DashboardWidget.statusBarText(Util.getLangText(msg).substr(0, 200), false, undefined, false);
                }

            },
            closeWorking: function (wndx) {
                var wnd = Util.nvl(wndx, window);
                var oMessageToastDOM = $('#content').parent().find('.sapMMessageToast');
                for (var i = 0; i < oMessageToastDOM.length; i++) {
                    if (this.nvl(oMessageToastDOM[i].innerText, "").endsWith(".."))
                        oMessageToastDOM[i].remove();
                }
            },
            dispTblRecsByDevice: function (dispRecs) {
                if (typeof dispRecs == "object") {
                    var newr = "L";
                    if (sap.ui.Device.resize.height <= 639)
                        newr = "S";
                    if (sap.ui.Device.resize.height > 640 && sap.ui.Device.resize.height <= 768)
                        newr = "M";
                    if (sap.ui.Device.resize.height > 769 && sap.ui.Device.resize.height <= 888)
                        newr = "L";
                    if (sap.ui.Device.resize.height > 889 && sap.ui.Device.resize.height <= 1080)
                        newr = "XL";
                    if (sap.ui.Device.resize.height > 1080)
                        newr = "XXL";
                    console.log("DEVICE " + newr + " -height=" + sap.ui.Device.resize.height + " records=" + dispRecs[newr]);
                    return dispRecs[newr];
                } else return dispRecs;

            },
            dispWidthByDevice: function (dispRecs) {
                if (typeof dispRecs == "object") {
                    var newr = "L";
                    if (sap.ui.Device.resize.width <= 639)
                        newr = "S";
                    if (sap.ui.Device.resize.width > 640 && sap.ui.Device.resize.width <= 1007)
                        newr = "M";
                    if (sap.ui.Device.resize.width > 1007)
                        newr = "L";
                    console.log("dispWidthByDevice " + newr + " -width=" + sap.ui.Device.resize.width + " width=" + dispRecs[newr]);
                    return dispRecs[newr];
                } else return dispRecs;

            },
            Search: {
                do_quick_search: function (e, control, pSq, pSqGetTitle, titObj, eventAfterSelect, pPoints, btns, pMulteSelect, pListPara, titDialog) {
                    var points = Util.nvl(pPoints, {});
                    // if (e.getParameters().clearButtonPressed || e.getParameters().refreshButtonPressed) {
                    UtilGen.setControlValue(control, "", "", false);
                    //     if (titObj != undefined)
                    //         UtilGen.setControlValue(titObj, "", "", false);
                    //     return;
                    // }
                    // var control = this;
                    var sq = pSq;
                    var multiSelect = Util.nvl(pMulteSelect, false);
                    Util.show_list(sq, ["CODE", "TITLE", "NAME"], "", function (data) {
                        var code = "";
                        if (multiSelect) {
                            for (var li = 0; li < data.length; li++)
                                code += "\"" + data[li].CODE + "\"";
                        } else
                            code = data.CODE;

                        UtilGen.setControlValue(control, code, code, true);
                        if (titObj != undefined)
                            UtilGen.setControlValue(titObj, data.TITLE, data.TITLE, true);
                        // else 
                        // {
                        //     UtilGen.setControlValue(control, data.CODE, data.CODE, false);
                        //     UtilGen.setControlValue(titObj, data.TITLE, data.TITLE, false);
                        // }
                        if (!multiSelect) {
                            var vldtt = Util.execSQL(pSqGetTitle.replaceAll(":CODE", Util.quoted(data.CODE)));
                            if (vldtt.ret != "SUCCESS") {
                                UtilGen.setControlValue(control, "", "", false);
                                if (titObj != undefined)
                                    UtilGen.setControlValue(titObj, "", "", false);
                                return;
                            }
                            var vldt = JSON.parse("{" + vldtt.data + "}").data;
                            var acn = vldt[0].CODE;
                            var nm = vldt[0].TITLE;

                            if (titObj == undefined)
                                UtilGen.setControlValue(control, acn, acn, true);
                            else {
                                UtilGen.setControlValue(control, acn, acn, true);
                                UtilGen.setControlValue(titObj, nm, nm, false);
                            }
                        }
                        if (eventAfterSelect != undefined)
                            eventAfterSelect(acn, nm);
                        return true;
                    }, points.pWidth, points.pHeight, undefined, multiSelect, undefined, undefined, undefined, undefined, pPoints, btns, pListPara, titDialog);

                },

                do_quick_search_simple: function (pSq, cols, eventAfterSelect, pPoints, btns, pMultiSelect, titleDlg, jsCmds) {
                    var points = Util.nvl(pPoints, {});
                    var sq = pSq;
                    var multiSelect = Util.nvl(pMultiSelect, false);
                    Util.show_list(sq, Util.nvl(cols, []), "", function (data) {
                        if (eventAfterSelect != undefined)
                            eventAfterSelect(data);
                        return true;
                    }, points.pWidth, points.pHeight, undefined, multiSelect, undefined, undefined, undefined, jsCmds, pPoints, btns, undefined, titleDlg);



                },
                getLOVSearchField: function (sql, control, nullValid, titObj) {
                    var vl = control.getValue();

                    if (Util.nvl(nullValid, true) && Util.nvl(vl, "") == "") {
                        if (titObj != undefined)
                            UtilGen.setControlValue(titObj, "", "", false);
                        return;
                    }

                    var nm = Util.getSQLValue(sql.replaceAll(":CODE", vl));
                    if (titObj == undefined)
                        UtilGen.setControlValue(control, vl + "-" + nm, vl, false);
                    else {
                        UtilGen.setControlValue(control, vl, vl, false);
                        UtilGen.setControlValue(titObj, nm, nm, false);

                    }
                    if (Util.nvl(nm, "") == "" &&
                        typeof control.focus != "undefined" && typeof control.setValue != "undefined")
                        setTimeout(() => { control.setValue(""); control.focus(); }, 150);

                }
            },
            Vouchers: {
                // validate for rv,pv,pvc,rvc
                onCellRender: function (qry, rowno, colno, currentRowContext) {
                    var clno = UtilGen.getTableColNo(qry.obj.getControl(), "ACCNO");
                    if ((qry.status == "edit" || qry.status == "new") && qry.name == "qry2" && colno == clno) {
                        var oModel = qry.obj.getControl().getModel();
                        var cellVal = oModel.getProperty("CUST_CODE", currentRowContext);
                        // var clno = UtilGen.getTableColNo(qry.obj.getControl(), "ACCNO");
                        qry.obj.getControl().getRows()[rowno].getCells()[colno].setEnabled(true);
                        if (Util.nvl(cellVal, "") != "")
                            qry.obj.getControl().getRows()[rowno].getCells()[colno].setEnabled(false);
                    }
                },
                validatePostedVocher: function (qry, sqlRow, rn) {
                    var kf = qry.formview.getFieldValue("keyfld");
                    var dt = Util.execSQL("select flag from acvoucher1 where keyfld=" + kf);
                    if (dt.ret == "SUCCESS" && dt.data.length > 0) {
                        var dtx = JSON.parse("{" + dt.data + "}").data;
                        if (dtx.length > 0 && dtx[0].FLAG != undefined && dtx[0].FLAG != 1) {
                            qry.formview.setFormReadOnly();
                            FormView.err("This voucher is posted !");
                        }


                    }

                },
                validateTotDrTotCr: function (qry, sqlRow, rn) {
                    var totcr = qry.formview.getFieldValue("totalcredit");
                    var totdr = qry.formview.getFieldValue("totaldebit");
                    if (totcr != undefined && totcr < 0)
                        FormView.err("Total CREDIT cant be less than zero !");
                    if (totcr != undefined && totcr == 0)
                        FormView.err("Total Credit cant be zero !");
                    if (totdr != undefined && totdr < 0)
                        FormView.err("Total DEBIT cant be less than zero !");
                    if (totdr != undefined && totdr == 0)
                        FormView.err("Total DEBIT cant be zero !");
                    if (totdr != undefined && totcr != undefined && totdr != totcr)
                        FormView.err("Total DEBIT and CREDIT is not matched !");

                },
                validateFieldsBeforeSave: function (qry, sqlRow, rn) {


                    var cc = qry.formview.getFieldValue("qry1.costcent");
                    var cd = qry.formview.getFieldValue("qry1.code");
                    var sm = qry.formview.getFieldValue("qry1.slsmn");

                    if (Util.nvl(cc, "") != "") {
                        var dt = Util.getSQLValue("select code from accostcent1 where code=" + Util.quoted(cc));
                        if (Util.nvl(dt, "") == "") {
                            UtilGen.errorObj(qry.formview.objs["qry1.costcent"].obj);
                            FormView.err("Cost center not found !");
                        }
                    }
                    if (Util.nvl(sm, "") != "") {
                        var dt = Util.getSQLValue("select no from salesp where no=" + Util.quoted(sm));
                        if (Util.nvl(dt, "") == "") {
                            UtilGen.errorObj(qry.formview.objs["qry1.slsmn"].obj);
                            FormView.err("Sales man not valid !");
                        }
                    }

                    if (Util.nvl(cd, "") != "") {
                        var dt = Util.getSQLValue("select accno from acaccount where childcount=0 and flag=1 and accno=" + Util.quoted(cd));
                        if (Util.nvl(dt, "") == "") {
                            UtilGen.errorObj(qry.formview.objs["qry1.code"].obj);
                            FormView.err("Bank/cash not valid !");
                        }
                    }


                },
                getNewKF: function (qry, sqlRow, rn) {
                    if (qry.name == "qry1" && qry.status == FormView.RecordStatus.NEW) {
                        var kfld = Util.getSQLValue("select nvl(max(keyfld),0)+1 from acvoucher1");
                        qry.formview.setFieldValue("qry1.keyfld", kfld, kfld, true);
                        qry.formview.setFieldValue("pac", qry.formview.getFieldValue("keyfld"));
                    }
                },
                validateDetails: function (qry, sqlRow, rowno) {
                    if (qry.name == "qry2") {
                        var ld = qry.obj.mLctb;
                        var chld = Util.getSQLValue("select childcount from acaccount where accno=" + Util.quoted(ld.getFieldValue(rowno, "ACCNO")));
                        if (chld == undefined || (typeof chld == "string" && chld == "") || chld > 0)
                            FormView.err(ld.getFieldValue(rowno, "ACCNO") + " not a valid a/c ! , row no # " + rowno);

                        if (Util.nvl(ld.getFieldValue(rowno, "COSTCENT"), "") != "") {
                            var chld = Util.getSQLValue("select code from accostcent1 where CODE=" + Util.quoted(ld.getFieldValue(rowno, "COSTCENT")));
                            if (chld == undefined || (typeof chld == "string" && chld == ""))
                                FormView.err(ld.getFieldValue(rowno, "COSTCENT") + " not a valid COST CENTER ! ");
                        }
                    }
                },
                getInsertLogFuncStr: function (frag, grpname, vou_code, type, tablename, pNotify) {
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var frm = frag.frm;
                    var kf = frm.getFieldValue("keyfld");
                    var insq = "";
                    if (frag.qryAccs == undefined) return "";
                    var getSq = function () {
                        var sqx = "c7_insert_log_proc(':GRPNAME'," +
                            "':USERNAME',':TABLENAME',':REC_STAT',':GRPNAME'||' # '||:JVNO||' :REC_STAT '" +
                            ",:KEYFLD,':PVAR2',:JVNO,':PVAR4',':PVAR5',':NOTIFY_TYPE'); ";
                        sqx = sqx.replaceAll(":REC_STAT", stat)
                            .replaceAll(":USERNAME", sett["LOGON_USER"])
                            .replaceAll(":GRPNAME", Util.nvl(grpname, "JV"))
                            .replaceAll(":JVNO", vono)
                            .replaceAll(":KEYFLD", kfld)
                            .replaceAll(":PVAR2", pv2)
                            .replaceAll(":PVAR4", pv4)
                            .replaceAll(":PVAR5", pv5)
                            .replaceAll(":TABLENAME", Util.nvl(tablename, "ACVOUCHER1"))
                            .replaceAll(":NOTIFY_TYPE", Util.nvl(notifyType, ""));
                        return sqx;
                    }

                    var stat = frm.objs["qry1"].status != FormView.RecordStatus.EDIT ?
                        "INSERTED" : "UPDATED";
                    stat = Util.nvl(pNotify, stat);
                    var notifyType = grpname + "_" + stat;
                    var vono = frm.getFieldValue("qry1.no");
                    var kfld = frm.getFieldValue("qry1.keyfld");
                    var pv5 = "";
                    var pv4 = "";
                    var pv2 = "VOU_CODE=" + vou_code + ",TYPE=" + type;
                    insq = getSq();


                    // checking other JV_KF_UPDATED, JV_KF_INSERTED, JV_KF_DELETED for notifications
                    var styp = "JV_KF_" + stat;
                    var sqN = "select *from C7_NOTIFY_SETUP where usernm='" + sett["LOGON_USER"] + "' and setup_type='" + styp + "' and CONDITION_STR='" + kfld + "'";
                    var dtx = Util.execSQLWithData(sqN);
                    if (dtx != undefined && dtx.length > 0) {
                        notifyType = styp;
                        pv2 = kfld;
                        var sq = getSq();
                        insq += sq;
                    }
                    insq = frm.parseString(insq);
                    // checking more if acc transaction                   
                    styp = "ACC_TRANS";
                    var sqN = "select  *from C7_NOTIFY_SETUP where usernm='" + sett["LOGON_USER"] + "' and setup_type='" + styp + "' and ':ACCNO' like '%\"'||CONDITION_STR||'\"%' ";
                    var qr2 = frm.objs["qry2"].obj;
                    var ld = qr2.mLctb;
                    for (var i = 0; i < ld.rows.length; i++)
                        frag.qryAccs[ld.getFieldValue(i, "ACCNO")] = ld.getFieldValue(i, "ACNAME");
                    var kys = Object.keys(frag.qryAccs);
                    var acns = "";
                    for (var k in kys)
                        acns += (acns.length > 0 ? "," : "") + "\"" + kys[k] + "\" ";
                    var dtx = Util.execSQLWithData(sqN.replaceAll(":ACCNO", acns));
                    for (var di = 0; di < dtx.length; di++) {
                        notifyType = styp;
                        pv2 = dtx[0].CONDITION_STR;
                        pv4 = frag.qryAccs[dtx[0].CONDITION_STR];
                        var sq = getSq();
                        insq += sq;
                    }
                    return insq;
                },
                formLoadData: function (frag) {

                    frag.oController.status = Util.nvl(frag.oController.status, 'new');
                    frag.frm.readonly = Util.nvl(frag.oController.readonly, false);

                    if (frag.frm.readonly)
                        frag.oController.status = "view";


                    if (frag.oController.nolist)
                        frag.frm.cmdButtons.cmdList.setVisible(false);

                    if (frag.oController.readonly) {
                        frag.frm.cmdButtons.cmdNew.setVisible(false);
                        frag.frm.cmdButtons.cmdEdit.setVisible(false);
                        frag.frm.cmdButtons.cmdDel.setVisible(false);
                        frag.frm.cmdButtons.cmdSave.setVisible(false);
                    }

                    if (frag.oController.status != FormView.RecordStatus.NEW) {
                        frag.frm.setFieldValue('pac', Util.nvl(frag.oController.keyfld), "");
                        frag.frm.setQueryStatus(undefined, frag.oController.status);
                    } else {
                        frag.frm.setFieldValue('pac', Util.nvl(frag.qryStr), "");
                        frag.frm.setQueryStatus(undefined, Util.nvl(frag.oController.status, FormView.RecordStatus.NEW));
                    }
                    if (frag.qryStr != "")
                        frag.frm.loadData(undefined, frag.oController.status);

                },
                copyDataFromVou: function (data, qrj, vars) {
                    if (data == null || data == undefined || data.length <= 0)
                        return false;
                    if (qrj.getControl().view.objs["qry1"].status != FormView.RecordStatus.NEW && qrj.getControl().view.objs["qry1"].status != FormView.RecordStatus.EDIT) {
                        sap.m.MessageToast.show("Not in new / edit mode !");
                        return;
                    }
                    for (var d in data) {
                        var dat = Util.execSQL("select V.ACCNO,V.FCDEBIT,V.FCCREDIT,V.DEBIT,V.CREDIT,A.NAME ACNAME,DESCR from ACVOUCHER2 V,ACACCOUNT A where A.ACCNO=V.ACCNO AND  V.keyfld=" + data[d].KEYFLD + " order by pos");
                        if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                            var dtx = JSON.parse("{" + dat.data + "}").data;
                            for (var i in dtx) {
                                if (vars.vou_code == 2 && dtx[i].DEBIT > 0)
                                    continue;
                                if (vars.vou_code == 3 && dtx[i].CREDIT > 0)
                                    continue;
                                var r = qrj.mLctb.rows.length - 1;
                                if (Util.nvl(qrj.mLctb.getFieldValue(qrj.mLctb.rows.length - 1, "ACCNO"), "") != "")
                                    r = qrj.mLctb.addRow();
                                qrj.mLctb.setFieldValue(r, "POS", r + 1);
                                qrj.mLctb.setFieldValue(r, "ACCNO", dtx[i].ACCNO);
                                qrj.mLctb.setFieldValue(r, "FCDEBIT", dtx[i].FCDEBIT);
                                qrj.mLctb.setFieldValue(r, "FCCREDIT", dtx[i].FCCREDIT);
                                qrj.mLctb.setFieldValue(r, "DEBIT", dtx[i].DEBIT);
                                qrj.mLctb.setFieldValue(r, "CREDIT", dtx[i].CREDIT);
                                qrj.mLctb.setFieldValue(r, "DESCR2", dtx[i].ACNAME);
                                qrj.mLctb.setFieldValue(r, "ACNAME", dtx[i].ACNAME);
                                qrj.mLctb.setFieldValue(r, "DESCR", qrj.getControl().view.objs["qry1.descr"].obj.getValue());

                            }
                        }
                    }
                    qrj.updateDataToControl();
                    qrj.eventCalc(qrj, undefined, -1, false);
                },
                before_add_table: function (scrollObjs, qrj, vars) {
                    var that = this;
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                    qrj.showToolbar.showSearch = false;
                    qrj.showToolbar.showFilter = false;
                    qrj.showToolbar.showGroupFilter = false;
                    qrj.showToolbar.showPersonalization = false;
                    qrj.showToolbar.showNewWnd = true;
                    qrj.createToolbar("", [],
                        // EVENT ON APPLY PERSONALIZATION
                        function (prsn, qv) {
                        },
                        // EVENT ON REVERT PERSONALIZATION TO ORIGINAL
                        function (qv) {
                        }
                    );
                    var txt = new sap.m.Input({ width: "100px" });
                    var btf = new sap.m.Button({
                        icon: "sap-icon://sys-find",
                        tooltip: "click to find next..",
                        press: function () {
                            var bi = 0;
                            if (qrj.getControl().getSelectedIndices().length > 0) {
                                bi = qrj.getControl().getSelectedIndices()[0] + 1;
                            }
                            var rn = qrj.mLctb.findAny(["CUST_CODE", "DESCR", "DESCR2", "ACCNO", "COSTCENT"], txt.getValue(), bi);
                            if (rn < 0) {
                                qrj.getControl().setSelectedIndex(-1);
                                return;
                            }
                            qrj.getControl().setSelectedIndex(rn);
                            if (rn > 1) {
                                qrj.getControl().setFirstVisibleRow(rn - 1);
                            } else
                                qrj.getControl().setFirstVisibleRow(rn);
                        }
                    });
                    var btDelRow = new sap.m.Button({
                        icon: "sap-icon://sys-minus",
                        tooltip: "select and delete a row ",
                    });
                    btDelRow.attachBrowserEvent("mousedown", function () {

                        var rowno = -1;
                        var colno = -1;
                        if (qrj.getControl().getSelectedIndices().length == 0) {
                            const currentFocusedControlId = sap.ui.getCore().getCurrentFocusedControlId();
                            var _input = sap.ui.getCore().byId(currentFocusedControlId);
                            // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                            rowno = qrj.getControl().indexOfRow(_input.getParent());
                            colno = _input.getParent().indexOfCell(_input);
                            qrj.getControl().setSelectedIndex(rowno);
                        }

                        if (qrj.getControl().getSelectedIndices().length == 0) {
                            sap.m.MessageToast.show("Must select a row !");
                            return;
                        }

                        var sl = qrj.getControl().getSelectedIndices();
                        for (var s = sl.length - 1; s >= -1; s--)
                            qrj.deleteRow(sl[s]);
                    });
                    var btAddRow = new sap.m.Button({
                        icon: "sap-icon://sys-add",
                        tooltip: "select add a row ",
                    });
                    btAddRow.attachBrowserEvent("mousedown", function () {

                        var rowno = -1;
                        var colno = -1;
                        if (qrj.getControl().getSelectedIndices().length == 0)
                            try {
                                const currentFocusedControlId = sap.ui.getCore().getCurrentFocusedControlId();
                                var _input = sap.ui.getCore().byId(currentFocusedControlId);
                                // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                                rowno = qrj.getControl().indexOfRow(_input.getParent());
                                colno = _input.getParent().indexOfCell(_input);
                                qrj.getControl().setSelectedIndex(rowno);
                            } catch (e) { }
                        var sl = qrj.getControl().getSelectedIndices()[0];
                        if (Util.nvl(sl, -1) != -1)
                            qrj.insertRow(sl);
                        else qrj.addRow();
                    }
                    );
                    var btNewAc = new sap.m.Button({
                        icon: "sap-icon://account",
                        tooltip: "Create new A/c",
                        press: function () {
                            UtilGen.execCmd("bin.forms.gl.masterAc formSize=650px,400px status=new", UtilGen.DBView, UtilGen.DBView.txtExeCmd, UtilGen.DBView.newPage);
                        }
                    });
                    var btPos = new sap.m.Button({
                        icon: "sap-icon://bullet-text",
                        tooltip: "Re-positioning",
                        press: function () {
                            if (!qrj.editable)
                                return;
                            var n = 1;
                            var lc = qrj.mLctb;
                            for (var i = 0; i < lc.rows.length; i++)
                                lc.setFieldValue(i, "POS", n++);
                            qrj.updateDataToControl();
                        }
                    });
                    var btSOA = new sap.m.Button({
                        icon: "sap-icon://document-text",
                        tooltip: "SOA",
                    });
                    btSOA.attachBrowserEvent("mousedown", function () {
                        var rowno = -1;
                        var colno = -1;
                        if (qrj.getControl().getSelectedIndices().length == 0) {
                            const currentFocusedControlId = sap.ui.getCore().getCurrentFocusedControlId();
                            var _input = sap.ui.getCore().byId(currentFocusedControlId);
                            // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                            rowno = qrj.getControl().indexOfRow(_input.getParent());
                            colno = _input.getParent().indexOfCell(_input);
                            qrj.getControl().setSelectedIndex(rowno);
                        } else
                            rowno = qrj.getControl().getSelectedIndices()[0];
                        var oModel = qrj.getControl().getModel();
                        var currentRowContext = qrj.getControl().getContextByIndex(rowno + qrj.getControl().getFirstVisibleRow());
                        var accno = oModel.getProperty("ACCNO", currentRowContext);
                        var cc = oModel.getProperty("CUST_CODE", currentRowContext);
                        if (Util.nvl(cc, "") != "") {
                            UtilGen.execCmd("testRep5 formType=dialog formSize=100%,80% repno=0 para_PARAFORM=false para_EXEC_REP=true pref=" + cc + " fromdate=@01/01/2020", UtilGen.DBView, qrj.getControl(), UtilGen.DBView.newPage);
                        } else if (Util.nvl(accno, "") != "") {
                            UtilGen.execCmd("testRep5 formType=dialog formSize=100%,80% repno=1 para_PARAFORM=false para_EXEC_REP=true fromacc=" + accno + " toacc=" + accno + " fromdate=@01/01/2020", UtilGen.DBView, qrj.getControl(), UtilGen.DBView.newPage);
                        }
                        if (colno != -1) {
                            setTimeout(function () {
                                if (Util.nvl(cc, "") != "") {
                                    var bl = Util.getSQLValue("select sum(debit-credit) from acvoucher2 where cust_code=" + Util.quoted(cc));
                                    sap.m.MessageToast.show("#" + cc + " Balance is : " + df.format(bl));
                                } else if (Util.nvl(accno, "") != "") {
                                    var bl = Util.getSQLValue("select sum(debit-credit) from acvoucher2 where accno=" + Util.quoted(accno));
                                    sap.m.MessageToast.show("#" + accno + " Balance is : " + df.format(bl));
                                }

                            });
                        }
                        qrj.getControl().setSelectedIndex(-1);

                    });
                    var btCpyFromVou = new sap.m.Button({
                        icon: "sap-icon://copy",
                        tooltip: "Copy line items from another voucher..",
                    });
                    btCpyFromVou.attachBrowserEvent("mousedown", function () {
                        var sq = "SELECT V.VOU_CODE,V.TYPE,nvl(AG.NAMEa,ag.name) name,COUNT(*) VOUCHERS_CNT FROM ACVOUCHER1 V,ACGRPJVS AG " +
                            " WHERE V.VOU_CODE=AG.VOU_CODE AND V.TYPE=AG.VOU_TYPE " +
                            " GROUP BY V.VOU_CODE,V.TYPE,nvl(AG.NAMEa,ag.name) " +
                            " ORDER BY V.VOU_CODE,V.TYPE";
                        Util.show_list(sq, ["NAME", "VOUCHERS_CNT"], "", function (data) {
                            if (data == null || data == undefined || data.length <= 0)
                                return false;
                            var vc = data.VOU_CODE;
                            var vt = data.TYPE;
                            setTimeout(() => {
                                var sq2 = "select no,TO_CHAR(vou_date,'DD/MM/RRRR') VOU_DATE ,descr,keyfld ,DEBAMT DEBAMT" +
                                    " from acvoucher1 where vou_code=" + vc +
                                    " and type=" + vt + " order by acvoucher1.vou_date desc,no desc";
                                Util.show_list(sq2, ["NO", "VOU_DATE", "DESCR", "DEBAMT"], "", function (data) {
                                    that.copyDataFromVou(data, qrj, vars);
                                    return true;
                                }, "100%", "100%", undefined, true);


                            }, 100);
                            return true;
                        }, "100%", "50%", undefined, false);

                    });
                    var btNw = new sap.m.Button({
                        icon: "sap-icon://full-screen", press: function () {
                            qrj.createNewWnd();
                        }
                    });
                    qrj.showToolbar.toolbar.removeAllContent();
                    qrj.showToolbar.toolbar.addStyleClass("toolBarBackgroundColor1");

                    qrj.showToolbar.toolbar.addContent(btAddRow);
                    qrj.showToolbar.toolbar.addContent(btDelRow);
                    qrj.showToolbar.toolbar.addContent(btNewAc);
                    qrj.showToolbar.toolbar.addContent(btPos);
                    qrj.showToolbar.toolbar.addContent(btSOA);
                    qrj.showToolbar.toolbar.addContent(btCpyFromVou);
                    qrj.showToolbar.toolbar.addContent(new sap.m.ToolbarSpacer());
                    qrj.showToolbar.toolbar.addContent(txt);
                    qrj.showToolbar.toolbar.addContent(btf);
                    qrj.showToolbar.toolbar.addContent(btf);
                    qrj.showToolbar.toolbar.addContent(btNw);
                    scrollObjs.push(qrj.showToolbar.toolbar);
                },
                attachLoadQry: function (frm, qry, kindof, refer) {
                    frm.fileUpload = undefined;
                    var desc = Util.getSQLValue("select descr from c7_attach where kind_of='" + kindof + "' and refer='" + refer + "'");
                    qry.formview.setFieldValue("attachment", desc);
                    Util.doXhr("getAttachVou?kindof=" + kindof + "&refer=" + refer, true, function (e) {
                        if (this.status == 200 && this.response.byteLength > 0)
                            frm.fileUpload = new Blob([this.response], { type: "application/pdf" });
                    });

                },
                attachSaveQry: function (that2, kindof, refer) {
                    // if (that2.fileUpload != undefined) {
                    // var kf = that2.frm.getFieldValue("keyfld");
                    var tx = that2.frm.getFieldValue("attachment");
                    Util.doXhrUpdateVouAttach("uploadAttachPdfVou", true, that2.fileUpload, refer, tx, Util.nvl(kindof, 'VOU'));
                    // }

                },
                attachShowUpload: function (that2, pChange) {
                    Util.sleep(1200);
                    var change = Util.nvl(pChange, true);
                    var vb = new sap.m.VBox();
                    // var tx = new sap.m.Input({ placeholder: "Descr" });
                    // var pv = new sap.m.PDFViewer({
                    //     displayType: sap.m.PDFViewerDisplayType.Embedded,
                    //     showDownloadButton: true,
                    //     height: "500px",
                    //     width: "100%",
                    // });
                    var pv = new sap.ui.core.HTML({
                        content: "<div id='pdfFrame' style='width:100%; height:500px;'></div>"
                    });
                    var onLoad = function (e) {
                        var pdfData = new Uint8Array(e.target.result);
                        var blob = new Blob([pdfData], { type: "application/pdf" });
                        var link = document.createElement('a');
                        link.href = window.URL.createObjectURL(blob);
                        link.target = "_blank";
                        link.style.display = "none";
                        document.body.appendChild(link);
                        link.download = "rpt" + new Date() + ".pdf";
                        // Util.printPdf(link.href);
                        jQuery.sap.addUrlWhitelist("blob");
                        // pv.setSource(link.href);
                        // pv.open();
                        document.getElementById("pdfFrame").innerHTML =
                            "<iframe src='" + link.href + "' " +
                            "width='100%' height='100%' " +
                            "style='border:none'></iframe>";
                    };

                    if (that2.fileUpload != undefined) {
                        var file = that2.fileUpload;
                        var reader = new FileReader();
                        reader.onload = onLoad;
                        reader.readAsArrayBuffer(file);
                        that2.fileUpload = file;
                    }

                    var fu = new sap.ui.unified.FileUploader({
                        fileType: ["pdf"],
                        onFileUpload: function (event) {
                            var file = event.getParameter("files")[0];
                            that2.fileUpload = file;
                        },
                        change: function (e) {
                            var files = e.getParameters("files").files;
                            if (files.length < 1) {
                                alert('select a file...');
                                return;
                            }
                            var file = files[0];
                            var reader = new FileReader();
                            reader.onload = onLoad;
                            reader.readAsArrayBuffer(file);
                            that2.fileUpload = file;
                        },
                    });
                    if (change)
                        vb.addItem(fu);
                    // vb.addItem(tx);
                    // vb.addItem(bt);
                    vb.addItem(pv);

                    var dlg = new sap.m.Dialog({
                        content: vb,
                        title: "Select PDF file to attach voucher",
                        contentWidth: "100%",
                        contentHeight: "600px",
                        buttons: [
                            new sap.m.Button({
                                text: "Delete",
                                enabled: change,
                                press: function () {
                                    if (!change) { sap.m.MessageToast.show("Cant delete !"); return; }
                                    // pv.setSource(undefined);
                                    document.getElementById("pdfFrame").innerHTML =
                                        "<iframe src='' " +
                                        "width='100%' height='100%' " +
                                        "style='border:none'></iframe>";
                                    that2.fileUpload = undefined;
                                }
                            }),
                            new sap.m.Button({
                                text: "Close",
                                press: function () {
                                    dlg.close();
                                }
                            }),
                        ]
                    });
                    dlg.open();
                    setTimeout(function () {
                        sap.m.MessageToast.show("Open again in case you dont see attachment !!!");
                    });
                },
                showRVByInvs: function (that2) {
                    // var that2 = this;
                    var sc = new sap.m.ScrollContainer().addStyleClass("sapUiMediumMargin");
                    sc.addContent(new sap.m.Text({ text: "Enter customer code:" }));
                    var txtPaidAmt = new sap.m.Input({
                        editable: false
                    });
                    var fetchData = function (pIsLifo) {
                        var isLifo = Util.nvl(pIsLifo, false);
                        var pdamt = parseFloat(txtAmount.getValue());
                        if (pdamt <= 0) FormView.err("Cant be 0 amount !");
                        var custCode = txtCustCode.getValue();
                        if (Util.nvl(custCode, "") == "")
                            FormView.err("Customer is not selected !")
                        var dt = Util.execSQL("SELECT INVOICE_NO,CUSNO,NAME,invoice_date,(NET_AMT-(PAID_AMT+RETURN_AMT)) NETPAY,PAID_AMT+RETURN_AMT PD ,INVUNPAID.KEYFLD,NET_AMT ,0 PAID_AMT" +
                            " FROM INVUNPAID,C_YCUST WHERE " +
                            " CUSNO IN (SELECT CODE FROM C_YCUST WHERE PATH LIKE (select path from c_ycust where code='" + txtCustCode.getValue() + "')||'%') " +
                            " AND CUSNO=CODE " +
                            " AND (NET_AMT-(PAID_AMT+RETURN_AMT))>0 AND INVOICE_CODE=21 " +
                            (isLifo ? " ORDER BY INVOICE_DATE desc,INVUNPAID.keyfld desc" : " ORDER BY INVOICE_DATE,INVUNPAID.keyfld "));
                        if (dt.ret == "SUCCESS") {
                            qr.setJsonStrMetaData("{" + dt.data + "}");
                            qr.mLctb.cols[qr.mLctb.getColPos("PAID_AMT")].mColClass = "sap.m.Input";
                            qr.mLctb.cols[qr.mLctb.getColPos("INVOICE_DATE")].getMUIHelper().display_format = "SHORT_DATE_FORMAT";
                            qr.mLctb.cols[qr.mLctb.getColPos("NETPAY")].getMUIHelper().display_format = "MONEY_FORMAT";
                            qr.mLctb.cols[qr.mLctb.getColPos("PD")].getMUIHelper().display_format = "MONEY_FORMAT";
                            qr.mLctb.cols[qr.mLctb.getColPos("NET_AMT")].getMUIHelper().display_format = "MONEY_FORMAT";
                            qr.mLctb.cols[qr.mLctb.getColPos("PAID_AMT")].getMUIHelper().display_format = "MONEY_FORMAT";

                            qr.mLctb.cols[qr.mLctb.getColPos("INVOICE_NO")].getMUIHelper().display_width = 80;
                            qr.mLctb.cols[qr.mLctb.getColPos("CUSNO")].getMUIHelper().display_width = 80;
                            qr.mLctb.cols[qr.mLctb.getColPos("NAME")].getMUIHelper().display_width = 130;
                            qr.mLctb.cols[qr.mLctb.getColPos("INVOICE_DATE")].getMUIHelper().display_width = 90;
                            qr.mLctb.cols[qr.mLctb.getColPos("NETPAY")].getMUIHelper().display_width = 90;
                            qr.mLctb.cols[qr.mLctb.getColPos("PD")].getMUIHelper().display_width = 90;
                            qr.mLctb.cols[qr.mLctb.getColPos("NET_AMT")].getMUIHelper().display_width = 90;
                            qr.mLctb.cols[qr.mLctb.getColPos("PAID_AMT")].getMUIHelper().display_width = 90;

                            qr.mLctb.cols[qr.mLctb.getColPos("KEYFLD")].mHideCol = true;
                            qr.mLctb.cols[qr.mLctb.getColPos("PAID_AMT")].eValidateColumn = function (evtx) {
                                if (qr.eventCalc != undefined)
                                    if (!qr.eventCalc(qr, this, -1, true))
                                        evtx.getSource().focus();

                            };
                            qr.eventCalc = function (qv, cx, rowno, reAmt) {
                                var sett = sap.ui.getCore().getModel("settings").getData();
                                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);

                                if (reAmt)
                                    qv.updateDataToTable();

                                var ld = qv.mLctb;
                                var sumPaidAmt = 0;
                                for (var i = 0; i < ld.rows.length; i++) {
                                    sumPaidAmt += Util.nvl(Util.extractNumber(ld.getFieldValue(i, "PAID_AMT"), df), 0);
                                }
                                txtPaidAmt.setValue(df.format(sumPaidAmt));
                                return true;
                            };
                            qr.mLctb.parse("{" + dt.data + "}", true);

                            var pdamt = parseFloat(txtAmount.getValue());
                            var pa = 0;
                            for (var i = 0; i < qr.mLctb.rows.length; i++) {
                                var pa = qr.mLctb.getFieldValue(i, "NETPAY");
                                if (pdamt - pa < 0)
                                    pa = pdamt;
                                if (pa > 0)
                                    qr.mLctb.setFieldValue(i, "PAID_AMT", pa);
                                pdamt = pdamt - pa;
                            }
                            qr.loadData();

                        }
                    }
                    var txtCustCode = new sap.m.Input({
                        width: "100px",
                        showValueHelp: true,
                        valueHelpRequest: function (e) {
                            if (e.getParameters().clearButtonPressed || e.getParameters().refreshButtonPressed) {
                                UtilGen.setControlValue(this, "", "", true);
                                UtilGen.setControlValue(txtParentName, "", "", true);
                                return;
                            }
                            var control = this;
                            var pacnm = txtCustName;
                            var sq = "select code, name from c_ycust where iscust='Y' order by path";
                            Util.showSearchList(sq, "NAME", "CODE", function (valx, val) {
                                UtilGen.setControlValue(control, valx, valx, true);
                                UtilGen.setControlValue(pacnm, val, val, true);
                            }, "Select a customer ...");
                        },
                        change: function (e) {
                            var control = this;
                            var vl = control.getValue();
                            var pacnm = txtCustName
                            UtilGen.setControlValue(pacnm, "", "", true);
                            var pnm = Util.getSQLValue("select name from c_ycust where code=" + Util.quoted(vl));
                            UtilGen.setControlValue(pacnm, pnm, pnm, true);
                            UtilGen.setControlValue(control, vl, vl, false);
                        }
                    });
                    var txtCustName = new sap.m.Input({
                        width: "200px",
                        editable: false
                    });

                    var txtAmount = new sap.m.Input({
                        width: "100px",
                        value: "0"
                    });

                    var btFifo = new sap.m.Button({
                        text: "FIFO Invoices",
                        press: function () {
                            fetchData(false);

                        }
                    });

                    var btLifo = new sap.m.Button({
                        text: "LIFO Invoices",
                        press: function () {
                            fetchData(true);
                        }
                    }).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginEnd");

                    var h1 = new sap.m.HBox({
                        alignItems: sap.m.FlexAlignItems.Center,
                        items: [txtCustCode, txtCustName, new sap.m.Text({ text: "Amount:" }).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginEnd"), txtAmount, btFifo, btLifo]
                    });

                    sc.addContent(h1);

                    var qr = new QueryView("qryRcptInvs" + that2.timeInLong);
                    qr.getControl().setEditable(true);

                    qr.getControl().view = that2;
                    qr.getControl().addStyleClass("sapUiSizeCondensed sapUiSmallMarginTop");
                    qr.getControl().setSelectionMode(sap.ui.table.SelectionMode.Single);
                    qr.getControl().setFixedBottomRowCount(0);
                    qr.getControl().setVisibleRowCountMode(sap.ui.table.VisibleRowCountMode.Fixed);
                    qr.getControl().setVisibleRowCount(10);
                    qr.insertable = false;
                    qr.deletable = false;
                    qr.editable = true;
                    sc.addContent(qr.getControl());
                    sc.addContent(new sap.m.VBox({ height: "50px" }));
                    sc.addContent(new sap.m.HBox({
                        alignItems: sap.m.FlexAlignItems.Center,
                        items: [new sap.m.Text({ text: "Amount:" }).addStyleClass("sapUiSmallMarginBegin sapUiSmallMarginEnd"), txtPaidAmt]
                    }
                    ));
                    var dlg = new sap.m.Dialog({
                        contentHeight: "80%",
                        contentWidth: "90%",
                        content: sc,
                        buttons: [
                            new sap.m.Button({
                                text: "OK",
                                press: function () {
                                    var amt = parseFloat(Util.extractNumber(txtAmount.getValue()));
                                    var totpd = parseFloat(Util.extractNumber(txtPaidAmt.getValue()));
                                    if (amt != totpd)
                                        FormView.err("Amount not matched with # " + amt);
                                    var ld = that2.frm.objs["qry2"].obj.mLctb;
                                    var ldinv = qr.mLctb;
                                    var ldi = 0;
                                    var des = that2.frm.getFieldValue("qry1.descr");
                                    ld.removeAllRows();
                                    ld.addRow();
                                    for (var i = 0; i < ldinv.rows.length; i++) {
                                        var pd = ldinv.getFieldValue(i, "PAID_AMT");
                                        if (pd > 0) {
                                            ld.setFieldValue(ldi, "CUST_CODE", ldinv.getFieldValue(i, "CUSNO"));
                                            ld.setFieldValue(ldi, "CREDIT", pd);
                                            ld.setFieldValue(ldi, "FCCREDIT", pd);
                                            ld.setFieldValue(ldi, "INVKEYFLD", ldinv.getFieldValue(i, "KEYFLD"));
                                            var nm = Util.getSQLValue("select name from c_ycust where code=" + Util.quoted(ldinv.getFieldValue(i, "CUSNO")));
                                            var acn = Util.getSQLValue("select ac_no from c_ycust where code=" + Util.quoted(ldinv.getFieldValue(i, "CUSNO")));
                                            var invdes = Util.getSQLValue("SELECT MAX('Inv # '||invoice_no||', Location ='||location_code ) from pur1 where keyfld=" + ldinv.getFieldValue(i, "KEYFLD"));
                                            ld.setFieldValue(ldi, "ACNAME", nm);
                                            ld.setFieldValue(ldi, "DESCR", des);
                                            ld.setFieldValue(ldi, "ACCNO", acn);
                                            ld.setFieldValue(ldi, "INV_DESCR", invdes);
                                            if (ld.rows.length >= ldi)
                                                ld.addRow();
                                            ldi++;
                                        }
                                    }
                                    if (ld.rows.length > 1)
                                        ld.deleteRow(ld.rows.length - 1);

                                    that2.frm.objs["qry2"].obj.updateDataToControl();
                                    that2.frm.objs["qry2"].obj.eventCalc(that2.frm.objs["qry2"].obj, undefined, -1, true);
                                    dlg.close();
                                }
                            }),
                            new sap.m.Button({
                                text: "Cancel",
                                press: function () {
                                    dlg.close();
                                }
                            })
                        ]
                    }).addStyleClass("sapUiSizeCondensed sapUiSizeCompact");
                    dlg.open();
                },
                showQuickBatch: function (ky, that) {
                    // var that = this;
                    var kfld = ky.split("-")[0];
                    var bat_id = ky.split("-")[1];
                    var paras = [];
                    var bnkcash = "2";
                    var strs = "";
                    var dt = Util.execSQL("select *from c7_batches_1 where keyfld=" + kfld + " and bat_id=" + bat_id);
                    if (dt.ret == "SUCCESS" && dt.data.length > 0) {
                        var dtxM = JSON.parse("{" + dt.data + "}").data;
                        for (var di in dtxM)
                            for (var d2 in dtxM[di])
                                strs += dtxM[di][d2] + " ";
                        var dt = Util.execSQL("select *from c7_batches_2 where keyfld=" + kfld + " and bat_id=" + bat_id);
                        if (dt.ret == "SUCCESS" && dt.data.length > 0) {
                            var dtxM = JSON.parse("{" + dt.data + "}").data;
                            for (var di in dtxM)
                                for (var d2 in dtxM[di])
                                    strs += dtxM[di][d2] + " ";
                        }

                    }

                    var dt = Util.execSQL("select *from c7_batches_para where keyfld=" + kfld);
                    var dtxM = JSON.parse("{" + dt.data + "}").data;
                    for (var di in dtxM)
                        if (strs.indexOf(":" + dtxM[di].PARA_NAME) >= 0)
                            paras.push(dtxM[di].PARA_NAME);

                    this.quickPara(kfld, bat_id, paras, that);


                },
                quickPara: function (kf, bat_id, pPara, that) {
                    var str = "";
                    // var that = this;
                    var sett = sap.ui.getCore().getModel("settings").getData();

                    var params = { "keyfld": kf, "bat_id": bat_id };
                    var fp = Util.nvl(Util.getSQLValue("select nvl(max(form_paras),'') para from c7_batches where keyfld=" + kf), "");
                    var sp = fp.split(" ");
                    for (var si in sp)
                        params[sp[si].split("=")[0]] = sp[si].split("=")[1];

                    pPara.forEach(ky => {
                        str += (str.length > 0 ? "," : "") + Util.quoted(ky);
                    });

                    var fnExeBatch = function (txt2, kfld, bat_id) {
                        var prx = txt2.split("&");
                        var paras = {};
                        var mapFlds1 = {};
                        var mapFlds2 = [];
                        prx.forEach(el => {
                            paras[el.split("=")[0]] = el.split("=")[1];
                        });
                        var isContentFormula = function (str) {
                            if (str.indexOf("+") >= 0 ||
                                str.indexOf("=") >= 0 ||
                                str.indexOf("*") >= 0 ||
                                str.indexOf("/") >= 0 ||
                                str.indexOf("-") >= 0)
                                return true;
                            return false;

                        }
                        var parseVal = function (vl) {
                            var vlx = vl;

                            for (var pi in paras)
                                vlx = vlx.replaceAll(":" + pi, paras[pi]);


                            if (typeof vlx == "string")
                                vlx = vlx.replaceAll("%20", " ");
                            if (vlx.startsWith("@") && !vlx.startsWith("@$"))
                                vlx = new Date(vlx.substring(1));
                            if (typeof vlx == "string" && vlx.startsWith("@") && vlx.startsWith("@$"))
                                vlx = Util.parseDefaultValue(vl.substring(1));

                            return vlx;
                        }
                        var dtx = Util.execSQLWithData("select *from c7_batches_1 where keyfld=" + kfld + " and bat_id=" + bat_id, "No data found, c7_batches_1 table !");
                        var fvs = Util.nvl(dtx[0].FIELDVALUES, "").split(" ");
                        for (var fi in fvs)
                            mapFlds1[fvs[fi].split("=")[0]] = fvs[fi].split("=")[1];
                        var dtx = Util.execSQLWithData("select *from c7_batches_2 where keyfld=" + kfld + " and bat_id=" + bat_id, "No data found, c7_batches_2 table!");
                        for (var di in dtx) {
                            var flds = {
                                accno: Util.nvl(dtx[di].FLD_ACCNO, ""),
                                amt: Util.nvl(dtx[di].AMOUNT, ""),
                                descr: Util.nvl(dtx[di].FLD_DESCR, ""),
                                costcent: Util.nvl(dtx[di].FLD_COSTCENT, ""),
                                rp_code: Util.nvl(dtx[di].FLD_RP_CODE, ""),
                                branch_no: Util.nvl(dtx[di].FLD_RP_BRANCH + "", "") + ""
                            }
                            mapFlds2.push(flds);
                        }
                        for (mi in mapFlds1)
                            mapFlds1[mi] = parseVal(mapFlds1[mi]);
                        for (mi in mapFlds2) {
                            var flds = mapFlds2[mi];
                            for (fi in flds)
                                flds[fi] = parseVal(flds[fi]);
                        }
                        UtilGen.setControlValue(that.frm.objs["qry1.descr"].obj, mapFlds1["descr"], mapFlds1["descr"], true);
                        if (that.frm.objs["qry1.rcvfrom"] != undefined)
                            UtilGen.setControlValue(that.frm.objs["qry1.rcvfrom"].obj, mapFlds1["payto"], mapFlds1["payto"], true);
                        if (that.frm.objs["qry1.code"] != undefined)
                            UtilGen.setControlValue(that.frm.objs["qry1.code"].obj, mapFlds1["codeacc"], mapFlds1["codeacc"], true);
                        // var nm = Util.getSQLValue("select name from acaccount where accno='" + mapFlds1["codeacc"] + "'");
                        // UtilGen.setControlValue(that.frm.objs["qry1.codename"].obj, nm, nm, true);
                        var ld = that.frm.objs["qry2"].obj.mLctb;
                        ld.removeAllRows();
                        var p = 0;
                        for (var mi in mapFlds2) {
                            var flds = mapFlds2[mi];
                            var amt = (isContentFormula(flds.amt + "") ? eval(flds.amt) : flds.amt);
                            if (amt != 0) {
                                ld.addRow();
                                if (that.vars.vou_code == 2 && amt > 0)
                                    amt = amt * -1;
                                var acn = flds.accno;
                                var des = Util.nvl(flds.descr, Util.nvl(mapFlds1["descr"], ""));
                                var nm = Util.getSQLValue("select name from acaccount where accno='" + acn + "'");
                                var csname = "";
                                if (flds.rp_code != "") {
                                    nm = Util.getSQLValue("select name from c_ycust where code='" + flds.rp_code + "'");
                                    acn = Util.getSQLValue("select ac_no from c_ycust where code=" + Util.quoted(flds.rp_code));
                                }
                                if (flds.costcent != "")
                                    csname = Util.getSQLValue("select title from accostcent1 where code='" + flds.costcent + "'");

                                ld.setFieldValue(p, "CUST_CODE", flds.rp_code);
                                ld.setFieldValue(p, "COSTCENT", flds.costcent);
                                ld.setFieldValue(p, "CREDIT", (amt < 0 ? Math.abs(amt) : 0));
                                ld.setFieldValue(p, "FCCREDIT", (amt < 0 ? Math.abs(amt) : 0));
                                ld.setFieldValue(p, "DEBIT", (amt > 0 ? amt : 0));
                                ld.setFieldValue(p, "FCDEBIT", (amt > 0 ? amt : 0));
                                ld.setFieldValue(p, "ACNAME", nm);
                                ld.setFieldValue(p, "CSNAME", csname);
                                ld.setFieldValue(p, "DESCR", des);
                                ld.setFieldValue(p, "ACCNO", acn);
                                p++;
                            }
                        }
                        that.frm.objs["qry2"].obj.updateDataToControl();
                        that.frm.objs["qry2"].obj.loadData();
                        // that.frm.objs["qry2"].obj.eventCalc(that.frm.objs["qry2"].obj, undefined, -1, true);

                        return true;

                    }
                    var vb = new sap.m.VBox({});
                    var formWidth = Util.nvl(params["formWidth"], "600px");
                    var dialogWidth = Util.nvl(params["dialogSize"], "90%,90%").split(",")[0];
                    var dialogHeight = Util.nvl(params["dialogSize"], "90%,90%").split(",")[1];
                    var dt = Util.execSQL("select *from C7_BATCHES_PARA where keyfld=" + params["keyfld"] + " and  para_name in (" + str + ") order by pos");
                    if (dt.ret == "SUCCESS") {
                        var dtx = JSON.parse("{" + dt.data + "}").data;
                        var fe = [];
                        var parAr = []; // to get all parameter name in array
                        for (var di in dtx)
                            parAr.push(dtx[di].PARA_NAME);
                        var titleTxt = "";
                        for (var d in dtx) {
                            if (Util.nvl(dtx[d].TITLE_TXT1, "") != titleTxt) {
                                titleTxt = Util.nvl(dtx[d].TITLE_TXT1, "");
                                fe.push(Util.getLabelTxt(titleTxt, Util.nvl(dtx[d].LBL_WIDTH, "25%"), "", "qrGroup"));
                            }
                            fe.push(Util.getLabelTxt(dtx[d].TITLE, Util.nvl(dtx[d].LBL_WIDTH, "25%"), Util.nvl(dtx[d].LINE_DLM, "")));
                            var obj = UtilGen.addControl(fe, "@", (dtx[d].DATA_TYPE == "date" ? sap.m.DatePicker : sap.m.Input), "para_" + dtx[d].PARA_NAME + "__" + that.timeInLong + "",
                                {
                                    customData: [/*0*/{ key: "" }, /*1*/{ key: dtx[d].PARA_NAME },/*2*/ { key: dtx[d].VALIDATION }, /*3*/{ key: dtx[d].LIST_SQL },/*4*/{ key: dtx[d].LIST_RET_FIELD },/*5*/{ key: dtx[d].ONCALC }],
                                    width: Util.nvl(dtx[d].OBJ_WIDTH, "75%"),
                                    showValueHelp: (Util.nvl(dtx[d].LIST_SQL, "") != "") ? true : false,
                                    editable: (Util.nvl(dtx[d].EDITABLE, "Y") == "Y") ? true : false,
                                    valueHelpRequest: function (e) {
                                        var sq = Util.nvl(this.getCustomData()[3].getKey(), "");
                                        var rf = Util.nvl(this.getCustomData()[4].getKey(), "");
                                        var fldCode = that.view.byId("para_" + this.getCustomData()[1].getKey() + "__" + that.timeInLong);
                                        var fldTit = that.view.byId("para_TITLE" + this.getCustomData()[1].getKey() + "TITLE__" + that.timeInLong);
                                        Util.show_list(sq, ["CODE", "TITLE"], "", function (data) {
                                            UtilGen.setControlValue(fldCode, data.CODE, data.CODE, true);
                                            if (fldTit != undefined)
                                                UtilGen.setControlValue(fldTit, data.TITLE, data.TITLE, true);
                                            return true;
                                        }, "100%", "100%", undefined, false);
                                    },
                                    change: function (e) {
                                        var sq = Util.nvl(this.getCustomData()[2].getKey(), "");
                                        sq = sq.replaceAll(":CODE", this.getValue());
                                        var onCalc = this.getCustomData()[5].getKey();
                                        if (onCalc != "") {
                                            for (var pi in parAr) {
                                                var vl = UtilGen.getControlValue(that.view.byId("para_" + parAr[pi] + "__" + that.timeInLong));
                                                if (vl != null && vl instanceof Date)
                                                    vl = Util.toOraDateString(vl);

                                                onCalc = onCalc.replaceAll(":" + parAr[pi], Util.nvl(vl, "null"));
                                            }
                                            try {
                                                eval(onCalc.replaceAll("that.byId", "that.view.byId"));
                                            }
                                            catch (err) { sap.m.MessageToast.show(err); console.log(err); }
                                        }
                                        if (Util.nvl(sq, "") == "") return;
                                        var vl = Util.getSQLValue(sq);
                                        var fldTit = that.view.byId("para_TITLE" + this.getCustomData()[1].getKey() + "TITLE__" + that.timeInLong);
                                        if (vl != undefined && fldTit != undefined)
                                            UtilGen.setControlValue(fldTit, vl, vl, true);
                                    }
                                }, dtx[d].DATA_TYPE, Util.nvl(sett[dtx[d].FORMAT_FLD], dtx[d].FORMAT_FLD), that.view);

                            if (dtx[d].PARA_VALUE != undefined) {
                                var value = dtx[d].PARA_VALUE;
                                if (obj instanceof sap.m.DatePicker && dtx[d].PARA_VALUE.startsWith("@"))
                                    if (params[dtx[d].PARA_NAME] != undefined)
                                        value = UtilGen.parseDefaultValue(params[dtx[d].PARA_NAME].substring(1));//new Date(params[dtx[d].PARA_NAME].substring(1));
                                    else {
                                        value = UtilGen.parseDefaultValue(dtx[d].PARA_VALUE.substring(1));//new Date(dtx[d].PARA_VALUE.substring(1));

                                    }
                                else
                                    if (params[dtx[d].PARA_NAME] != undefined)
                                        value = params[dtx[d].PARA_NAME];
                                    else
                                        value = dtx[d].PARA_VALUE;


                                UtilGen.setControlValue(obj, value, value, true);


                            }
                        }
                        Util.navEnter(fe);
                        var cnt = UtilGen.formCreate2("", true, fe, undefined, sap.m.ScrollContainer, {
                            width: formWidth,
                            cssText: [
                                "padding-left:0px ;" +
                                "padding-top:5px;" +
                                "border-style: groove;" +
                                "margin-left: 0;" +
                                "margin-right: 0;" +
                                "border-radius:20px;" +
                                "margin-top: 10px;"
                            ]
                        }, "sapUiSizeCompact", "");
                        cnt.addContent(new sap.m.VBox({ height: "40px" }));
                        vb.addItem(cnt);
                    }
                    var dlg = new sap.m.Dialog({
                        title: Util.getLangText("parameters"),
                        contentWidth: dialogWidth,
                        contentHeight: dialogHeight,
                        content: [vb],
                        buttons: [
                            new sap.m.Button({
                                text: Util.getLangText("executeTxt"),
                                press: function () {
                                    var str = "";
                                    for (var f in fe) {
                                        var val;
                                        if (typeof fe[f] == "string")
                                            continue;
                                        if (fe[f] instanceof sap.m.InputBase)
                                            val = UtilGen.getControlValue(fe[f]);
                                        if (val instanceof Date)
                                            val = "@" + val.getDate() + "\/" + (val.getMonth() + 1) + "\/" + val.getFullYear();
                                        val = val.startsWith("@") ? val : encodeURIComponent(val);
                                        str += (str.length > 0 ? " " : "") + fe[f].getCustomData()[1].getKey() + "=" + val;
                                    }
                                    str = ("keyfld=" + params["keyfld"] + " " + str).replaceAll(" ", "&");
                                    var dt = fnExeBatch(str, params["keyfld"], params["bat_id"]);
                                    if (dt)
                                        dlg.close();

                                }
                            }),
                            new sap.m.Button({
                                text: Util.getLangText("closeTxt"),
                                press: function () {
                                    dlg.close();
                                }
                            })

                        ]
                    });
                    dlg.open();
                    // setTimeout(function () {
                    //     dlg.$().offset({ top: "100", left: "100" });
                    // });

                },
                getNewPORDNoFromQry: function (qry, vc) {
                    var lc = qry.formview.objs["qry1.location_code"].obj.getSelectedKey();
                    var ty = Util.extractNumber(qry.formview.objs["qry1.ord_type"].obj.getSelectedKey());
                    return this.getNewPORDNo(lc, vc, ty);
                },
                getNewPORDNo: function (loc, vc, typ) {
                    var sqln = ("select c7_pord_new_no(':loc'," +
                        "':vou_code' , :vou_type ) from dual").replaceAll(":vou_code", vc)
                        .replaceAll(":loc", loc)
                        .replaceAll(":vou_type", Util.nvl(typ, -1));
                    var vl = Util.extractNumber(Util.getSQLValue(sqln));
                    return vl;
                },
                getNewPurNo: function (loc, vc, typ) {
                    var sqln = ("select c7_pur_new_no(':loc'," +
                        "':vou_code' , :vou_type ) from dual").replaceAll(":vou_code", vc)
                        .replaceAll(":loc", loc)
                        .replaceAll(":vou_type", Util.nvl(typ, -1));
                    var vl = Util.extractNumber(Util.getSQLValue(sqln));
                    return vl;
                }
            },
            setFormTitle: function (frm, tit, mainPage) {
                if (typeof frm.getParent != "undefined" && (frm.getParent() instanceof sap.m.Dialog))
                    frm.getParent().setTitle(tit);
                else {
                    mainPage.setShowHeader(true);
                    mainPage.setTitle(tit);
                }
            },
            showBalanceAccno: function (cd) {
                var sett = sap.ui.getCore().getModel("settings").getData();
                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                var bl = Util.getSQLValue('select sum(debit-credit) from acvoucher2 where accno=' + Util.quoted(cd));
                sap.m.MessageToast.show("#" + cd + "# Balance is : " + df.format(bl));
            },
            setColorCellDrCr: function (qv, startCell, endCell, dispRow, css, colName) {
                // var qt = oModel.getProperty(colName, currentRowContext);
                // var css = (val > 0 ? UtilGen.DBView.style_debit_numbers + ";text-align:center;" : UtilGen.DBView.style_credit_numbers + ";text-align:center;");
                for (var i = startCell; i < endCell; i++)
                    if (qv.getControl()._getVisibleColumns()[i - startCell].tableCol.mColName == colName) {
                        qv.getControl().getRows()[dispRow].getCells()[i - startCell].$().css("cssText", css);
                        qv.getControl().getRows()[dispRow].getCells()[i - startCell].$().parent().parent().css("cssText", css);
                    }

            },
            getTableColNo: function (tbl, colName) {
                var endCell = tbl.getColumns().length;
                for (var i = 0; i < endCell; i++)
                    if (tbl._getVisibleColumns()[i].tableCol.mColName == colName)
                        return i;
                return -1;
            },
            getPathAccsBalances: function (accs, dt) {
                var sqlStr = "select path from acaccount where '" + accs + "' like '%\"'||accno||'\"%' order by path"
                var dat = Util.execSQL(sqlStr);
                if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                    var dtx = JSON.parse("{" + dat.data + "}").data;
                    var tot = 0;
                    var dtstr = (dt != undefined ? " and vou_date<=" + Util.toOraDateString(dt) : " and vou_date<=" + Util.toOraDateString(UtilGen.DBView.today_date.getDateValue()));
                    for (var i in dtx)
                        tot += Util.getSQLValue("select nvl(sum(debit-credit),0) from acc_transaction_up where path like '" + dtx[i].PATH + "%' " + dtstr);
                    return tot;
                }
                return 0;
            },
            getBackYears: function (pFromdate, pTodate) {
                var thatForm = this;
                var view = thatForm.view;
                var backYears = [];
                var fisc = sap.ui.getCore().getModel("fiscalData").getData();
                var dtBackYears = Util.execSQLWithData("select * from c7_fiscals where code=(select max(back_fiscal_code) from c7_fiscals where code=" + Util.quoted(fisc["fiscal_code"]) + ")");
                var sqladd = 0;
                while (dtBackYears.length > 0) {
                    //Check date range in between date of period
                    if (pFromdate <= new Date(dtBackYears[0].TO_DATE.replaceAll(".", ":")))
                        backYears.push({
                            fiscal_code: dtBackYears[0].CODE,
                            fiscal_title: dtBackYears[0].TITLE,
                            fiscal_from: dtBackYears[0].FROM_DATE,
                            fiscal_to: dtBackYears[0].TO_DATE,
                            fiscal_schema: dtBackYears[0].SCHEMA_OWNER,
                        });
                    sqladd++
                    dtBackYears = Util.execSQLWithData("select * from c7_fiscals where code=(select max(back_fiscal_code) from c7_fiscals where code=" + Util.quoted(dtBackYears[0].CODE) + ")");
                }
                return backYears;
            },

            buildJSONTreeWithTotal: function (lctb, that) {
                if (lctb.cols.length == 0)
                    return null;
                // var that = this;
                // this.applySettings();
                var items = lctb.getData(true);
                if (items == null)
                    return;
                var tblDetailStyle = that["styleTableDetails"];
                var tblHeadStyle = that["styleTableHeader"];
                var mapNodes = [];
                var recalcCHildCount = true;
                var itemsByID = [];
                var columns = [];
                var lastParent = "";
                var lastParentNode = null;
                var rootNode = null;
                var footer = {};
                var findNodebyVal = function (id) {
                    return mapNodes[id];
                };

                var calcChildCount = function () {
                    if (that.mColChild.length <= 0) return;
                    var ld = lctb;
                    for (var i = 0; i < ld.rows.length; i++) {
                        var childcont = 0;
                        for (var j = 0; j < ld.rows.length; j++)
                            ld.getFieldValue(j, that.mColParent) ==
                                ld.getFieldValue(i, that.mColCode) ? childcont++ : childcont;
                        ld.setFieldValue(i, that.mColChild, childcont);
                    }
                }

                var getHTMLText = function (oData) {
                    if (lctb.cols.length <= 0) return;
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    // if (that.getControl().getModel() == undefined) return;
                    // var oData = that.getControl().getModel().getData();
                    // var oData = lctb.getData(false);
                    var h = "", dt = "", rs = "";           // table header data

                    var hCol = "";
                    var tmpv1 = "", tmpv2 = "", tmpv3 = "", classadd = "", styleadd = "";
                    var cs = []; // colspans in array for first row
                    var nxtSpan = 0;
                    var hasSpan = false;
                    var hs = 1;
                    var cnt = 0;
                    var ld = lctb;
                    for (var c in ld.cols) {
                        cnt++;
                        // if (cnt - 1 == 0 && grouped) continue;
                        if (ld.cols[c].mHideCol) continue;

                        cs[c] = "";
                        tmpv1 = ld.cols[c].mTitle;

                        if (nxtSpan > 1) {
                            cs[c] = "";
                            if (ld.cols[c].mTitleParent != "")
                                tmpv1 = ld.cols[c].mTitle;
                            else
                                tmpv1 = ld.cols[c].mTitleParent;

                            var st = "style=\"text-align: center;" + (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, -1, ld.cols[c].mColName), "") : "") + "\"" + " colspan=\"1\"";
                            h += "<th " + st + ">" + Util.htmlEntities(tmpv1) + "</th>";
                            nxtSpan--;
                            continue;
                        }
                        hs = ld.cols[c].mTitleParentSpan;
                        if (hs > 1) {
                            // cs[c] = "<th style=\"text-align: center;\" colspan=\"" + hs + "\">" + this.col[c].getMultiLabels()[0].getText() + "</th>";
                            hasSpan = true;
                            nxtSpan = hs;
                            tmpv1 = ld.cols[c].mTitle;
                            // tmpv2 = "\"text-align:Center\"";
                            var st = "style=\"text-align: center;" + (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, -1, ld.cols[c].mColName), "") : "") + "\"" + " colspan=\"" + hs + "\"";
                            var st2 = "style=\"text-align: center;" + (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, -1, ld.cols[c].mColName), "") : "") + "\"" + " colspan=\"1\"";
                            cs[c] = "<th " + st + ">" + ld.cols[c].mTitleParent + "</th>";
                            h += "<th " + st2 + ">" + Util.htmlEntities(tmpv1) + "</th>";
                        }
                        else {
                            // cs[c] = "<th colspan=\"1\"></th>";
                            tmpv1 = ld.cols[c].mTitle;
                            // tmpv2 = "\"text-align:Center\"";
                            var st = "style=\"text-align: center;" + (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, -1, ld.cols[c].mColName), "") : "") + "\"" + " colspan=\"1\"";
                            h += "<th " + st + ">" + Util.htmlEntities(tmpv1) + "</th>";
                            cs[c] = "<th " + st + ">";
                            hs--;
                        }

                        // tmpv2 = "";//"\"text-align:Center\"";
                        // var st = "style=\"text-align: center;" + (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, -1, ld.cols[c].mColName), "") : "") + "\"" + " colspan=\"" + hs + "\"";
                        // cs[c] = "<th " + st + ">" + tmpv1 + "</th>";
                        // h += "<th " + tmpv2 + st + ">" + Util.htmlEntities(tmpv1) + "</th>";
                    }

                    for (var x in cs)
                        hCol += cs[x];


                    hCol = "<tr " + tblHeadStyle + ">" + hCol + "</tr>";
                    var spacerAdd = "<tr><td class=\"page-header-space\"><div></div></td></tr>";
                    var spacerAddFooter = "<tfoot><tr><td class=\"page-footer-space\"><div></div></td></tr></tfoot>";

                    h = "<thead>" + spacerAdd + (hasSpan ? hCol : "") +
                        "<tr " + tblHeadStyle + ">" + h + "</tr></thead>";

                    for (var i = 0; i < oData.length; i++) {
                        rs = _getRowData2(i, oData);
                        dt += rs;
                    }
                    dt = "<tbody " + tblDetailStyle + ">" + dt + "</tbody>";
                    var tblClass = Util.nvl(that.tableClass, "");
                    h = "<table " + tblClass + ">" + h + dt + spacerAddFooter + "</table>";
                    return h;
                }
                var _getRowData2 = function (i, oData) {
                    var cellValue = "";
                    // var that = this;
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                    var dfq1 = new DecimalFormat("#,##0");
                    var rs = "";
                    var cnt = 0;
                    var grouped = lctb.cols[0].mGrouped;
                    var t;
                    var tmpv2 = "", tmpv3 = "", classadd = "", styleadd = "";
                    //getting style for row...
                    var cf = "";  // conditional format css (if condition true and false)
                    var rowid = Number(Util.nvl(oData[i]["_rowid"], -1));
                    var child;

                    // purpose  :  looping all columns to get conditional format css
                    for (var v in oData[i]) {

                        if (v.startsWith("childeren_"))
                            child = oData[i][v];
                        var cn = lctb.getColPos(v);

                        if (cn > -1 && lctb.cols[cn].mHideCol) continue;
                        if (cn > -1 && rowid > -1 && Util.nvl(lctb.cols[cn].mCfOperator, "").length > 0) {
                            if (lctb.evaluteCfValue(lctb.cols[cn], rowid))
                                cf += lctb.cols[cn].mCfTrue;
                            else
                                cf += lctb.cols[cn].mCfFalse;
                        }
                    }
                    // purpose   :  looping to write html <tr>

                    for (var v in oData[i]) {
                        // task  :  find out that should i print this row or not , by checking this row is collapsed or expanded..

                        cnt++;
                        tmpv2 = "", tmpv3 = "", classadd = "", styleadd = "";

                        var cn = lctb.getColPos(v.replace("___", "/"));
                        var cc = lctb.cols[cn];
                        if (cn > -1 && lctb.cols[cn].mHideCol) continue;
                        if (cnt - 1 == 0) {
                            t = v;
                        }   // get 1st array key.. to find this row is summary/group
                        // if (cnt - 1 === 0 && grouped) {
                        //     continue;
                        // }
                        if (cnt - 1 === lctb.cols.length) break;
                        cellValue = Util.nvl(oData[i][v], "");
                        var spcAdd = "";
                        if (cc.mColName == that.mColName && that.mColLevel.length > 0 && Util.nvl(oData[i][that.mColLevel], "") != "")
                            spcAdd = Util.nvl(that.showSpaces, true) ? Util.charCount("\xa0\xa0", parseInt(oData[i][that.mColLevel])) : ""; //Util.charCount("\xa0\xa0", parseInt(oData[i][that.mColLevel]));


                        if (rowid > -1 && cf.length > 0)
                            styleadd += cf;
                        styleadd += (that.fnOnCellAddStyle != undefined ? Util.nvl(that.fnOnCellAddStyle(oData, i, v), "") : "");
                        if ((that.mColChild.length > 0 && parseInt(oData[i][that.mColChild]) > 0) &&
                            (cc.getMUIHelper().display_format == "MONEY_FORMAT" ||
                                cc.getMUIHelper().display_format == "QTY_FORMAT")) {

                            // styleadd += "color:silver;";
                            var dfq = (that.formatNumber != undefined ? Util.nvl(that.formatNumber(oData, i, v), dfq1) : dfq1);
                            cellValue = (Util.nvl(that.reFormatNumber, true) ? dfq.format(Util.extractNumber(cellValue)) : Util.extractNumber(cellValue) + "");//dfq.format(Util.extractNumber(cellValue));
                        }
                        var wdth = Util.nvl(cc.getMUIHelper().display_width, "100") + "";
                        if (wdth.charAt(wdth.length - 1).match("[0-9]"))
                            wdth = wdth + "px";
                        var a = "text-align:" + Util.nvl(cc.getMUIHelper().display_align, "start") +
                            ";width:" + wdth + " ";



                        if (cc.getMUIHelper().display_format == "QTY_FORMAT" ||
                            cc.getMUIHelper().display_format == "MONEY_FORMAT") {
                            a = "text-align:" + Util.getLangDescrAR("end", "start") + ";width:" + wdth + " ";
                            if (cellValue == null || cellValue == "0" || cellValue == 0)
                                cellValue = "";
                            else {
                                var dfq = (that.formatNumber != undefined ? Util.nvl(that.formatNumber(oData, i, v), dfq1) : dfq1);
                                cellValue = (Util.nvl(that.reFormatNumber, true) ? dfq.format(Util.extractNumber(cellValue)) : Util.extractNumber(cellValue) + "");
                                if ((cellValue + "").startsWith("-"))
                                    cellValue = "(" + cellValue.substring(1) + ")";
                            }
                        }
                        if (that.mColCode.length > 0 && Util.nvl(oData[i][that.mColCode], "") == "" && oData[i][that.mColLevel] == minLevel)
                            styleadd += "font-weight:bold;border-top:groove;border-bottom:groove;";

                        if (that.mColCode.length > 0 && Util.nvl(oData[i][that.mColCode], "") == "" && oData[i][that.mColLevel] >= minLevel &&
                            (cc.getMUIHelper().display_format == "QTY_FORMAT" ||
                                cc.getMUIHelper().display_format == "MONEY_FORMAT"))
                            styleadd += "border-top:groove;border-bottom:groove;";

                        if (that.mColCode.length > 0 && Util.nvl(oData[i][that.mColCode], "") == "" && cc.mColName == that.mColName) {
                            a = "text-align:start ;width:" + wdth + " ";
                            styleadd += "font-weight:bold;";
                            spcAdd = Util.nvl(that.showSpaces, true) ? Util.charCount("\xa0\xa0", parseInt(oData[i][that.mColLevel])) : "";//"";//Util.charCount("\xa0\xa0", parseInt(oData[i][that.mColLevel]));
                        }
                        if ((cc.getMUIHelper().display_format == "QTY_FORMAT" ||
                            cc.getMUIHelper().display_format == "MONEY_FORMAT") &&
                            that.hideTotals && parseInt(oData[i][that.mColChild]) > 0)
                            cellValue = "";

                        styleadd += a;
                        styleadd = (styleadd.length > 0 ? ' style="' : "") + styleadd + (styleadd.length > 0 ? '"' : "");
                        classadd += (that.fnOnCellAddClass != undefined ? Util.nvl(that.fnOnCellAddClass(oData, i, v), "") : "");
                        classadd = (classadd.length > 0 ? ' class="' : "") + classadd + (classadd.length > 0 ? '"' : "");
                        var onclickcell = " onclick=\"" + (that.fnOnCellClick != undefined ? Util.nvl(that.fnOnCellClick(oData, i, v), "") : "") + "\"";
                        tmpv2 = (tmpv2.length > 0 ? ' colspan="' : "") + tmpv2 + (tmpv2.length > 0 ? '"' : "");
                        if (that.fnOnCellValue != undefined)
                            cellValue = Util.nvl(that.fnOnCellValue(oData, i, v, cellValue), cellValue);
                        rs += "<td" + tmpv2 + classadd + styleadd + onclickcell + " > " + Util.nvl(Util.htmlEntities(spcAdd + cellValue), "") + "</td>";
                    }

                    rs = "<tr class='html_table_row1'>" + rs + "</tr>";//+strch ;

                    var child = [];
                    for (var v in oData[i]) {
                        child = []
                        if (v.startsWith("childeren_")) {
                            child.push(oData[i][v]);
                            rs += _getRowData2(0, child);
                        }
                    }

                    return rs;
                }
                var footerCodes = {};

                var sett = sap.ui.getCore().getModel("settings").getData();
                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                var dfq = new DecimalFormat(sett["FORMAT_QTY_1"]);
                var sf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);
                var minLevel = (that.mColLevel.length > 0 && lctb.rows.length) > 1 ? parseInt(lctb.getFieldValue(0, that.mColLevel)) : 0;

                // looping mctb..
                //resetting footers to null..
                for (var k = 0; k < lctb.cols.length; k++) {
                    var cn = lctb.cols[k].mColName;
                    footer[cn] = null;
                }
                (recalcCHildCount ? calcChildCount() : "");
                for (var i = 0; i < lctb.rows.length; i++) {
                    var current_parent = "";
                    var current_code = lctb.getFieldValue(i, that.mColCode) + "";
                    // var current_title = lctb.getFieldValue(i, that.mColName) + "";
                    current_parent = lctb.getFieldValue(i, that.mColParent) + "";

                    if (current_parent.length > 0) {
                        if (lastParent == current_parent)
                            rootNode = lastParentNode;
                        else {
                            rootNode = findNodebyVal(current_parent);
                            lastParent = current_parent;
                            lastParentNode = rootNode;
                        }
                    }
                    else
                        rootNode = null;
                    var oNode1 = null;
                    var v = "";
                    var chlds = (that.mColChild.length > 0 ? lctb.getFieldValue(i, that.mColChild) : 0);
                    var footerg = undefined;
                    if (chlds > 0) {
                        footerCodes[current_code] = {};
                        footerg = footerCodes[current_code];
                    }
                    //defining node
                    for (var k = 0; k < lctb.cols.length; k++) {
                        var vl = lctb.getFieldValue(i, lctb.cols[k].mColName);
                        var lvl = -1;
                        if (that.mColLevel.length > 0)
                            lvl = lctb.getFieldValue(i, that.mColLevel);

                        vl = (Util.nvl(vl, "") + "").replace(/\"/g, "'").replace(/\n/, "\\r").replace(/\r/, "\\r").replace(/\\/g, "\\\\").trim();

                        if (lctb.cols[k].mSummary == "SUM" && chlds > 0) {
                            var cn = lctb.cols[k].mColName;
                            footerg[cn] = (Util.nvl(footerg[cn], 0) == 0 ? 0 : Util.nvl(footerg[cn], 0)) + parseFloat(Util.nvl(vl, '0'));
                        } else if (chlds > 0)
                            footerg[lctb.cols[k].mColName] = null;



                        if (lctb.cols[k].mSummary == "SUM" && lvl == minLevel) {
                            var cn = lctb.cols[k].mColName;
                            footer[cn] = (Util.nvl(footer[cn], 0) == 0 ? 0 : Util.nvl(footer[cn], 0)) + parseFloat(Util.nvl(vl, '0'));

                        }
                        if (lctb.cols[k].getMUIHelper().data_type == "NUMBER" &&
                            lctb.cols[k].getMUIHelper().display_format == "MONEY_FORMAT") {
                            vl = (vl.length == 0 ? "" : df.format(parseFloat(vl)));
                        }

                        if (lctb.cols[k].getMUIHelper().data_type == "NUMBER" &&
                            lctb.cols[k].getMUIHelper().display_format == "QTY_FORMAT") {
                            vl = (vl.length == 0 ? "" : dfq.format(parseFloat(vl)));
                        }
                        if (lctb.cols[k].getMUIHelper().data_type == "NUMBER" &&
                            lctb.cols[k].valOnZero != undefined && parseFloat(vl) == 0) {
                            vl = lctb.cols[k].valOnZero;
                        }


                        if (lctb.cols[k].getMUIHelper().data_type == "DATE" &&
                            lctb.cols[k].getMUIHelper().display_format == "SHORT_DATE_FORMAT") {
                            var dt = new Date(Util.nvl(vl, "").replaceAll(".", ":"));
                            vl = dt;// sf.format(dt);
                        }
                        if (lctb.cols[k].getMUIHelper().data_type != "DATE" &&
                            lctb.cols[k].getMUIHelper().display_format == "SHORT_DATE_FORMAT") {
                            var dt = new Date(Util.nvl(vl, "").replaceAll(".", ":"));
                            vl = sf.format(dt);
                        }


                        v += (v.length == 0 ? "" : ",") + '"' +
                            lctb.cols[k].mColName + '":"' +
                            vl + '"';
                        if (k == lctb.cols.length - 1)
                            v += (v.length == 0 ? "" : ",") + "\"_rowid\":" + i;

                    }

                    //v = v.replace(/\\/g, "\\\\");
                    oNode1 = JSON.parse("{" + Util.nvl(v, "") + "}");


                    if (rootNode == null || rootNode == undefined) {
                        itemsByID.push(oNode1);
                    }
                    else {
                        rootNode["childeren_" + i] = oNode1;
                    }
                    mapNodes[current_code] = oNode1;
                }
                //that.mTree.setFixedBottomRowCount(-1);
                if (!Util.nvl(that.hideSubTotals, false))
                    for (var fg in footerCodes) {
                        mapNodes[fg]["childeren_-999"] = footerCodes[fg]
                        if (that.mColName.length > 0) {
                            footerCodes[fg][that.mColName] = Util.getLangText("totalTxt") + " " + findNodebyVal(fg)[that.mColName];
                            if (that.fnOnAddTotalRow != undefined)
                                that.fnOnAddTotalRow(footerCodes[fg], findNodebyVal(fg)); // parameter: total row and mapNodes[fg]
                        }

                    }

                if (Util.nvl(that.showFooter, false))
                    if (footer != {}) {
                        for (var f in footer) {
                            if (lctb.getColByName(f).getMUIHelper().display_format == "MONEY_FORMAT")
                                footer[f] = df.format(footer[f]);
                            if (lctb.getColByName(f).getMUIHelper().display_format == "QTY_FORMAT")
                                footer[f] = dfq.format(footer[f]);
                        }
                        if (that.mColName.length > 0)
                            footer[that.mColName] = Util.getLangText("totalTxt");
                        if (that.fnOnFooter != undefined)
                            that.fnOnFooter(footer); // parameter: total row and mapNodes[fg]
                        itemsByID.push(footer);

                        // this.mTree.setFixedBottomRowCount(1);
                    }

                var str = getHTMLText(itemsByID);
                return str;
                // return itemsByID;
            },
            getMonthTitleCrossTable: function (lc) {
                //for month lable..
                var monthsEn = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
                var monthsAr = ["يناير", "فبراير", "مارس", "أبريل", "مايو", "يونيو", "يوليو", "أغسطس", "سبتمبر", "أكتوبر", "نوفمبر", "ديسمبر"];
                for (var li = 0; li < lc.cols.length; li++) {
                    if (Util.nvl(lc.cols[li].ct_val, "N") == "Y") {
                        var tit = parseInt(lc.cols[li].mTitle.split("_")[1]);
                        if (lc.cols[li].mColName.startsWith("tot__"))
                            lc.cols[li].mTitle = Util.getLangText("totalTxt");
                        else
                            lc.cols[li].mTitle = (UtilGen.DBView.sLangu == "AR" ? monthsAr[tit - 1] : monthsEn[tit - 1]) + "-" + lc.cols[li].mTitle.split("_")[0];
                    }
                }
            },
            setGrowthAvgRate: function (lc, fld, agrFld, calcBal, fmt) {
                var dfq1 = new DecimalFormat(Util.nvl(fmt, "#,##0"));
                for (var ri = 0; ri < lc.rows.length; ri++) {
                    var bl = [], grs = [];
                    for (var li = 0; li < lc.cols.length; li++) {
                        if (bl.length == 0 && lc.cols[li].mColName.endsWith("__" + fld) && lc.cols[li].mColName != "tot__" + fld) {
                            bl.push(lc.getFieldValue(ri, lc.cols[li].mColName));
                            grs.push(0);
                            continue;
                        }
                        if (bl.length > 0 && lc.cols[li].mColName.endsWith("__" + fld) && lc.cols[li].mColName != "tot__" + fld)
                            if (bl[bl.length - 1] != 0) {
                                var tbl = lc.getFieldValue(ri, lc.cols[li].mColName);
                                if (Util.nvl(calcBal, false))
                                    tbl += bl[bl.length - 1];
                                grs.push(((tbl / bl[bl.length - 1]) - 1) * 100);
                                bl.push(tbl);
                            }
                    }
                    if (grs.length > 1) {
                        var agr = 0; var tot = 0;
                        grs.forEach(ky => {
                            tot += ky;
                        });
                        agr = Math.round(tot / (grs.length - 1));
                        lc.setFieldValue(ri, Util.nvl(agrFld, "AGR"), (agr == 0) ? "" :
                            (agr < 0 ? "(" + dfq1.format(Math.abs(agr)) + "%)" : dfq1.format(agr) + "%"));
                    } else
                        lc.setFieldValue(ri, Util.nvl(agrFld, "AGR"), "");

                }
            },
            setAvg: function (lc, fld, agrFld, fmt) {
                //for growth average rate                
                var dfq1 = new DecimalFormat(Util.nvl(fmt, "#,##0"));
                for (var ri = 0; ri < lc.rows.length; ri++) {
                    var grs = [];
                    for (var li = 0; li < lc.cols.length; li++) {
                        if (lc.cols[li].mColName.endsWith("__" + fld) && lc.cols[li].mColName != "tot__" + fld)
                            grs.push(lc.getFieldValue(ri, lc.cols[li].mColName));
                    }
                    if (grs.length > 1) {
                        var agr = 0; var tot = 0;
                        grs.forEach(ky => {
                            tot += ky;
                        });
                        agr = Math.round(tot / (grs.length));
                        lc.setFieldValue(ri, Util.nvl(agrFld, "AGR"), (agr == 0) ? "" :
                            (agr < 0 ? "(" + dfq1.format(Math.abs(agr)) + ")" : dfq1.format(agr) + ""));
                    } else
                        lc.setFieldValue(ri, Util.nvl(agrFld, "AGR"), "");

                }
            },
            createDefaultToolbar1: function (qrj, findCols, addSpace, pOnDel, pOnAdd, showDel, showAdd, fnAddCmds, showNewWnd) {
                qrj.createToolbar("", [],
                    // EVENT ON APPLY PERSONALIZATION
                    function (prsn, qv) {
                    },
                    // EVENT ON REVERT PERSONALIZATION TO ORIGINAL
                    function (qv) {
                    }
                );
                var txt = undefined;
                var btf = undefined;
                if (Util.nvl(findCols, []).length > 0) {
                    txt = new sap.m.Input({ width: "100px" });
                    btf = new sap.m.Button({
                        icon: "sap-icon://sys-find",
                        tooltip: "click to find next..",
                        press: function () {
                            var bi = 0;
                            if (qrj.getControl().getSelectedIndices().length > 0) {
                                bi = qrj.getControl().getSelectedIndices()[0] + 1;
                            }
                            var rn = qrj.mLctb.findAny(findCols, txt.getValue(), bi);
                            if (rn < 0) {
                                qrj.getControl().setSelectedIndex(-1);
                                return;
                            }
                            qrj.getControl().setSelectedIndex(rn);
                            if (rn > 1) {
                                qrj.getControl().setFirstVisibleRow(rn - 1);
                            } else
                                qrj.getControl().setFirstVisibleRow(rn);
                        }
                    });
                }
                var btDelRow = new sap.m.Button({
                    icon: "sap-icon://sys-minus",
                    tooltip: "select and delete a row ",
                });
                var onAdd = function () {

                    var rowno = -1;
                    var colno = -1;
                    if (qrj.getControl().getSelectedIndices().length == 0)
                        try {
                            const currentFocusedControlId = sap.ui.getCore().getCurrentFocusedControlId();
                            var _input = sap.ui.getCore().byId(currentFocusedControlId);
                            // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                            rowno = qrj.getControl().indexOfRow(_input.getParent());
                            colno = _input.getParent().indexOfCell(_input);
                            qrj.getControl().setSelectedIndex(rowno);
                        }
                        catch (e) { };
                    var sl = qrj.getControl().getSelectedIndices()[0];

                    if (pOnAdd != undefined)
                        pOnAdd(sl);
                    else {
                        if (Util.nvl(sl, -1) != -1)
                            qrj.insertRow(sl);
                        else qrj.addRow();
                    }
                };
                var onDel = function () {

                    var rowno = -1;
                    var colno = -1;
                    if (qrj.getControl().getSelectedIndices().length == 0) {
                        const currentFocusedControlId = sap.ui.getCore().getCurrentFocusedControlId();
                        if (Util.nvl(currentFocusedControlId, "") == "" ||
                            sap.ui.getCore().byId(currentFocusedControlId) == undefined ||
                            sap.ui.getCore().byId(currentFocusedControlId).indexOfRow == undefined
                        ) setTimeout(function () {
                            FormView.err("Selection may invalid !");
                        });
                        var _input = sap.ui.getCore().byId(currentFocusedControlId);
                        // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                        rowno = qrj.getControl().indexOfRow(_input.getParent());
                        colno = _input.getParent().indexOfCell(_input);
                        qrj.getControl().setSelectedIndex(rowno);
                    }

                    if (qrj.getControl().getSelectedIndices().length == 0) {
                        sap.m.MessageToast.show("Must select a row !");
                        return;
                    }

                    var sl = qrj.getControl().getSelectedIndices();
                    if (pOnDel != undefined)
                        pOnDel(sl);
                    else
                        for (var s = sl.length - 1; s >= -1; s--)
                            qrj.deleteRow(sl[s]);
                };

                btDelRow.attachBrowserEvent("mousedown", onDel);
                var btAddRow = new sap.m.Button({
                    icon: "sap-icon://sys-add",
                    tooltip: "select add a row ",
                });
                btAddRow.attachBrowserEvent("mousedown", onAdd);
                qrj.showToolbar.toolbar.removeAllContent();
                qrj.showToolbar.toolbar.addStyleClass("toolBarBackgroundColor1");
                if (Util.nvl(showAdd, true))
                    qrj.showToolbar.toolbar.addContent(btAddRow);
                if (Util.nvl(showDel, true))
                    qrj.showToolbar.toolbar.addContent(btDelRow);
                if (fnAddCmds != undefined)
                    fnAddCmds(qrj.showToolbar.toolbar);


                if (Util.nvl(addSpace, false))
                    qrj.showToolbar.toolbar.addContent(new sap.m.ToolbarSpacer());
                if (Util.nvl(findCols, []).length > 0) {
                    qrj.showToolbar.toolbar.addContent(txt);
                    qrj.showToolbar.toolbar.addContent(btf);
                }
                if (Util.nvl(showNewWnd, true)) {
                    var bw = new sap.m.Button({
                        icon: "sap-icon://full-screen", press: function () {
                            qrj.createNewWnd();
                        }
                    });
                    qrj.showToolbar.toolbar.addContent(bw);
                }

            },
            createDefaultToolbar2: function (qrj, findCols, addSpace) {
                if (Util.nvl(findCols, []).length > 0) {
                    qrj.showToolbar.filterCols = findCols;
                    qrj.showToolbar.showFilter = true;
                    qrj.showToolbar.showSearch = false;

                    var txt = new sap.m.Input({ width: "100px" });
                    var btf = new sap.m.Button({
                        icon: "sap-icon://sys-find",
                        tooltip: "click to find next..",
                        press: function () {
                            var bi = 0;
                            if (qrj.getControl().getSelectedIndices().length > 0) {
                                bi = qrj.getControl().getSelectedIndices()[0] + 1;
                            }
                            var rn = qrj.mLctb.findAny(findCols, txt.getValue(), bi);
                            if (rn < 0) {
                                qrj.getControl().setSelectedIndex(-1);
                                return;
                            }
                            qrj.getControl().setSelectedIndex(rn);
                            if (rn > 1) {
                                qrj.getControl().setFirstVisibleRow(rn - 1);
                            } else
                                qrj.getControl().setFirstVisibleRow(rn);
                        }
                    });
                    txt.attachBrowserEvent("keydown", function (e) {
                        if (e.key == 'Enter')
                            btf.firePress();
                    });

                }

                if (Util.nvl(addSpace, false))
                    qrj.showToolbar.toolbar.addContent(new sap.m.ToolbarSpacer());
                qrj.showToolbar.showPersonalization = false;
                qrj.createToolbar("", qrj.showToolbar.filterCols,
                    // EVENT ON APPLY PERSONALIZATION
                    function (prsn, qv) {
                    },
                    // EVENT ON REVERT PERSONALIZATION TO ORIGINAL
                    function (qv) {
                    }
                );
                if (Util.nvl(findCols, []).length > 0) {
                    qrj.showToolbar.toolbar.addContent(txt);
                    qrj.showToolbar.toolbar.addContent(btf);
                }

                qrj.showToolbar.toolbar.addStyleClass("toolBarBackgroundColor1");
            },
            inputDialog: function (title, msg, val, fnOk, fnCancel, width, height, pSet) {
                var setInp = { ...{ value: Util.nvl(val, "") }, ...Util.nvl(pSet, {}) };
                var inp = new sap.m.Input(setInp);
                var vb = new sap.m.VBox({
                    // alignItems: sap.m.FlexAlignItems.Center,
                    items: [new sap.m.Title({ text: Util.getLangText(msg) }), inp]
                }).addStyleClass("sapUiSmallMargin");
                inp.attachBrowserEvent("keydown", function (e) {
                    if (e.key == 'Enter')
                        btDone.firePress();
                });
                var btDone = new sap.m.Button({
                    text: Util.getLangText("cmdDone"),
                    icon: "sap-icon://accept",
                    press: function () {
                        if (fnOk != undefined)
                            if (Util.nvl(fnOk(inp.getValue()), true)) {
                                dlg.closeFromOk = true;
                                dlg.close();
                            }
                            else {
                                setTimeout(() => { inp.focus(); inp.selectText(0, 999); }, 500);
                                FormView.err(Util.getLangText("msgDeniedInputDlg"));
                            }
                    }
                });
                var btCancel = new sap.m.Button({
                    text: Util.getLangText("cmdClose"),
                    icon: "sap-icon://decline",
                    press: function () {
                        dlg.close();
                        if (fnCancel != undefined)
                            fnCancel();
                    }
                });

                var dlg = new sap.m.Dialog({
                    title: Util.getLangText(title),
                    contentWidth: Util.nvl(width, "400px"),
                    contentHeight: Util.nvl(height, "100px"),
                    content: vb,
                    buttons: [btDone,
                        btCancel
                    ]
                });
                dlg.attachAfterClose(function () {
                    if (Util.nvl(dlg.closeFromOk, false))
                        return;

                    if (fnCancel != undefined)
                        fnCancel();
                });
                dlg.open();
                setTimeout(function () {
                    inp.focus();
                    inp.selectText(0, 999);
                }, 100);
            },

            // grpname: , tablename: , rec_stat: , descr: , pvar1: , pvar2: pvar3: , pvar4: , pvar5: , notify_type:
            getInsertLogStr: function (setx, condStr) {
                var sett = sap.ui.getCore().getModel("settings").getData();
                var log = true;
                var user = sett["LOGON_USER"];
                if (Util.nvl(setx.notify_type, "") != "" && Util.nvl(condStr, "") != "") {
                    var sqN = Util.getSQLValue("select nvl(count(*),0) from C7_NOTIFY_SETUP where setup_type='" + setx.notify_type + "' and CONDITION_STR='" + condStr + "'");
                    if (sqN != 0)
                        log = true;
                    else log = false;
                }
                if (!log) return "";
                var sqx = "c7_insert_log_proc(':GRPNAME'," +
                    "':USERNAME',':TABLENAME',':REC_STAT',':DESCR' " +
                    ",':PVAR1',':PVAR2',':PVAR3',':PVAR4',':PVAR5',':NOTIFY_TYPE',':ADVANCE_DATA'); ";
                sqx = sqx.replaceAll(":GRPNAME", setx.grpname)
                    .replaceAll(":USERNAME", user)
                    .replaceAll(":TABLENAME", setx.tablename)
                    .replaceAll(":REC_STAT", setx.rec_stat)
                    .replaceAll(":DESCR", setx.descr)
                    .replaceAll(":PVAR1", Util.nvl(setx.pvar1, ""))
                    .replaceAll(":PVAR2", Util.nvl(setx.pvar2, ""))
                    .replaceAll(":PVAR3", Util.nvl(setx.pvar3, ""))
                    .replaceAll(":PVAR4", Util.nvl(setx.pvar4, ""))
                    .replaceAll(":PVAR5", Util.nvl(setx.pvar5, ""))
                    .replaceAll(":NOTIFY_TYPE", Util.nvl(setx.notify_type, ""))
                    .replaceAll(":ADVANCE_DATA", Util.nvl(setx.advance_data, ""));
                return sqx;
            },
            showPropDialog: function (props) {
                // if (props == undefined) return;
                // var kys = Object.keys(prop);
                // var fe = [];
                // for (var k = 0; k < kys.length; k++) {

                // }
            },
            addDetailSetupCmd: function (settings) {
                if (settings == undefined) return;
                var activeObj = undefined;
                var selecedRow = undefined;

                var addColSetup = function (applyCol) {
                    var fnApply = function (qv, applyCol) {
                        var sett = sap.ui.getCore().getModel("settings").getData();
                        var pn = sett["PROFILENO"];
                        qv.updateDataToTable();
                        var ld = qv.mLctb;
                        var inSql = "insert into cp_setcols " +
                            "(PROFILE, SETGRPCODE, ITEM_NAME, DISPLAY_TYPE, DISPLAY_WIDTH, DESCR, DESCRA, POSITION, GETFOCUS, ALIGN, USE_FORMAT, EDITOR_CLASS, LOV_SQL, OTHER_STYLES, LOOKUP_COLUMN, DEFAULT_VALUE, RETURN_VALUES, PARAMS, VALIDATE_EVENT, MULTISELECT, HIDE_COLS) " +
                            " select :PROFILENO, SETGRPCODE, ITEM_NAME, DISPLAY_TYPE, DISPLAY_WIDTH, DESCR, DESCRA, POSITION, GETFOCUS, ALIGN, USE_FORMAT, EDITOR_CLASS, LOV_SQL, OTHER_STYLES, LOOKUP_COLUMN, DEFAULT_VALUE, RETURN_VALUES, PARAMS, VALIDATE_EVENT, MULTISELECT, HIDE_COLS " +
                            " from cp_setcols where  profile=0 and setgrpcode=':APPLYCOL'; ";
                        var delSql = (pn != 0 ? "delete from cp_setcols where profile=:PROFILENO and setgrpcode=':APPLYCOL';" + inSql
                            : "");
                        var updSql = "";
                        var wrSq = " profile=:PROFILENO and setgrpcode=':APPLYCOL' and item_name='";
                        for (var i = 0; i < ld.rows.length; i++) {
                            var tmpsq = "update cp_setcols " +
                                " set display_width=" + ld.getFieldValue(i, "DISPLAY_WIDTH") +
                                ", display_type='" + ld.getFieldValue(i, "DISPLAY_TYPE") + "'" +
                                ", position='" + ld.getFieldValue(i, "POSITION") + "'" +
                                ", align='" + ld.getFieldValue(i, "ALIGN") + "'" +
                                " where " + wrSq + ld.getFieldValue(i, "ITEM_NAME") + "';";
                            updSql += tmpsq;
                        }
                        var sqle = "begin " + delSql + updSql + "end;";
                        sqle = sqle.replaceAll(":APPLYCOL", applyCol)
                            .replaceAll(":PROFILENO", pn);
                        var dt = Util.execSQL(sqle);
                        if (dt.ret == "SUCCESS") {
                            FormView.msgSuccess(Util.getLangText("msgSaved"));
                            return true;
                        }
                        if (dt != undefined && dt.ret != "SUCCESS")
                            UtilGen.showCustomMessageToast("Error in saving..." + dt.ret, 100, "red", "#fff");
                        return false;
                    }
                    var fnExe = function (applyCol) {
                        var sett = sap.ui.getCore().getModel("settings").getData();
                        var pn = sett["PROFILENO"];
                        var sq = "select SETGRPCODE,ITEM_NAME,POSITION,DESCR,DISPLAY_TYPE,DISPLAY_WIDTH," +
                            "GETFOCUS,ALIGN from cp_setcols where setgrpcode='" +
                            applyCol + "' and (profile=" + pn + " or profile=0) order by position";
                        var qv = new QueryView("qrCols" + (new Date()).getTime());
                        qv.getControl().setEditable(true);
                        qv.getControl().view = UtilGen.DBView;
                        qv.getControl().addStyleClass("sapUiSizeCondensed sapUiSmallMarginTop");
                        qv.getControl().setSelectionMode(sap.ui.table.SelectionMode.Single);
                        qv.getControl().setFixedBottomRowCount(0);
                        qv.getControl().setVisibleRowCountMode(sap.ui.table.VisibleRowCountMode.Auto);
                        UtilGen.createDefaultToolbar1(qv, ["DESCR"], false, undefined, undefined, false, false);
                        qv.showToolbar.toolbar.addContent(new sap.m.ToolbarSpacer());
                        qv.insertable = false;
                        qv.deletable = false;
                        qv.editable = true;
                        var dt = Util.execSQL(sq);
                        if (dt.ret == "SUCCESS") {
                            qv.setJsonStrMetaData("{" + dt.data + "}");

                            Util.setColProp(qv, "SETGRPCODE", "mHideCol", true);
                            Util.setColProp(qv, "ITEM_NAME", "mHideCol", true);
                            Util.setColProp(qv, "GETFOCUS", "mHideCol", true);

                            Util.setColProperties(qv, "DESCR", {
                                "mTitle": "Descr",
                                "display_width": 220,
                            });

                            Util.setColProperties(qv, "DISPLAY_TYPE", {
                                "mColClass": "sap.m.Input",
                                "mTitle": "Display Type",
                                "display_width": 100,
                            });
                            Util.setColProperties(qv, "DISPLAY_WIDTH", {
                                "mColClass": "sap.m.Input",
                                "mTitle": "Width",
                                "display_width": 100,
                            });
                            Util.setColProperties(qv, "POSITION", {
                                "mColClass": "sap.m.Input",
                                "mTitle": "POS",
                                "display_width": 80,
                            });
                            Util.setColProperties(qv, "ALIGN", {
                                "mColClass": "sap.m.Input",
                                "mTitle": "Align",
                                "display_width": 130,
                            });

                            // qv.mLctb.cols[qv.mLctb.getColPos("GETFOCUS")].mColClass = "sap.m.Input";

                            qv.mLctb.parse("{" + dt.data + "}", true);
                            var ld = qv.mLctb;
                            for (var i = 0; i < ld.rows.length; i++)
                                ld.setFieldValue(i, "DESCR", Util.getLangText(ld.getFieldValue(i, "DESCR")));
                            qv.loadData();


                        }

                        var pg = new sap.m.Page({
                            showHeader: true,
                            content: [],
                            showFooter: true
                        }).addStyleClass("sapUiSizeCompact");
                        var tbHeader = new sap.m.Toolbar();
                        pg.setFooter(tbHeader);
                        pg.removeAllHeaderContent();
                        pg.addHeaderContent(qv.showToolbar.toolbar);
                        pg.addContent(qv.getControl());

                        var dlg = new sap.m.Dialog({
                            title: "Advance Column Setup",
                            contentWidth: UtilGen.dispWidthByDevice({ "S": 100, "M": 70, "L": 70, "XL": 40 }) + "%",
                            contentHeight: "400px",
                            content: pg,
                            buttons: [
                                new sap.m.Button({
                                    text: Util.getLangText("saveRec"),
                                    icon: "sap-icon://accept",
                                    press: function () {
                                        if (fnApply(qv, applyCol))
                                            dlg.close();
                                    }

                                }),
                                new sap.m.Button({
                                    text: Util.getLangText("cmdClose"),
                                    press: function () {
                                        dlg.close();
                                    }
                                })

                            ]
                        });
                        dlg.open();
                    }
                    fnExe(applyCol);
                }
                var getMenus = function () {
                    var mnus = [];
                    if (settings.applyCol != undefined)
                        mnus.push(new sap.m.MenuItem({
                            icon: "sap-icon://column-chart-dual-axis",
                            text: Util.getLangText("itemInfoColSet"),
                            press: function () {
                                addColSetup(settings.applyCol);
                            }
                        }));
                    if (settings.fnAddMenus != undefined)
                        settings.fnAddMenus(mnus);
                    var mnu = new sap.m.Menu({
                        items: mnus
                    });
                    return mnu;
                }
                var cmdDetailSetCmd = new sap.m.Button({
                    icon: "sap-icon://settings",
                    press: function () {
                        this.focus();
                        var mnu = getMenus();
                        mnu.openBy(cmdDetailSetCmd);
                    }
                });
                cmdDetailSetCmd.attachBrowserEvent("mousedown", function () {
                    activeObj = sap.ui.getCore().getCurrentFocusedControlId();
                });
                return cmdDetailSetCmd;

            },
            addItemsInfoCmd: function (settings) {
                if (settings == undefined) return;
                var activeObj = undefined;
                var selecedRow = undefined;
                var sett = sap.ui.getCore().getModel("settings").getData();
                var df = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);
                var thatForm = settings.thatForm;
                var qrj = settings.qrj;
                var itemField = Util.nvl(settings.itemField, "ORD_REFER");
                var storeField = Util.nvl(settings.storeField, "STRA");
                var itemDescrField = Util.nvl(settings.itemDescrField, "DESCR");
                var qryDate = Util.nvl(settings.qryDate, "qry1.ord_date");
                var fromdate = sap.ui.getCore().getModel("fiscalData").getData().fiscal_from;
                var fnCallBack = Util.nvl(settings.fnCallBack, undefined);

                var ld = (Util.nvl(qrj, undefined) != undefined ? qrj.mLctb : undefined);
                var getRowSel = function () {
                    var rowno = -1;
                    var colno = -1;
                    // if (qrj.getControl().getSelectedIndices().length == 0) {
                    const currentFocusedControlId = activeObj;
                    if (currentFocusedControlId == undefined) return undefined;
                    var _input = sap.ui.getCore().byId(currentFocusedControlId);
                    // if (_input != undefined || (!_input.getParent() instanceof sap.ui.table.Row)) return;
                    rowno = qrj.getControl().indexOfRow(_input.getParent());
                    colno = _input.getParent().indexOfCell(_input);
                    qrj.getControl().setSelectedIndex(rowno);
                    // }

                    if (qrj.getControl().getSelectedIndices().length == 0) {
                        sap.m.MessageToast.show("Must select a row !");
                        return undefined;
                    }

                    var sl = qrj.getControl().getSelectedIndices();
                    selecedRow = sl;
                };
                var showAllStoreDialog = function (sqdt, dtx) {

                    qrj.updateDataToTable();
                    var i1 = selecedRow[0];
                    var rfr = ld.getFieldValue(i1, itemField);
                    var descr = ld.getFieldValue(i1, itemDescrField);
                    var odt = Util.toOraDateString(thatForm.frm.getFieldValue(qryDate));

                    var str = (storeField.indexOf(".") >= 0) ? thatForm.frm.getFieldValue(storeField) :
                        ld.getFieldValue(i1, storeField);
                    var sq = "select descr,childcounts,packd,unitd,pack," +
                        " C7_GET_STORE_ITEM_ALLQTY_RSRV(reference,'')/items.pack rsrv, " +
                        " prd_dt,exp_dt from items where reference=':rfr'";
                    sq = sq.replaceAll(":ordate", odt)
                        .replaceAll(":rfr", rfr)
                        .replaceAll(":store", str);

                    var sq2 = "select no,name," +
                        "C7_GET_STORE_ITEM_ALLQTY(':rfr',:ordate,no)/:PACK qih , " +
                        " ':PACKD' PACKD ,':UNITD' UNITD, :PACK PACK " +
                        " from store where flag=1 order by no ";
                    var sqdt = Util.execSQLWithData(sq);
                    if (sqdt.length > 0) {
                        sq2 = sq2.replaceAll(":PACKD", sqdt[0].PACKD)
                            .replaceAll(":PACK", sqdt[0].PACK)
                            .replaceAll(":ordate", odt)
                            .replaceAll(":rfr", rfr)
                            .replaceAll(":UNITD", sqdt[0].UNITD);
                        UtilGen.Search.do_quick_search_simple(sq2,
                            ["NO", "NAME"], function (data) {
                                if (fnCallBack != undefined)
                                    fnCallBack(i1, data, "showQtyAllStore");
                            }, { pWidth: "40%" }, undefined, undefined, "Item : " + rfr + " - " + descr, [
                            {
                                NO: {
                                    colname: "NO",
                                    display_width: 50,
                                    mTitle: Util.getLangText("locationTxt"),
                                },
                            },

                        ]);
                    }
                };
                var getMenus = function () {
                    var mnus = [];
                    if (Util.nvl(activeObj, undefined) != undefined &&
                        Util.nvl(selecedRow, []).length > 0) {
                        if (Util.nvl(settings.showStockCard, true))
                            mnus.push(new sap.m.MenuItem({
                                icon: "sap-icon://list",
                                text: Util.getLangText("stkCardRepTit") + ((ld != undefined &&
                                    selecedRow != undefined &&
                                    selecedRow.length > 0) ? " - " + ld.getFieldValue(selecedRow[0], itemField) : ""),
                                press: function () {
                                    qrj.updateDataToTable();
                                    var itm = ld.getFieldValue(selecedRow[0], itemField);
                                    var str = (storeField.indexOf(".") >= 0) ? thatForm.frm.getFieldValue(storeField) :
                                        ld.getFieldValue(selecedRow[0], storeField);
                                    var todt = df.format(thatForm.frm.getFieldValue(qryDate));
                                    UtilGen.execCmd("rp.in.st2 formType=dialog formSize=100%,100% repno=0 store=" + str +
                                        " para_PARAFORM=false para_EXEC_REP=true prefer=" + itm + " fromdate=@" + fromdate + " todate=@" + todt, UtilGen.DBView, this, UtilGen.DBView.newPage);
                                }
                            }));
                        if (Util.nvl(settings.showQtyStore, true))
                            mnus.push(new sap.m.MenuItem({
                                icon: "sap-icon://list",
                                text: Util.getLangText("sbRepTit") + ((ld != undefined &&
                                    selecedRow != undefined &&
                                    selecedRow.length > 0) ? " - " + ld.getFieldValue(selecedRow[0], itemField) : ""),
                                press: function () {
                                    qrj.updateDataToTable();
                                    var i1 = selecedRow[0];
                                    var rfr = ld.getFieldValue(i1, itemField);
                                    var descr = ld.getFieldValue(i1, itemDescrField);
                                    var odt = Util.toOraDateString(thatForm.frm.getFieldValue(qryDate));
                                    var str = (storeField.indexOf(".") >= 0) ? thatForm.frm.getFieldValue(storeField) :
                                        ld.getFieldValue(i1, storeField);
                                    var sq = "select descr,childcounts,packd,unitd,pack,(select max(name) from store where no=:store ) strname ," +
                                        " C7_GET_STORE_ITEM_ALLQTY(reference,:ordate,:store)/items.pack qih, " +
                                        " prd_dt,exp_dt from items where reference=':rfr'";
                                    sq = sq.replaceAll(":ordate", odt)
                                        .replaceAll(":rfr", rfr)
                                        .replaceAll(":store", str);

                                    var sqdt = Util.execSQLWithData(sq);
                                    if (sqdt.length > 0) {
                                        var strStr = str != 0 ? " - Store # " + str + "-" + sqdt[0].STRNAME : "All store -";
                                        var msgstr = sqdt[0].QIH + " " + sqdt[0].PACKD + " , Item:  " + rfr + "- " + descr + ", " + strStr + " , ";
                                        UtilGen.showCustomMessageToast(msgstr, 100);
                                    }
                                }
                            }));

                        if (Util.nvl(settings.showQtyAllStore, true))
                            mnus.push(new sap.m.MenuItem({
                                icon: "sap-icon://list",
                                text: Util.getLangText("sbRepTit") + ((ld != undefined &&
                                    selecedRow != undefined &&
                                    selecedRow.length > 0) ? " - " + ld.getFieldValue(selecedRow[0], itemField) : ""),
                                press: function () {
                                    showAllStoreDialog();
                                }
                            }));
                    }

                    var mnu = new sap.m.Menu({
                        items: mnus
                    });
                    return mnu;
                }
                var cmdSet = new sap.m.Button({
                    icon: "sap-icon://information",
                    press: function () {
                        try {
                            getRowSel();
                        } catch (m) { console.log(m); };
                        this.focus();
                        var mnu = getMenus();
                        mnu.openBy(cmdSet);
                    }
                });
                cmdSet.attachBrowserEvent("mousedown", function () {
                    activeObj = sap.ui.getCore().getCurrentFocusedControlId();
                });
                return cmdSet;
            },
            showMsgStoreBal: function (rfr, stra, pDescr, pDate) {
                // var rfr = ld.getFieldValue(i1, itemField);
                var descr = Util.nvl(pDescr, Util.getSQLValue("select descr from items where reference='" + rfr + "'"));
                var odt = Util.toOraDateString(Util.nvl(pDate, new Date()));
                var str = Util.nvl(stra, 0);
                var fnqty = str != 0 ? " C7_GET_STORE_ITEM_ALLQTY(reference,:ordate,:store)/items.pack qih, " :
                    "C7_GET_STORE_ITEM_ALLQTY(reference,:ordate)/items.pack qih,";
                var sq = "select descr,childcounts,packd,unitd,pack,(select max(name) from store where no=:store ) strname ," +
                    fnqty +
                    " prd_dt,exp_dt from items where reference=':rfr'";
                sq = sq.replaceAll(":ordate", odt)
                    .replaceAll(":rfr", rfr)
                    .replaceAll(":store", str);

                var sqdt = Util.execSQLWithData(sq);
                var strStr = str != 0 ? " - Store # " + str + "-" + sqdt[0].STRNAME : "All store -";
                var msgstr = sqdt[0].QIH + " " + sqdt[0].PACKD + " , Item:  " + rfr + "- " + descr + ", " + strStr + " , ";
                if (sqdt.length > 0)
                    UtilGen.DashboardWidget.statusBarText(Util.getLangText(msgstr).substr(0, 255), false, undefined, false);
                // UtilGen.showCustomMessageToast(rfr + "- " + descr + ", " + strStr + " , " + sqdt[0].QIH + " " + sqdt[0].PACKD, 100);
            },
            getTableFromValidateEvent: function (evtx) {
                var info = {};
                info["row"] = evtx.getSource().getParent();
                info["column_no"] = evtx.getSource().getParent().indexOfCell(evtx.getSource());
                info["columns"] = evtx.getSource().getParent().getParent().getColumns();
                info["table"] = evtx.getSource().getParent().getParent(); // get table control.
                info["oModel"] = info["table"].getModel();
                info["rowStart"] = info["table"].getFirstVisibleRow(); //starting Row index
                info["currentRowoIndexContext"] = info["table"].getContextByIndex(info["rowStart"] + info["table"].indexOfRow(info["row"]));
                info["newValue"] = evtx.getSource().getValue();

                return info;
            },
            SalesOrderFunc: {
                initAction: {
                    none: 'none',
                    approve: 'approve',
                    issueDeliver: 'issueDeliver',
                    saleInvs: 'saleInvs',
                    closeSO: 'closeSO',
                },
                init: function (frag) {
                    this.frag = frag;
                },
                checkSOStatus: function (soKf, pRaiseErr) {
                    var raiseErr = Util.nvl(pRaiseErr, true);
                    var podt = Util.execSQLWithData("select nvl(max(ord_flag),-1) ord_flag," +
                        " nvl(max(ord_no),-1) ord_no,max(ordacc) ordacc, " +
                        " max(DELIVEREDQTY) DLV_QTY,MAX(ORDERDQTY) ORD_QTY , " +
                        "max(PURQTY) SOLD_QTY " +
                        " from pord1 where keyfld=" + soKf, "No data found !");
                    if (!raiseErr) return podt[0];

                    if (podt[0].ORD_FLAG < 0)
                        FormView.err("SO is not avaialble !");
                    if (podt[0].ORD_FLAG == 1)
                        FormView.err("SO is not approved !");
                    if (podt[0].ORD_FLAG >= 3)
                        FormView.err("SO is closed !");
                    return podt[0];

                }
            },
            SalesRetReqFunc: {
                initAction: {
                    none: 'none',
                    approve: 'approve',
                    issueRV: 'issueRV',
                    saleRets: 'saleRets',
                    closeSRR: 'closeSRR',
                },
                init: function (frag) {
                    this.frag = frag;
                },
                checkSOStatus: function (soKf, pRaiseErr) {
                    var raiseErr = Util.nvl(pRaiseErr, true);
                    var podt = Util.execSQLWithData("select nvl(max(ord_flag),-1) ord_flag," +
                        " nvl(max(ord_no),-1) ord_no,max(ordacc) ordacc, " +
                        " max(DELIVEREDQTY) DLV_QTY,MAX(ORDERDQTY) ORD_QTY , " +
                        "max(PURQTY) SOLD_QTY " +
                        " from pord1 where keyfld=" + soKf, "No data found !");
                    if (!raiseErr) return podt[0];

                    if (podt[0].ORD_FLAG < 0)
                        FormView.err("SO is not avaialble !");
                    if (podt[0].ORD_FLAG == 1)
                        FormView.err("SO is not approved !");
                    if (podt[0].ORD_FLAG >= 3)
                        FormView.err("SO is closed !");
                    return podt[0];

                }
            },


            PurchaseOrderFunc: {
                initAction: {
                    none: 'none',
                    approve: 'approve',
                    issueRV: 'issueRV',
                    purInvs: 'purInvs',
                    closePO: 'closePO',
                },
                init: function (frag) {
                    this.frag = frag;
                },
                //return data ORD_FLAG,ORD_NO
                checkPOStatus: function (poKf, pRaiseErr) {
                    var raiseErr = Util.nvl(pRaiseErr, true);
                    var podt = Util.execSQLWithData("select nvl(max(ord_flag),-1) ord_flag,nvl(max(ord_no),-1) ord_no,nvl(max(ordacc),'') ordacc from pord1 where keyfld=" + poKf, "No data found !");
                    if (!raiseErr) return podt[0];

                    if (podt[0].ORD_FLAG < 0)
                        FormView.err("PO is not avaialble !");
                    if (podt[0].ORD_FLAG == 1)
                        FormView.err("PO is not approved !");
                    if (podt[0].ORD_FLAG >= 3)
                        FormView.err("PO is closed !");
                    return podt[0];

                },

                copyDetails: function (frag, kinds, tables, recordSet) {
                    var thatForm = frag;
                    var copyItems = function () {
                        var selItems = function (cod, tbl) {
                            var sq = "SELECT ORD_NO,ORD_DATE,ORD_REF,ORD_REFNM,ord_amt,KEYFLD FROM PORD1 " +
                                " WHERE ORD_CODE=" + cod + " and ord_flag=2 ORDER BY KEYFLD desc ";
                            if (tbl == "PUR1")
                                sq = "SELECT INVOICE_NO ORD_NO,INVOICE_DATE ORD_DATE,C_CUS_NO ORD_REF,INV_REFNM ORD_REFNM,INV_AMT ord_amt,KEYFLD FROM PUR1 " +
                                    " WHERE INVOICE_CODE=" + cod + " and flag=2 ORDER BY KEYFLD desc ";
                            UtilGen.Search.do_quick_search_simple(sq,
                                ["ORD_NO", "ORD_DATE", "ORD_REF", "ORD_REFNM", "ORD_AMT"], function (data) {
                                    copyVouItems(data, cod, tbl);

                                }, { pWidth: "80%" }, undefined, true, Util.getLangText("titSalesOrder"), [
                                {
                                    ORD_NO: {
                                        colname: "ORD_NO",
                                        display_width: 80,
                                        mTitle: Util.getLangText("titPurOrd"),
                                    }
                                },
                                {
                                    ORD_DATE: {
                                        colname: "ORD_DATE",
                                        display_format: "SHORT_DATE_FORMAT",
                                        mTitle: Util.getLangText("ordDate"),
                                        display_width: 100
                                    }
                                },
                                {
                                    ORD_REF: {
                                        colname: "ORD_REF",
                                        mTitle: Util.getLangText("refCode"),
                                        display_width: 100,
                                    }
                                },
                                {
                                    ORD_REFNM: {
                                        colname: "ORD_REFNM",
                                        mTitle: Util.getLangText("refName"),
                                        display_width: 250

                                    }
                                },
                                {
                                    KEYFLD: {
                                        colname: 'KEYFLD',
                                        return_field: "pac",
                                        hide: true
                                    }
                                },
                                {
                                    ORD_AMT: {
                                        colname: "ORD_AMT",
                                        display_format: "MONEY_FORMAT",
                                        mTitle: Util.getLangText("amountTxt"),
                                        display_width: 120,
                                        mSummary: "SUM"
                                    }
                                }
                            ]);
                        }

                        var sq = "select TRANS_DESCR DESCR,trans_code,trans_table" +
                            " FROM C7_TRANS_CODES WHERE ':kinds' like '%'||TRANS_KIND||'%' and ':tables' like '%\"'||trans_table||'\"%' order by pos";
                        sq = sq.replaceAll(":kinds", kinds)
                            .replaceAll(":tables", tables);
                        UtilGen.Search.do_quick_search_simple(sq,
                            ["TRAMS_DESCR"], function (data) {
                                var cod = data.TRANS_CODE;
                                var tbl = data.TRANS_TABLE;
                                setTimeout(() => {
                                    selItems(cod, tbl);
                                });
                            }, { pWidth: "400px" }, undefined, undefined, "select kind ... ", [
                            {
                                TRANS_CODE: {
                                    colname: 'TRANS_CODE',
                                    hide: true
                                }
                            },
                            {
                                TRANS_TABLE: {
                                    colname: 'TRANS_TABLE',
                                    hide: true
                                }
                            },

                        ]);
                    };
                    var copyVouItems = function (data, cod, tbl) {
                        var qrj = thatForm.frm.objs["qry2"].obj;
                        var vars = thatForm.vars;
                        if (data == null || data == undefined || data.length <= 0)
                            return false;
                        if (thatForm.frm.objs["qry1"].status != FormView.RecordStatus.NEW &&
                            thatForm.frm.objs["qry1"].status != FormView.RecordStatus.EDIT) {
                            sap.m.MessageToast.show("Not in new / edit mode !");
                            return;
                        }
                        var sqRec = "select P.ORD_POS,P.ORD_REFER,P.ORD_PKQTY," +
                            "P.ORD_UNQTY,P.ORD_PRICE,P.ORD_DISCAMT,P.STRA,P.ORD_PACKD,P.ORD_UNITD,P.ORD_PACK , I.DESCR,I.DESCRA " +
                            "  from pord2 P,ITEMS I where P.keyfld=:KEYFLD AND P.ORD_REFER=I.REFERENCE order by ord_pos";
                        if (tbl == "PUR1")
                            sqRec = "select P.ITEMPOS ORD_POS,P.REFER ORD_REFER,P.PKQTY ORD_PKQTY," +
                                "P.QTY ORD_UNQTY,P.PRICE ORD_PRICE,P.DISC_AMT ORD_DISCAMT,P.STRA,P.PACKD ORD_PACKD,P.UNITD ORD_UNITD,P.PACK ORD_PACK , I.DESCR,I.DESCRA " +
                                "  from PUR2 P,ITEMS I where P.keyfld=:KEYFLD AND P.REFER=I.REFERENCE order by ord_pos";
                        var copyRec = function (dtx) {
                            var rs = recordSet;
                            if (tbl == "PORD1" || tbl == "PUR1") {
                                var r = qrj.mLctb.rows.length - 1;
                                if (Util.nvl(qrj.mLctb.getFieldValue(qrj.mLctb.rows.length - 1, rs["REFER"]), "") != "")
                                    r = qrj.mLctb.addRow();
                                if (rs["POS"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["POS"], r + 1);
                                qrj.mLctb.setFieldValue(r, rs["REFER"], dtx.ORD_REFER);
                                if (rs["DESCR"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["DESCR"], dtx.DESCR);
                                if (rs["PACKD"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["PACKD"], dtx.ORD_PACKD);
                                if (rs["UNITD"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["UNITD"], dtx.ORD_UNITD);
                                if (rs["PACK"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["PACK"], dtx.ORD_PACK);
                                if (rs["PKQTY"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["PKQTY"], dtx.ORD_PKQTY);
                                if (rs["UNQTY"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["UNQTY"], dtx.ORD_UNQTY);
                                if (rs["PRICE"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["PRICE"], dtx.ORD_PRICE);
                                if (rs["DISCAMT"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["DISCAMT"], dtx.ORD_DISCAMT);
                                if (rs["STRA"] != undefined)
                                    qrj.mLctb.setFieldValue(r, rs["STRA"], dtx.STRA);
                            }
                        };
                        for (var d in data) {
                            var sqx = sqRec.replaceAll(":KEYFLD", data[d].KEYFLD);
                            var dat = Util.execSQL(sqx);
                            if (dat.ret == "SUCCESS" && dat.data.length > 0) {
                                var dtx = JSON.parse("{" + dat.data + "}").data;
                                for (var i in dtx)
                                    copyRec(dtx[i]);
                            }
                        }
                        qrj.updateDataToControl();
                        qrj.eventCalc(qrj, undefined, -1, true, true);
                    }
                    copyItems();
                }


            },
            JOFunc: {
                checkJOStatus: function (poKf, pRaiseErr) {
                    var raiseErr = Util.nvl(pRaiseErr, true);
                    var podt = Util.execSQLWithData("select nvl(max(ord_flag),-1) ord_flag,nvl(max(ord_no),-1) ord_no,nvl(max(ordacc),'') ordacc from pord1 where keyfld=" + poKf, "No data found !");
                    if (!raiseErr) return podt[0];

                    if (podt[0].ORD_FLAG < 0)
                        FormView.err("JO is not avaialble !");
                    if (podt[0].ORD_FLAG == 1)
                        FormView.err("JO is not approved !");
                    if (podt[0].ORD_FLAG >= 3)
                        FormView.err("JO is closed !");
                    return podt[0];

                }
            },
            DashboardWidget: {
                getSlides: function (kf, pHeight, pnlClass, pnlClassTit, fnOnMenuClick) {
                    var gj;
                    var gjPnl;
                    var timlong = UtilGen.DBView.timeInLong;
                    var that = this;
                    // var dt = UtilGen.DBView.today_date.getDateValue();
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var fisc = sap.ui.getCore().getModel("fiscalData").getData();
                    var df = new DecimalFormat(sett["FORMAT_QTY_1"]);
                    var tl = [];
                    // var strAr = "";
                    // if (Array.isArray(kf))
                    //     kf.forEach(function (el) { strAr != strAr.length > 0 ? "," : "" + kf[el] });
                    // else strAr = kf;

                    var sq = "select *from c7_db_slides where keyfld=" + kf;
                    try {
                        var dtx = Util.execSQLWithData(sq, 'no data found !');
                        var sqx = dtx[0].SQL_VAL;
                        sqx = sqx.replaceAll(":todate", Util.toOraDateString(UtilGen.DBView.today_date.getDateValue()));
                        if (sqx.startsWith("select ")) {
                            var dt = Util.execSQLWithData(sqx);
                            for (var di in dt) {
                                var tle = new sap.m.GenericTile({
                                    header: Util.getLangText(dtx[0].TITLE1),
                                    subheader: Util.nvl(dt[di].CODE, "") + " /  " + dt[di].TITLE,
                                    tileContent: [
                                        new sap.m.TileContent({
                                            content: new sap.m.HBox({
                                                alignItems: "Center",
                                                justifyContent: "Center",
                                                items: [
                                                    new sap.m.Text({
                                                        text: df.format(Util.extractNumber(dt[di].VALUE))
                                                    }).addStyleClass("guageValNumber"),
                                                    new sap.m.Text({
                                                        text: ".  " + Util.nvl(dt[di].POST_VAL, ''),
                                                        class: "sapUiTinyMarginBegin"
                                                    }).addStyleClass("guageValNumber"),
                                                ]
                                            })
                                        })
                                    ]
                                }).addStyleClass("");
                                tl.push(tle);
                            }
                        } else {
                            tl = eval(sqx);
                        }
                        var gj3 = new sap.m.SlideTile({
                            class: "",
                            tiles: tl,
                            transitionTime: tl.length > 1 ? 2300 : 0,
                        }).addStyleClass("guagePanel");
                        return gj3;
                    }
                    catch (e) {
                        console.log(e);
                    }
                    return undefined;
                },
                inputGuageTarget: function (kf, title, msg) {
                    var targetval = Util.getSQLValue("select max_val from c6_db_gauges where keyfld=" + kf);
                    if (Util.nvl(targetval, '') == "") targetval = 0;

                    UtilGen.inputDialog(title, msg + " : ", targetval, function (str) {

                        var vl = Util.extractNumber(Util.nvl(str, "0"));
                        var dt = Util.execSQL("update c6_db_gauges set max_val=" + vl + " where keyfld = " + kf);
                        if (dt.ret == "SUCCESS") {
                            UtilGen.DBView.loadData_main();
                        } else return false;
                    }, function () {
                        return true;
                    }, undefined, undefined, {});
                },
                getGauge: function (kf, pHeight, pnlClass, pnlClassTit, fnOnMenuClick, fnClick) {
                    var that = this;
                    var timlong = UtilGen.DBView.timeInLong;
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var df = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);
                    var dt = UtilGen.DBView.today_date.getDateValue();
                    var ps = "_para_todate=@" + df.format(dt);

                    // --- Placeholder card (shows busy indicator) ---
                    var oPlaceholder = new sap.m.VBox({
                        width: "100%",
                        height: Util.nvl(pHeight, "auto"),
                        alignItems: sap.ui.core.TextAlign.Center,
                        justifyContent: sap.m.FlexAlignItems.Start,
                        items: [new sap.m.BusyIndicator({ size: ".5rem" })]
                    }).addStyleClass("gaugeCard");

                    // --- Fetch data ---
                    Util.doAjaxGet("gaugedata2?" + ps, "&_keyfld='" + kf + "'", false).done(function (data) {
                        var gjData = JSON.parse(data).data[0];
                        if (!gjData) {
                            oPlaceholder.removeAllItems();
                            oPlaceholder.addItem(new sap.m.Text({ text: "No data" }));
                            return;
                        }

                        // Build the final gauge card
                        var oCard = that.createGauge("gauge_" + kf + "_" + timlong, gjData, {
                            CELL_HEIGHT: Util.nvl(pHeight, "auto"),
                            CELL_WIDTH: "100%"
                        }, fnOnMenuClick, kf, fnClick);

                        // Replace placeholder content with the card
                        oPlaceholder.removeAllItems();
                        oPlaceholder.addItem(oCard);

                        // Apply optional classes
                        if (pnlClass) {
                            oPlaceholder.addStyleClass(pnlClass);
                        }
                    });

                    return oPlaceholder;
                }
                ,
                createGauge: function (name, gg, rep, fnOnMenuClick, kf, clickHandler) {
                    var that = UtilGen.DBView;
                    var df = new DecimalFormat(gg.VALUE_FORMAT || "#,##0");
                    var min = parseFloat(gg.MIN_VAL) || 0;
                    var max = parseFloat(gg.MAX_VAL) || 100;
                    var value = parseFloat(gg.SQL_VAL) || 0;

                    // --- Gauge config ---
                    var range = max - min;
                    var config = {
                        size: 60,
                        min: min,
                        max: max,
                        value: value,
                        minorTicks: 5,
                        greenZones: [{ from: min, to: min + range * 0.75 }],
                        yellowZones: [{ from: min + range * 0.75, to: min + range * 0.9 }],
                        redZones: [{ from: min + range * 0.9, to: max }]
                    };

                    // --- Destroy old controls ---
                    Util.destroyID(name, that);
                    Util.destroyID(name + "_flex", that);
                    Util.destroyID(name + "_parent", that);

                    // --- 1. Header: Title + Settings button ---
                    var oHeader = new sap.m.HBox({
                        width: "100%",
                        alignItems: sap.ui.core.TextAlign.Start,
                        justifyContent: "SpaceBetween",
                        items: [
                            new sap.m.Text({
                                text: Util.getLangText(gg.TITLE1),
                                textAlign: "Center",
                            }).addStyleClass("sapUiTinyMargin gaugeTitle"),
                            new sap.m.Button({
                                icon: "sap-icon://settings",
                                tooltip: "Set target",
                                press: function () {
                                    if (fnOnMenuClick) {
                                        fnOnMenuClick(kf, gg);
                                    } else {
                                        UtilGen.DashboardWidget.inputGuageTarget(kf, Util.getLangText(gg.TITLE1), "Enter Target Value");
                                    }
                                }
                            }).addStyleClass("sapUiTinyMarginBegin")
                        ]
                    }).addStyleClass("cardHeaderBar");

                    // --- 2. Target line ---
                    var oTarget = new sap.m.Text({
                        text: "Target : " + df.format(max),
                        textAlign: "Center",
                        width: "100%"
                    }).addStyleClass("gaugeTarget");

                    // --- 3. Gauge canvas placeholder ---
                    var oGaugePlaceholder = new sap.m.Label({
                        id: that.createId(name),
                        text: "",
                        width: "100%",
                        height: "100%"
                    }).addStyleClass("gaugeCanvasWrapper");

                    // --- 4. Main value (large, bold) ---
                    var oMainValue = new sap.m.Text({
                        text: df.format(value) + (gg.UNIT ? " " + gg.UNIT : ""),
                        textAlign: "Center",
                        width: "100%"
                    }).addStyleClass("gaugeMainValue");

                    // --- 5. Last Month (if prior exists) ---
                    var oLastMonth = null;
                    var oDifference = null;
                    if (gg.PRIOR_FUNC_VAL != undefined && gg.PRIOR_FUNC_VAL.toString().length > 0) {
                        var prior = parseFloat(gg.PRIOR_FUNC_VAL);
                        var diff = value - prior;
                        var isPositive = diff >= 0;
                        var diffText = df.format(Math.abs(diff));
                        var sign = isPositive ? "+" : "-";
                        var colorClass = isPositive ? "gaugePositive" : "gaugeNegative";
                        var arrow = isPositive ? "▲" : "▼";

                        oLastMonth = new sap.m.Text({
                            text: (Util.getLangText(gg.PRIOR_LABEL) || "Last Month") + ": " + df.format(prior),
                            textAlign: "Center",
                            width: "100%"
                        }).addStyleClass("gaugeLastMonth");

                        oDifference = new sap.m.Text({
                            text: arrow + " " + sign + diffText + (gg.UNIT ? " " + gg.UNIT : ""),
                            textAlign: "Center",
                            width: "100%"
                        }).addStyleClass("gaugeDifference " + colorClass);
                    }

                    // --- 6. Summary (optional) ---
                    var oSummary = null;
                    if (gg.SUMMARY_VAL && gg.SUMMARY_VAL.trim() !== "") {
                        var dt = UtilGen.DBView.today_date.getDateValue();
                        var summaryValue = Util.getSQLValue(
                            gg.SUMMARY_VAL.replaceAll(":TODATE", Util.toOraDateString(dt))
                                .replaceAll(":todate", Util.toOraDateString(dt))
                        );
                        if (Util.extractNumber(summaryValue) != 0) {
                            oSummary = new sap.m.Text({
                                text: (Util.getLangText(gg.SUMMARY_LABEL) || "Total") + ": " + df.format(summaryValue),
                                textAlign: "Center",
                                width: "100%"
                            }).addStyleClass("sapUiSmallMarginTop");
                        }
                    }

                    // --- Build the final card (VBox) ---
                    var oCard = new sap.m.VBox({
                        width: "100%",
                        alignItems: sap.ui.core.TextAlign.Center,
                        items: [
                            oHeader,
                            oTarget,
                            oGaugePlaceholder,
                            oMainValue,
                            oLastMonth,
                            oDifference,
                            oSummary
                        ].filter(item => item !== null)
                    }).addStyleClass("gaugeCard");

                    if (typeof clickHandler == "function")
                        oGaugePlaceholder.addStyleClass("gaugeClickable");

                    // --- Create gauge and attach event ---
                    var oGauge = new Gauge(that.createId(name), config);
                    oCard._gauge = oGauge;
                    oCard._value = value;


                    oCard.addEventDelegate({
                        onAfterRendering: function () {
                            if (this._gauge) {
                                this._gauge.render();
                                this._gauge.redraw(this._value);
                            }
                        }
                    }, oCard);
                    setTimeout(() => {
                        oGaugePlaceholder.$().on("click", function () {
                            clickHandler(kf, gg);
                        });
                    }, 0);
                    return oCard;
                },
                /**
                 * Creates a card with a grid of labeled values, supports lazy loading, row titles, and summary.
                 * 
                 * @param {string} name - unique ID prefix
                 * @param {object} config - configuration object:
                 *   - title (string): card title
                 *   - rows (array): array of row definitions, each with:
                 *       - title (string, optional): row header
                 *       - columns (array): column objects { label, value, unit?, width?, style?, color?, onClick? }
                 *   - summary (array, optional): column objects for the summary row (displayed after a separator)
                 *   - loadData (function, optional): async function that returns a Promise resolving to { rows, summary }.
                 *        If provided, data is loaded lazily (busy indicator shown initially).
                 *   - settings (object): { colsPerRow, VALUE_FORMAT, UNIT, showSettings, onSettings }
                 * @returns {sap.m.VBox} the card with update methods
                 */
                createColumnCard: function (name, config) {
                    var that = UtilGen.DBView;
                    var sett = config.settings || {};
                    var title = config.title || "";
                    var loadData = config.loadData || null;
                    var initialRows = config.rows || [];
                    var initialSummary = config.summary || null;
                    var cardWidth = sett.width || "100%";
                    var cardHeight = sett.height || "auto";  // auto‑fit by default
                    var df = new DecimalFormat(sett.VALUE_FORMAT || "#,##0");
                    // --- Internal state ---
                    var currentRows = initialRows.slice();
                    var currentSummary = initialSummary;
                    var currentSettings = {
                        colsPerRow: sett.colsPerRow || 2,
                        VALUE_FORMAT: sett.VALUE_FORMAT || "#,##0",
                        UNIT: sett.UNIT || "",
                        showSettings: sett.showSettings !== undefined ? sett.showSettings : true,
                        onSettings: sett.onSettings || null,
                        width: cardWidth,
                        height: cardHeight
                    };
                    var isLoading = false;

                    // --- Helper: build grid from rows and summary ---
                    function buildGrid(rows, summary) {
                        var oGrid = new sap.m.VBox({
                            width: "100%",
                            alignItems: "Center",
                            items: []
                        });

                        var colsPerRow = currentSettings.colsPerRow;

                        function createRowItems(columns, isSummary) {
                            var rowItems = [];
                            for (var i = 0; i < columns.length; i += colsPerRow) {
                                var chunk = columns.slice(i, i + colsPerRow);
                                var oRow = new sap.m.HBox({
                                    width: "100%",
                                    justifyContent: "SpaceAround",
                                    alignItems: "Center"
                                });

                                chunk.forEach(function (col) {
                                    var width = col.width || (100 / colsPerRow) + "%";
                                    var widthStyle = (typeof width === "number") ? width + "%" : width;

                                    var oLabel = new sap.m.Text({
                                        text: col.label,
                                        textAlign: "Center"
                                    }).addStyleClass(isSummary ? "summaryLabel" : "comparisonLabel");

                                    var unit = col.unit || currentSettings.UNIT;
                                    var valueText = col.value + (unit ? " " + unit : "");
                                    var oValue = new sap.m.Text({
                                        text: valueText,
                                        textAlign: "Center"
                                    }).addStyleClass(isSummary ? "summaryValue" : "comparisonValue");
                                    if (col.style) oValue.addStyleClass(col.style);
                                    if (col.color) oValue.$().css("color", col.color);

                                    var oColumn = new sap.m.VBox({
                                        alignItems: "Center",
                                        width: widthStyle,
                                        items: [oLabel, oValue]
                                    }).addStyleClass("columnItem");

                                    if (typeof col.onClick === "function") {
                                        oColumn.addEventDelegate({
                                            onPress: function () { col.onClick(col); },
                                            onTap: function () { col.onClick(col); }
                                        });
                                        oColumn.addStyleClass("clickableColumn");
                                    }

                                    oRow.addItem(oColumn);
                                });
                                rowItems.push(oRow);
                            }
                            return rowItems;
                        }

                        rows.forEach(function (rowDef) {
                            if (rowDef.title) {
                                var oTitle = new sap.m.Text({
                                    text: rowDef.title,
                                    textAlign: sap.ui.core.TextAlign.Start,
                                    width: "100%"
                                }).addStyleClass("rowTitle sapUiTinyMarginBegin");
                                oGrid.addItem(new sap.m.VBox({
                                    width: "100%",
                                    items:
                                        oTitle
                                }));
                            }
                            var rowColumns = rowDef.columns || [];
                            var rowItems = createRowItems(rowColumns, false);
                            rowItems.forEach(function (item) {
                                oGrid.addItem(item);
                            });
                        });

                        if (summary && summary.length > 0) {
                            var oSeparator = new sap.m.HBox({
                                width: "100%",
                                justifyContent: "Center",
                                items: [new sap.m.Text({ text: "" })]
                            }).addStyleClass("summarySeparator");
                            oGrid.addItem(oSeparator);

                            var summaryItems = createRowItems(summary, true);
                            summaryItems.forEach(function (item) {
                                var oFooterContainer = new sap.m.VBox({
                                    width: "100%",
                                    alignItems: "Center",
                                    items: [item]
                                }).addStyleClass("summaryFooter");
                                oGrid.addItem(oFooterContainer);
                            });
                        }

                        return oGrid;
                    }

                    // --- Build header bar (title with Fiori‑style background) ---
                    function buildHeader() {
                        var oHeader = new sap.m.HBox({
                            width: "100%",
                            alignItems: "Center",
                            justifyContent: "SpaceBetween",
                            items: [
                                new sap.m.Text({ text: Util.getLangText(title) }).addStyleClass("cardTitle"),
                                currentSettings.showSettings ? new sap.m.Button({
                                    icon: "sap-icon://settings",
                                    tooltip: "Change parameters",
                                    press: function () {
                                        if (typeof currentSettings.onSettings === "function") {
                                            currentSettings.onSettings(oCard, currentRows, currentSummary, currentSettings);
                                        } else {
                                            sap.m.MessageToast.show("No settings handler defined.");
                                        }
                                    }
                                }).addStyleClass("sapUiTinyMarginBegin") : null
                            ].filter(item => item !== null)
                        }).addStyleClass("cardHeaderBar");  // <-- header bar style

                        return oHeader;
                    }

                    // --- Initial construction ---
                    var oHeader = buildHeader();
                    var oGrid = new sap.m.VBox({ width: "100%", alignItems: "Center", items: [] });

                    if (typeof loadData === "function") {
                        isLoading = true;
                        oGrid.addItem(new sap.m.BusyIndicator({ size: ".5rem" }));
                        setTimeout(function () {
                            loadData().then(function (result) {
                                if (result.rows) currentRows = result.rows.slice();
                                if (result.summary) currentSummary = result.summary;
                                isLoading = false;
                                var newGrid = buildGrid(currentRows, currentSummary);
                                oGrid.destroyItems();
                                newGrid.getItems().forEach(function (item) {
                                    oGrid.addItem(item);
                                });
                            }).catch(function (err) {
                                sap.m.MessageToast.show("Error loading data: " + err.message);
                                oGrid.destroyItems();
                                oGrid.addItem(new sap.m.Text({ text: "Error loading data" }));
                            });
                        }, 100);
                    } else {
                        var grid = buildGrid(currentRows, currentSummary);
                        grid.getItems().forEach(function (item) {
                            oGrid.addItem(item);
                        });
                    }

                    var oCard = new sap.m.VBox({
                        width: currentSettings.width,
                        height: currentSettings.height,  // auto by default
                        alignItems: "Center",
                        items: [oHeader, oGrid]
                    }).addStyleClass("gaugeCard");

                    // --- Update methods (unchanged) ---
                    oCard.updateData = function (newRows, newSummary) {
                        if (newRows) currentRows = newRows.slice();
                        if (newSummary !== undefined) currentSummary = newSummary;
                        var oldGrid = oCard.getContent()[1];
                        var newGrid = buildGrid(currentRows, currentSummary);
                        oCard.removeContent(oldGrid);
                        oCard.addContent(newGrid);
                        oldGrid.destroy();
                    };

                    oCard.updateSettings = function (newSettings) {
                        for (var key in newSettings) {
                            if (newSettings.hasOwnProperty(key)) {
                                currentSettings[key] = newSettings[key];
                            }
                        }
                        var oldHeader = oCard.getContent()[0];
                        var oldGrid = oCard.getContent()[1];
                        var newHeader = buildHeader();
                        var newGrid = buildGrid(currentRows, currentSummary);
                        oCard.removeContent(oldHeader);
                        oCard.removeContent(oldGrid);
                        oCard.addContent(newHeader);
                        oCard.addContent(newGrid);
                        oldHeader.destroy();
                        oldGrid.destroy();
                    };

                    oCard.updateCard = function (newRows, newSummary, newSettings) {
                        if (newRows) currentRows = newRows.slice();
                        if (newSummary !== undefined) currentSummary = newSummary;
                        if (newSettings) {
                            for (var key in newSettings) {
                                if (newSettings.hasOwnProperty(key)) {
                                    currentSettings[key] = newSettings[key];
                                }
                            }
                        }
                        var oldHeader = oCard.getContent()[0];
                        var oldGrid = oCard.getContent()[1];
                        var newHeader = buildHeader();
                        var newGrid = buildGrid(currentRows, currentSummary);
                        oCard.removeContent(oldHeader);
                        oCard.removeContent(oldGrid);
                        oCard.addContent(newHeader);
                        oCard.addContent(newGrid);
                        oldHeader.destroy();
                        oldGrid.destroy();
                    };

                    oCard.getRows = function () { return currentRows; };
                    oCard.getSummary = function () { return currentSummary; };
                    oCard.getSettings = function () { return currentSettings; };
                    oCard.isLoading = function () { return isLoading; };

                    return oCard;
                },
                // Counter for unique canvas IDs


                createChartCard: function (name, config) {
                    var _chartIdCounter = 0;
                    var sett = config.settings || {};
                    var title = config.title || "Chart";
                    var chartType = config.chartType || "bar";
                    var categoryAxis = config.categoryAxis || "category";
                    var valueAxis = config.valueAxis || "value";
                    var colors = config.colors || ["#0070c0", "#ed7d31", "#70ad47", "#ffc000", "#4472c4"];
                    var clickHandler = config.clickHandler || null;
                    var loadData = config.loadData || null;
                    var initialData = config.data || [];
                    var cardWidth = sett.width || "100%";
                    var cardHeight = sett.height || "auto";
                    var minHeight = sett.minHeight || "200px";

                    var positiveColor = config.positiveColor || colors[0] || "#0070c0";
                    var negativeColor = config.negativeColor || "#dc3912";
                    var colorByValue = config.colorByValue !== undefined ? config.colorByValue : true;

                    // --- Internal state ---
                    var currentData = initialData.slice();
                    var currentSettings = {
                        width: cardWidth,
                        height: cardHeight,
                        minHeight: minHeight,
                        showSettings: sett.showSettings !== undefined ? sett.showSettings : true,
                        onSettings: sett.onSettings || null
                    };
                    var isLoading = false;
                    var chartInstance = null;
                    var canvasId = "chartCanvas_" + name + "_" + (++_chartIdCounter) + "_" + Date.now();
                    var resizeHandlerId = null;

                    // --- Load Chart.js ---
                    function loadChartJSLibrary() {
                        return new Promise(function (resolve, reject) {
                            if (typeof Chart !== 'undefined') {
                                resolve();
                                return;
                            }
                            var script = document.createElement('script');
                            script.src = "js/chart.min.js";
                            script.onload = function () { resolve(); };
                            script.onerror = function () { reject(new Error("Failed to load Chart.js")); };
                            document.head.appendChild(script);
                        });
                    }

                    // --- Build chart data ---
                    function buildChartData(data) {
                        var categories = data.map(function (item) { return item[categoryAxis]; });
                        var values = data.map(function (item) { return item[valueAxis]; });

                        // Determine background colors per data point
                        var backgroundColors;
                        if (colorByValue && (chartType === "bar" || chartType === "column")) {
                            // For bar/column: color each bar based on value
                            backgroundColors = values.map(function (val) {
                                if (typeof val === 'number') {
                                    return val >= 0 ? positiveColor : negativeColor;
                                }
                                return positiveColor; // fallback
                            });
                        } else {
                            // Use the default color palette for other chart types or when colorByValue is false
                            backgroundColors = colors.slice(0, values.length);
                        }

                        var dataset = {
                            label: "Value",
                            data: values,
                            backgroundColor: backgroundColors,
                            borderColor: backgroundColors.map(function () { return "#ffffff"; }), // optional border
                            barThickness: 30,
                            minBarLength: 5,
                            borderWidth: 1
                        };

                        if (chartType === "pie" || chartType === "doughnut" || chartType === "polarArea") {
                            // For pie/donut, use the full palette (or conditional if needed)
                            dataset.backgroundColor = backgroundColors;
                            dataset.borderColor = "#ffffff";
                            dataset.borderWidth = 2;
                        }

                        return {
                            labels: categories,
                            datasets: [dataset]
                        };
                    }

                    // --- Render chart ---
                    function renderChart(canvasEl, data) {
                        if (chartInstance) {
                            chartInstance.destroy();
                            chartInstance = null;
                        }
                        if (!canvasEl) return;

                        // Remove old click listener
                        if (canvasEl._clickListener) {
                            canvasEl.removeEventListener('click', canvasEl._clickListener);
                            canvasEl._clickListener = null;
                        }

                        var ctx = canvasEl.getContext('2d');
                        var chartData = buildChartData(data);
                        var configChart = {
                            type: chartType,
                            data: chartData,
                            options: {
                                responsive: true,
                                maintainAspectRatio: false,
                                plugins: {
                                    legend: { display: false }
                                },
                                scales: (chartType === "pie" || chartType === "doughnut") ? undefined : {
                                    x: { grid: { display: false } },
                                    y: { beginAtZero: true, grid: { color: "#e0e0e0" } }
                                }
                            }
                        };

                        chartInstance = new Chart(ctx, configChart);

                        // Click handler
                        if (typeof clickHandler === "function") {
                            var clickListener = function (event) {
                                if (!chartInstance) return;
                                var elements = chartInstance.getElementsAtEventForMode(
                                    event,
                                    'index',
                                    { intersect: true, radius: 20 }
                                );
                                if (elements.length > 0) {
                                    var index = elements[0]._index;
                                    if (data && data[index]) {
                                        clickHandler(data[index], event);
                                    }
                                }
                            };
                            canvasEl.addEventListener('click', clickListener);
                            canvasEl._clickListener = clickListener;

                            chartInstance.options.onClick = function (event, elements) {
                                if (elements.length > 0) {
                                    var index = elements[0].index;
                                    if (data && data[index]) {
                                        clickHandler(data[index], event);
                                    }
                                }
                            };
                            chartInstance.update();
                        }

                        // Force resize after a short delay to adapt to container size
                        setTimeout(function () {
                            if (chartInstance) {
                                chartInstance.resize();
                            }
                        }, 150);
                    }

                    // --- Resize chart – always re-render ---
                    function resizeChart() {
                        if (!chartInstance) return;
                        var data = currentData;
                        if (data && data.length > 0) {
                            chartInstance.destroy();
                            chartInstance = null;
                            var canvasEl = document.getElementById(canvasId);
                            if (canvasEl) {
                                renderChart(canvasEl, data);
                            }
                        }
                    }

                    // --- Build header ---
                    function buildHeader() {
                        var oHeader = new sap.m.HBox({
                            width: "100%",
                            alignItems: "Center",
                            justifyContent: "SpaceBetween",
                            items: [
                                new sap.m.Text({ text: Util.getLangText(title) }).addStyleClass("cardTitle"),
                                currentSettings.showSettings ? new sap.m.Button({
                                    icon: "sap-icon://settings",
                                    tooltip: "Change parameters",
                                    press: function () {
                                        if (typeof currentSettings.onSettings === "function") {
                                            currentSettings.onSettings(oCard, currentData, currentSettings);
                                        } else {
                                            sap.m.MessageToast.show("No settings handler defined.");
                                        }
                                    }
                                }).addStyleClass("sapUiTinyMarginBegin") : null
                            ].filter(item => item !== null)
                        }).addStyleClass("cardHeaderBar");
                        // Header should not grow
                        oHeader.setLayoutData(new sap.m.FlexItemData({
                            growFactor: 0
                        }));
                        return oHeader;
                    }

                    // --- Build chart container (VBox that holds the canvas) ---
                    function buildChartContainer(data) {
                        var oContainer = new sap.m.VBox({
                            width: "100%",
                            height: "100%",          // fill the remaining space
                            alignItems: sap.m.FlexAlignItems.Stretch,
                            justifyContent: sap.m.FlexJustifyContent.Stretch
                        });

                        if (isLoading) {
                            oContainer.addItem(new sap.m.BusyIndicator({ size: ".5rem" }));
                            return oContainer;
                        }

                        // If height is "auto", use minHeight; else let container fill
                        var canvasStyle = 'width:100%;height:100%;pointer-events:auto;cursor:pointer;';
                        canvasStyle += 'max-height:' + currentSettings.height + ';';
                        if (currentSettings.height === "auto" || currentSettings.height === "") {
                            canvasStyle += 'min-height:' + currentSettings.minHeight + ';';
                        }

                        var oCanvas = new sap.ui.core.HTML({
                            content: '<canvas id="' + canvasId + '" style="' + canvasStyle + '"></canvas>',
                            width: "100%",
                            height: "100%"
                        });
                        oContainer.addItem(oCanvas);
                        oContainer._canvasId = canvasId;
                        oContainer._data = data;

                        // Container should grow to fill available space
                        oContainer.setLayoutData(new sap.m.FlexItemData({
                            growFactor: 1
                        }));

                        return oContainer;
                    }

                    // --- Initial construction ---
                    var oHeader = buildHeader();
                    var oChartContainer = new sap.m.VBox({ width: "100%", height: "100%" });
                    oChartContainer.setLayoutData(new sap.m.FlexItemData({ growFactor: 1 }));

                    var oCard = new sap.m.VBox({
                        width: currentSettings.width,
                        height: currentSettings.height,   // fixed height or "auto"
                        alignItems: "Stretch",
                        items: [oHeader, oChartContainer]
                    }).addStyleClass("gaugeCard chartCard tableCard");
                    oCard.addStyleClass("heightStrict");
                    // Load Chart.js and data
                    loadChartJSLibrary().then(function () {
                        if (typeof loadData === "function") {
                            isLoading = true;
                            var busyContainer = new sap.m.VBox({
                                width: "100%",
                                height: "100%",
                                alignItems: "Center",
                                justifyContent: "Center",
                                items: [new sap.m.BusyIndicator({ size: ".5rem" })]
                            });
                            busyContainer.setLayoutData(new sap.m.FlexItemData({ growFactor: 1 }));
                            oCard.removeItem(oChartContainer);
                            oCard.addItem(busyContainer);
                            oChartContainer = busyContainer;

                            loadData().then(function (data) {
                                currentData = data.slice();
                                isLoading = false;
                                var newContainer = buildChartContainer(currentData);
                                oCard.removeItem(busyContainer);
                                oCard.addItem(newContainer);
                                oChartContainer = newContainer;
                                setTimeout(function () {
                                    var canvasEl = document.getElementById(canvasId);
                                    if (canvasEl) renderChart(canvasEl, currentData);
                                }, 200);
                            }).catch(function (err) {
                                sap.m.MessageToast.show("Error loading chart data: " + err.message);
                                oCard.removeItem(oChartContainer);
                                var errText = new sap.m.Text({ text: "Error loading data" });
                                errText.setLayoutData(new sap.m.FlexItemData({ growFactor: 1 }));
                                oCard.addItem(errText);
                            });
                        } else {
                            var container = buildChartContainer(currentData);
                            oCard.removeItem(oChartContainer);
                            oCard.addItem(container);
                            oChartContainer = container;
                            setTimeout(function () {
                                var canvasEl = document.getElementById(canvasId);
                                if (canvasEl) renderChart(canvasEl, currentData);
                            }, 200);
                        }
                    }).catch(function (err) {
                        sap.m.MessageToast.show("Failed to load Chart.js: " + err.message);
                        oCard.removeItem(oChartContainer);
                        var errText = new sap.m.Text({ text: "Chart library not loaded" });
                        errText.setLayoutData(new sap.m.FlexItemData({ growFactor: 1 }));
                        oCard.addItem(errText);
                    });

                    // --- Update methods ---
                    oCard.updateData = function (newData) {
                        if (newData) currentData = newData.slice();
                        var oldContainer = oCard.getItems()[1];
                        var newContainer = buildChartContainer(currentData);
                        oCard.removeItem(oldContainer);
                        oCard.addItem(newContainer);
                        oldContainer.destroy();
                        setTimeout(function () {
                            var canvasEl = document.getElementById(canvasId);
                            if (canvasEl) renderChart(canvasEl, currentData);
                        }, 200);
                    };

                    oCard.updateSettings = function (newSettings) {
                        for (var key in newSettings) {
                            if (newSettings.hasOwnProperty(key)) {
                                currentSettings[key] = newSettings[key];
                            }
                        }
                        // Apply new width/height immediately
                        oCard.setWidth(currentSettings.width);
                        oCard.setHeight(currentSettings.height);
                        var oldHeader = oCard.getItems()[0];
                        var oldContainer = oCard.getItems()[1];
                        var newHeader = buildHeader();
                        var newContainer = buildChartContainer(currentData);
                        oCard.removeItem(oldHeader);
                        oCard.removeItem(oldContainer);
                        oCard.addItem(newHeader);
                        oCard.addItem(newContainer);
                        oldHeader.destroy();
                        oldContainer.destroy();
                        setTimeout(function () {
                            var canvasEl = document.getElementById(canvasId);
                            if (canvasEl) renderChart(canvasEl, currentData);
                        }, 200);
                    };

                    oCard.updateCard = function (newData, newSettings) {
                        if (newData) currentData = newData.slice();
                        if (newSettings) {
                            for (var key in newSettings) {
                                if (newSettings.hasOwnProperty(key)) {
                                    currentSettings[key] = newSettings[key];
                                }
                            }
                        }
                        oCard.setWidth(currentSettings.width);
                        oCard.setHeight(currentSettings.height);
                        var oldHeader = oCard.getItems()[0];
                        var oldContainer = oCard.getItems()[1];
                        var newHeader = buildHeader();
                        var newContainer = buildChartContainer(currentData);
                        oCard.removeItem(oldHeader);
                        oCard.removeItem(oldContainer);
                        oCard.addItem(newHeader);
                        oCard.addItem(newContainer);
                        oldHeader.destroy();
                        oldContainer.destroy();
                        setTimeout(function () {
                            var canvasEl = document.getElementById(canvasId);
                            if (canvasEl) renderChart(canvasEl, currentData);
                        }, 200);
                    };

                    oCard.getData = function () { return currentData; };
                    oCard.getSettings = function () { return currentSettings; };
                    oCard.isLoading = function () { return isLoading; };

                    // --- Lifecycle events ---
                    oCard.addEventDelegate({
                        onAfterRendering: function () {
                            setTimeout(function () {
                                var canvasEl = document.getElementById(canvasId);
                                if (canvasEl) {
                                    if (chartInstance) {
                                        resizeChart();
                                    } else if (currentData && currentData.length > 0) {
                                        renderChart(canvasEl, currentData);
                                    }
                                }
                            }, 300);
                        },
                        onExit: function () {
                            if (resizeHandlerId) {
                                sap.ui.core.ResizeHandler.deregister(resizeHandlerId);
                                resizeHandlerId = null;
                            }
                            var canvasEl = document.getElementById(canvasId);
                            if (canvasEl && canvasEl._clickListener) {
                                canvasEl.removeEventListener('click', canvasEl._clickListener);
                            }
                            if (chartInstance) {
                                chartInstance.destroy();
                                chartInstance = null;
                            }
                        }
                    });

                    // --- Resize handler on the card's DOM element ---
                    oCard.addEventDelegate({
                        onAfterRendering: function () {
                            var domRef = oCard.getDomRef();
                            if (domRef && sap.ui.core.ResizeHandler) {
                                if (resizeHandlerId) {
                                    sap.ui.core.ResizeHandler.deregister(resizeHandlerId);
                                }
                                resizeHandlerId = sap.ui.core.ResizeHandler.register(domRef, function () {
                                    clearTimeout(this._resizeTimer);
                                    this._resizeTimer = setTimeout(function () {
                                        resizeChart();
                                    }, 100);
                                }.bind(this));
                            }
                        }
                    });

                    return oCard;
                },
                createTableCard: function (config) {
                    var sett = config.settings || {};
                    var title = config.title || "Table";
                    var queryView = config.queryView || null;
                    var loadData = config.loadData || null;
                    var columnWidths = config.columnWidths || {};
                    var wrapText = config.wrapText || false;
                    var rowClickHandler = config.rowClickHandler || null;
                    var cardWidth = sett.width || "100%";
                    var cardHeight = sett.height || "auto";
                    var minHeight = sett.minHeight || "200px";
                    var maxHeight = sett.maxHeight || "400px";

                    // --- Internal state ---
                    var currentData = null;
                    var currentSettings = {
                        width: cardWidth,
                        height: cardHeight,
                        minHeight: minHeight,
                        maxHeight: maxHeight,
                        showSettings: sett.showSettings !== undefined ? sett.showSettings : true,
                        onSettings: sett.onSettings || null
                    };
                    var isLoading = false;
                    var tableContainerId = "tableContainer_" + (Date.now()) + "_" + Math.random().toString(36).substr(2, 6);

                    // --- Helper: Format a cell value based on column properties ---
                    function formatCellValue(value, col) {
                        if (value === null || value === undefined) return "";
                        var fmt = col.mUIHelper.display_format;
                        var dataType = col.mUIHelper.data_type;
                        var sett = sap.ui.getCore().getModel("settings").getData();

                        if (dataType === "NUMBER") {
                            if (fmt === "MONEY_FORMAT") {
                                var df = new DecimalFormat(sett["FORMAT_MONEY_1"]);
                                return df.format(value);
                            } else if (fmt === "QTY_FORMAT") {
                                var df = new DecimalFormat(sett["FORMAT_QTY_1"]);
                                return df.format(value);
                            } else if (fmt && fmt !== "NONE") {
                                try {
                                    var df = new DecimalFormat(fmt);
                                    return df.format(value);
                                } catch (e) { /* ignore */ }
                            }
                            return value.toString();
                        } else if (dataType === "DATE") {
                            if (fmt === "SHORT_DATE_FORMAT") {
                                var sdf = new simpleDateFormat(sett["ENGLISH_DATE_FORMAT"]);
                                if (value instanceof Date) return sdf.format(value);
                                try { return sdf.format(new Date(value)); } catch (e) { return value; }
                            } else if (fmt) {
                                try {
                                    var sdf = new simpleDateFormat(fmt);
                                    if (value instanceof Date) return sdf.format(value);
                                    try { return sdf.format(new Date(value)); } catch (e) { return value; }
                                } catch (e) { /* ignore */ }
                            }
                            return value.toString();
                        } else {
                            return value;
                        }
                    }

                    // --- Helper: Build table HTML from LocalTableData ---
                    function buildTableHTML(lctb) {
                        if (!lctb || lctb.cols.length === 0 || lctb.rows.length === 0) {
                            return "<p>No data</p>";
                        }

                        // Start table with fixed layout to enforce column widths
                        var html = '<table class="tableCardTable" style="width:100%;table-layout:fixed;border-collapse:collapse;">';
                        // Header
                        html += '<thead><tr>';
                        lctb.cols.forEach(function (col) {
                            if (col.mHideCol) return;
                            var width = columnWidths[col.mColName] || col.mUIHelper.display_width || "auto";
                            if (typeof width === "number") width = width + "%";
                            // If width is a string like "10%", keep it; else if it's a number, we already appended "%"
                            var title = Util.getLangCaption(col.mTitle) || col.mColName;
                            var align = col.mUIHelper.display_align || "left";
                            html += '<th style="width:' + width + ';min-width:' + width + ';max-width:' + width + ';text-align:' + align + ';overflow:hidden;text-overflow:ellipsis;" title="' + title + '">' + title + '</th>';
                        });
                        html += '</tr></thead>';

                        // Body
                        html += '<tbody>';
                        lctb.rows.forEach(function (row, rowIndex) {
                            html += '<tr data-row="' + rowIndex + '">';
                            lctb.cols.forEach(function (col) {
                                if (col.mHideCol) return;
                                var value = row.cells[lctb.getColPos(col.mColName)].getValue();
                                var displayValue = formatCellValue(value, col);
                                var align = col.mUIHelper.display_align || "left";
                                var shouldWrap = (columnWidths[col.mColName] && columnWidths[col.mColName].wrap) || wrapText;
                                var style = 'text-align:' + align + ';';
                                if (!shouldWrap) {
                                    style += 'overflow:hidden;text-overflow:ellipsis;white-space:nowrap;';
                                } else {
                                    style += 'white-space:normal;word-wrap:break-word;';
                                }
                                // Also set width on td to match th
                                var width = columnWidths[col.mColName] || col.mUIHelper.display_width || "auto";
                                if (typeof width === "number") width = width + "%";
                                style += 'width:' + width + ';min-width:' + width + ';max-width:' + width + ';';
                                var titleAttr = '';
                                if (!shouldWrap && displayValue.length > 50) {
                                    titleAttr = ' title="' + Util.htmlEntities(displayValue) + '"';
                                }
                                html += '<td style="' + style + '"' + titleAttr + '>' + Util.htmlEntities(displayValue) + '</td>';
                            });
                            html += '</tr>';
                        });
                        html += '</tbody>';

                        // --- Summary row (if any column has mSummary === "SUM") ---
                        var hasSummary = false;
                        lctb.cols.forEach(function (col) {
                            if (col.mSummary === "SUM" && !col.mHideCol) hasSummary = true;
                        });
                        if (hasSummary) {
                            html += '<tfoot><tr>';
                            lctb.cols.forEach(function (col, idx) {
                                if (col.mHideCol) return;
                                if (col.mSummary === "SUM") {
                                    var sum = 0;
                                    lctb.rows.forEach(function (row) {
                                        var val = row.cells[idx].getValue();
                                        if (typeof val === "number") sum += val;
                                    });
                                    var displaySum = formatCellValue(sum, col);
                                    var align = col.mUIHelper.display_align || "left";
                                    var width = columnWidths[col.mColName] || col.mUIHelper.display_width || "auto";
                                    if (typeof width === "number") width = width + "%";
                                    html += '<td style="text-align:' + align + ';font-weight:bold;border-top:2px solid #ccc;width:' + width + ';min-width:' + width + ';max-width:' + width + ';">' + Util.htmlEntities(displaySum) + '</td>';
                                } else {
                                    var width = columnWidths[col.mColName] || col.mUIHelper.display_width || "auto";
                                    if (typeof width === "number") width = width + "%";
                                    html += '<td style="width:' + width + ';min-width:' + width + ';max-width:' + width + ';"></td>';
                                }
                            });
                            html += '</tr></tfoot>';
                        }

                        html += '</table>';
                        return html;
                    }

                    // --- Render table into ScrollContainer ---
                    function renderTable(container, lctb) {
                        container.destroyContent();
                        var htmlContent = buildTableHTML(lctb);
                        var oHTML = new sap.ui.core.HTML({
                            content: htmlContent,
                            width: "100%",
                            height: "100%"
                        });
                        oHTML.addStyleClass("tableCardHTML");
                        container.addContent(oHTML);
                        attachRowClick(container);
                    }

                    // --- Attach row click handler ---
                    function attachRowClick(container) {
                        if (typeof rowClickHandler !== "function") return;
                        setTimeout(function () {
                            var domRef = container.getDomRef();
                            if (!domRef) return;
                            var $table = $(domRef).find("table");
                            if ($table.length === 0) return;
                            $table.off("click", "tr").on("click", "tr", function (e) {
                                var $row = $(this);
                                var rowIndex = $row.data("row");
                                if (rowIndex === undefined) return;
                                var rowData = {};
                                var lctb = container._lctb;
                                if (lctb) {
                                    lctb.cols.forEach(function (col) {
                                        // if (col.mHideCol) return;
                                        rowData[col.mColName] = lctb.getFieldValue(rowIndex, col.mColName);
                                    });
                                }
                                rowClickHandler(rowData, e, rowIndex);
                            });
                        }, 100);
                    }

                    // --- Build header ---
                    function buildHeader() {
                        var oHeader = new sap.m.HBox({
                            width: "100%",
                            alignItems: "Center",
                            justifyContent: "SpaceBetween",
                            items: [
                                new sap.m.Text({ text: Util.getLangText(title) }).addStyleClass("cardTitle"),
                                currentSettings.showSettings ? new sap.m.Button({
                                    icon: "sap-icon://settings",
                                    tooltip: "Change parameters",
                                    press: function () {
                                        if (typeof currentSettings.onSettings === "function") {
                                            currentSettings.onSettings(oCard, currentData, currentSettings);
                                        } else {
                                            sap.m.MessageToast.show("No settings handler defined.");
                                        }
                                    }
                                }).addStyleClass("sapUiTinyMarginBegin") : null
                            ].filter(item => item !== null)
                        }).addStyleClass("cardHeaderBar");
                        oHeader.setLayoutData(new sap.m.FlexItemData({ growFactor: 0 }));
                        return oHeader;
                    }

                    // --- Build table container (ScrollContainer) ---
                    function buildTableContainer(lctb) {
                        var oContainer = new sap.m.ScrollContainer({
                            width: "100%",
                            height: "100%",
                            vertical: true,
                            horizontal: false
                        });
                        oContainer.setLayoutData(new sap.m.FlexItemData({ growFactor: 1 }));
                        oContainer._lctb = lctb;
                        return oContainer;
                    }

                    // --- Initial construction ---
                    var oHeader = buildHeader();
                    var oTableContainer = buildTableContainer(null);

                    var oCard = new sap.m.VBox({
                        width: currentSettings.width,
                        height: currentSettings.height,
                        alignItems: "Stretch",
                        items: [oHeader, oTableContainer]
                    }).addStyleClass("gaugeCard tableCard");

                    // --- Load data ---
                    function loadTableData() {
                        if (typeof loadData === "function") {
                            isLoading = true;
                            oTableContainer.destroyContent();
                            oTableContainer.addContent(new sap.m.BusyIndicator({ size: ".25rem" }));
                            loadData().then(function (result) {
                                isLoading = false;
                                var lctb = null;
                                if (result instanceof QueryView) {
                                    lctb = result.mLctb;
                                } else if (result instanceof LocalTableData) {
                                    lctb = result;
                                } else {
                                    throw new Error("loadData must return QueryView or LocalTableData");
                                }
                                currentData = lctb;
                                oTableContainer._lctb = lctb;
                                renderTable(oTableContainer, lctb);
                            }).catch(function (err) {
                                sap.m.MessageToast.show("Error loading table: " + err.message);
                                oTableContainer.destroyContent();
                                oTableContainer.addContent(new sap.m.Text({ text: "Error loading data" }));
                            });
                        } else if (queryView) {
                            var lctb = queryView.mLctb;
                            currentData = lctb;
                            oTableContainer._lctb = lctb;
                            renderTable(oTableContainer, lctb);
                        } else {
                            oTableContainer.destroyContent();
                            oTableContainer.addContent(new sap.m.Text({ text: "No data provided" }));
                        }
                    }

                    loadTableData();

                    // --- Update methods ---
                    oCard.updateData = function (newQVorLCTB) {
                        var lctb = null;
                        if (newQVorLCTB instanceof QueryView) {
                            lctb = newQVorLCTB.mLctb;
                        } else if (newQVorLCTB instanceof LocalTableData) {
                            lctb = newQVorLCTB;
                        } else {
                            return;
                        }
                        currentData = lctb;
                        oTableContainer._lctb = lctb;
                        renderTable(oTableContainer, lctb);
                    };

                    oCard.updateSettings = function (newSettings) {
                        for (var key in newSettings) {
                            if (newSettings.hasOwnProperty(key)) {
                                currentSettings[key] = newSettings[key];
                            }
                        }
                        oCard.setWidth(currentSettings.width);
                        oCard.setHeight(currentSettings.height);
                        var oldHeader = oCard.getItems()[0];
                        var oldContainer = oCard.getItems()[1];
                        var newHeader = buildHeader();
                        var newContainer = buildTableContainer(currentData);
                        oCard.removeItem(oldHeader);
                        oCard.removeItem(oldContainer);
                        oCard.addItem(newHeader);
                        oCard.addItem(newContainer);
                        oldHeader.destroy();
                        oldContainer.destroy();
                        if (currentData) {
                            renderTable(newContainer, currentData);
                        }
                    };

                    oCard.updateCard = function (newQVorLCTB, newSettings) {
                        if (newQVorLCTB) {
                            var lctb = null;
                            if (newQVorLCTB instanceof QueryView) {
                                lctb = newQVorLCTB.mLctb;
                            } else if (newQVorLCTB instanceof LocalTableData) {
                                lctb = newQVorLCTB;
                            }
                            if (lctb) {
                                currentData = lctb;
                                oTableContainer._lctb = lctb;
                            }
                        }
                        if (newSettings) {
                            for (var key in newSettings) {
                                if (newSettings.hasOwnProperty(key)) {
                                    currentSettings[key] = newSettings[key];
                                }
                            }
                        }
                        oCard.setWidth(currentSettings.width);
                        oCard.setHeight(currentSettings.height);
                        var oldHeader = oCard.getItems()[0];
                        var oldContainer = oCard.getItems()[1];
                        var newHeader = buildHeader();
                        var newContainer = buildTableContainer(currentData);
                        oCard.removeItem(oldHeader);
                        oCard.removeItem(oldContainer);
                        oCard.addItem(newHeader);
                        oCard.addItem(newContainer);
                        oldHeader.destroy();
                        oldContainer.destroy();
                        if (currentData) {
                            renderTable(newContainer, currentData);
                        }
                    };

                    oCard.getData = function () { return currentData; };
                    oCard.getSettings = function () { return currentSettings; };
                    oCard.isLoading = function () { return isLoading; };

                    return oCard;
                },
                createCustomCard: function (name, config) {
                    var sett = config.settings || {};
                    var title = config.title || "";
                    var items = config.items || [];
                    var rowClickHandler = config.rowClickHandler || null;
                    var loadData = config.loadData || null;
                    var ratioBase = config.ratioBase || null;
                    var cardWidth = sett.width || "100%";
                    var minHeight = sett.minHeight || "0";
                    var showSettings = sett.showSettings !== undefined ? sett.showSettings : true;
                    var onSettings = sett.onSettings || null;
                    var rowHeight = sett.rowHeight || 26;
                    var headerHeight = sett.headerHeight || 32;
                    var padding = sett.padding || 10;

                    var currentItems = items.slice();
                    var currentItemsCache = [];
                    var isLoading = false;
                    var oCard = null;
                    var oCanvas = null;
                    var canvasId = "customCanvas_" + name + "_" + Date.now();
                    var canvasEl = null;
                    var resizeHandlerId = null;
                    var rowHitMap = [];
                    var hoveredItem = null;

                    // Spinner state
                    var spinnerFrame = 0;
                    var spinnerTimer = null;

                    // ---------------------------------------------------------------
                    // Parse "px" string or number
                    // ---------------------------------------------------------------
                    function toNumberPx(v, def) {
                        if (v === null || v === undefined || v === "") return def;
                        if (typeof v === "number") return v;
                        var s = String(v).replace("px", "").trim();
                        var n = parseFloat(s);
                        return isNaN(n) ? def : n;
                    }

                    // ---------------------------------------------------------------
                    // Format a number
                    // ---------------------------------------------------------------
                    function formatNumber(val, format) {
                        var sett2 = sap.ui.getCore().getModel("settings").getData();
                        if (val === null || val === undefined || val === "") return "";
                        if (format === "MONEY_FORMAT") {
                            return new DecimalFormat(sett2["FORMAT_MONEY_1"]).format(val);
                        }
                        if (format === "QTY_FORMAT") {
                            return new DecimalFormat(sett2["FORMAT_QTY_1"]).format(val);
                        }
                        if (format) {
                            try { return new DecimalFormat(format).format(val); } catch (e) { }
                        }
                        if (typeof val === "number" && !isNaN(val)) return val.toLocaleString();
                        return val.toString();
                    }

                    // ---------------------------------------------------------------
                    // Resolve per-item style into a font/color object
                    // ---------------------------------------------------------------
                    function resolveStyle(itemStyle, defaults, themeColors) {
                        var s = itemStyle || {};
                        var bold = (s.bold !== undefined) ? s.bold : defaults.bold;
                        var italic = (s.italic !== undefined) ? s.italic : (defaults.italic || false);
                        var fontSize = (s.fontSize !== undefined) ? s.fontSize : defaults.fontSize;
                        var color = s.color || defaults.color || themeColors.textColor;
                        return { bold: bold, italic: italic, fontSize: fontSize, color: color };
                    }

                    function makeFont(fontFamily, style) {
                        var w = style.bold ? "bold" : "normal";
                        var st = style.italic ? "italic" : "normal";
                        return st + " " + w + " " + style.fontSize + "px " + fontFamily;
                    }

                    // ---------------------------------------------------------------
                    // Compute content height (enforces minHeight during loading)
                    // ---------------------------------------------------------------
                    function computeContentHeight(items) {
                        var h = 0;
                        items.forEach(function (item) {
                            var type = item.type || "row";
                            if (type === "header") h += headerHeight;
                            else if (type === "divider") h += 10;
                            else if (type === "spacer") h += parseInt(item.height || 10);
                            else if (type === "text") h += rowHeight;
                            else if (type === "total") h += rowHeight + 8;
                            else h += rowHeight;
                        });
                        h += padding * 2;

                        var minH = toNumberPx(minHeight, 0);
                        if (items.length === 0 && minH > 0) return minH;
                        return Math.max(h, minH);
                    }

                    // ---------------------------------------------------------------
                    // Spinner
                    // ---------------------------------------------------------------
                    function drawSpinner(ctx, cssWidth, cssHeight, colors) {
                        var cx = cssWidth / 2;
                        var cy = cssHeight / 2;
                        var r = 14;
                        var arcs = 12;
                        var arcLen = (Math.PI * 2) / arcs;

                        ctx.save();
                        ctx.translate(cx, cy);
                        ctx.rotate(spinnerFrame * (Math.PI * 2) / arcs);
                        for (var i = 0; i < arcs; i++) {
                            var alpha = (i + 1) / arcs;
                            ctx.beginPath();
                            ctx.strokeStyle = colors.labelColor;
                            ctx.globalAlpha = alpha;
                            ctx.lineWidth = 3;
                            ctx.arc(0, 0, r, i * arcLen, (i + 1) * arcLen - 0.05);
                            ctx.stroke();
                        }
                        ctx.restore();
                        ctx.globalAlpha = 1;

                        if (!spinnerTimer && isLoading) {
                            spinnerTimer = setInterval(function () {
                                spinnerFrame++;
                                if (!isLoading || !canvasEl) {
                                    clearInterval(spinnerTimer);
                                    spinnerTimer = null;
                                    return;
                                }
                                drawContent();
                            }, 80);
                        }
                    }

                    // ---------------------------------------------------------------
                    // Draw content
                    // ---------------------------------------------------------------
                    function drawContent() {
                        if (!canvasEl) return;

                        var dpr = window.devicePixelRatio || 1;
                        var cssWidth = canvasEl.clientWidth || canvasEl.parentNode.clientWidth || 300;
                        var contentItems = currentItemsCache;
                        var cssHeight = computeContentHeight(contentItems);

                        // Resize canvas for HiDPI
                        canvasEl.width = Math.round(cssWidth * dpr);
                        canvasEl.height = Math.round(cssHeight * dpr);
                        canvasEl.style.width = cssWidth + "px";
                        canvasEl.style.height = cssHeight + "px";

                        var ctx = canvasEl.getContext("2d");
                        ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
                        ctx.clearRect(0, 0, cssWidth, cssHeight);

                        // ---- Theme ----
                        var cs = getComputedStyle(document.documentElement);
                        var themeColors = {
                            textColor: cs.getPropertyValue("--sapTextColor").trim() || "#000",
                            labelColor: cs.getPropertyValue("--sapContent_LabelColor").trim() || "#666",
                            borderColor: cs.getPropertyValue("--sapList_BorderColor").trim() || "#ccc",
                            hoverBg: cs.getPropertyValue("--sapList_Hover_Background").trim() || "#f0f0f0",
                            hoverText: cs.getPropertyValue("--sapActiveColor").trim() || "#0066cc",
                            lineColor: "darkgrey"
                        };
                        var fontFamily = cs.getPropertyValue("--sapFontFamily").trim() || "'72', Arial, sans-serif";

                        // ---- Loading state ----
                        if (contentItems.length === 0 && isLoading) {
                            drawSpinner(ctx, cssWidth, cssHeight, themeColors);
                            rowHitMap = [];
                            return;
                        }

                        var leftPad = padding;
                        var rightPad = padding;
                        var usableW = cssWidth - leftPad - rightPad;

                        var labelW = usableW * 0.65;
                        var opW = usableW * 0.10;
                        var valueW = usableW * 0.25;
                        var lovLabelW = usableW * 0.50;
                        var lovValueW = usableW * 0.30;

                        // ---- Hover background (before text) ----
                        if (hoveredItem && typeof rowClickHandler === "function") {
                            for (var hi = 0; hi < rowHitMap.length; hi++) {
                                if (rowHitMap[hi].item === hoveredItem) {
                                    var hv = rowHitMap[hi];
                                    ctx.fillStyle = themeColors.hoverBg;
                                    ctx.fillRect(0, hv.y1, cssWidth, hv.y2 - hv.y1);
                                    break;
                                }
                            }
                        }

                        var y = padding;
                        rowHitMap = [];

                        // Ratio total for LOV (auto-compute if not provided)
                        var ratioTotal = ratioBase;
                        if (!ratioTotal) {
                            var sum = 0;
                            contentItems.forEach(function (it) {
                                if (it.type === "lov" && it.includeInRatio !== false)
                                    sum += parseFloat(it.value) || 0;
                            });
                            ratioTotal = sum;
                        }

                        var runningTotal = 0;
                        var lastFormat = null;
                        var firstInGroup = true;

                        function colorFor(item, baseColor) {
                            if (rowClickHandler && item === hoveredItem) return themeColors.hoverText;
                            return baseColor;
                        }

                        contentItems.forEach(function (item, index) {
                            var type = item.type || "row";

                            if (type === "row" && item.format) lastFormat = item.format;

                            // Running total uses `op` (row only)
                            if (type === "row") {
                                var op0 = item.op || "+";
                                var val0 = parseFloat(item.value) || 0;
                                if (op0 === "+") runningTotal += val0;
                                else if (op0 === "-") runningTotal -= val0;
                            }

                            // ---- HEADER ----
                            if (type === "header") {
                                var styleH = resolveStyle(item.style, { bold: true, fontSize: 14 }, themeColors);
                                ctx.font = makeFont(fontFamily, styleH);
                                ctx.fillStyle = colorFor(item, styleH.color);
                                ctx.textAlign = "left";
                                ctx.textBaseline = "middle";
                                ctx.fillText(Util.getLangText(item.label || ""), leftPad, y + headerHeight / 2);

                                rowHitMap.push({ y1: y, y2: y + headerHeight, item: item, index: index });
                                y += headerHeight;
                            }

                            // ---- DIVIDER ----
                            else if (type === "divider") {
                                ctx.beginPath();
                                ctx.strokeStyle = themeColors.lineColor;
                                ctx.lineWidth = 1;
                                ctx.moveTo(leftPad, y + 3);
                                ctx.lineTo(cssWidth - rightPad, y + 3);
                                ctx.stroke();
                                y += 10;
                            }

                            // ---- SPACER ----
                            else if (type === "spacer") {
                                y += parseInt(item.height || 10);
                            }

                            // ---- TEXT ----
                            else if (type === "text") {
                                var styleT = resolveStyle(item.style, { bold: false, fontSize: 13 }, themeColors);
                                ctx.font = makeFont(fontFamily, styleT);
                                ctx.fillStyle = colorFor(item, styleT.color);
                                ctx.textAlign = "left";
                                ctx.textBaseline = "middle";
                                ctx.fillText(Util.getLangText(item.text || ""), leftPad, y + rowHeight / 2);

                                rowHitMap.push({ y1: y, y2: y + rowHeight, item: item, index: index });
                                y += rowHeight;
                            }

                            // ---- LOV (with per-cell style customization) ----
                            else if (type === "lov") {
                                var lovValue = parseFloat(item.value) || 0;

                                // Ratio: show only if explicitly provided AND > 0
                                var showRatio = false;
                                var ratioNum = 0;
                                if (item.ratio !== undefined && item.ratio !== null &&
                                    item.ratio !== "" && item.ratio !== 0 && item.ratio !== "0") {
                                    ratioNum = parseFloat(item.ratio);
                                    if (!isNaN(ratioNum) && ratioNum > 0) showRatio = true;
                                }

                                // Base style – applies to all 3 cells (label, value, ratio)
                                var baseStyle = item.style || {};

                                // Per-cell merged styles: base + specific overrides
                                var mergedL = Object.assign({}, baseStyle, item.styleLabel || {});
                                var mergedV = Object.assign({}, baseStyle, item.styleValue || {});
                                var mergedR = Object.assign({}, baseStyle, item.styleRatio || {});

                                var styleL = resolveStyle(mergedL, { bold: false, fontSize: 13 }, themeColors);
                                var styleV = resolveStyle(mergedV, { bold: false, fontSize: 13 }, themeColors);
                                var styleR = resolveStyle(mergedR, { bold: false, fontSize: 12, color: themeColors.labelColor }, themeColors);

                                ctx.textBaseline = "middle";

                                // Label
                                ctx.font = makeFont(fontFamily, styleL);
                                ctx.fillStyle = colorFor(item, styleL.color);
                                ctx.textAlign = "left";
                                ctx.fillText(Util.getLangText(item.label || ""), leftPad, y + rowHeight / 2);

                                // Value
                                ctx.font = makeFont(fontFamily, styleV);
                                ctx.fillStyle = colorFor(item, styleV.color);
                                ctx.textAlign = "right";
                                var lovValueX = leftPad + lovLabelW + lovValueW;
                                ctx.fillText(formatNumber(lovValue, item.format), lovValueX, y + rowHeight / 2);

                                // Ratio – integer only
                                if (showRatio) {
                                    ctx.font = makeFont(fontFamily, styleR);
                                    ctx.fillStyle = colorFor(item, styleR.color);
                                    ctx.textAlign = "right";
                                    ctx.fillText(Math.round(ratioNum) + "%", cssWidth - rightPad, y + rowHeight / 2);
                                }

                                rowHitMap.push({ y1: y, y2: y + rowHeight, item: item, index: index });
                                y += rowHeight;
                            }

                            // ---- TOTAL ----
                            else if (type === "total") {
                                // Solid line above
                                ctx.beginPath();
                                ctx.strokeStyle = themeColors.lineColor;
                                ctx.lineWidth = 1;
                                ctx.moveTo(leftPad, y + 3);
                                ctx.lineTo(cssWidth - rightPad, y + 3);
                                ctx.stroke();
                                y += 6;

                                var totalFormat = item.format || lastFormat;

                                // Total row: NOT bold by default (override via style.bold)
                                var styleTot = resolveStyle(item.style, { bold: false, fontSize: 13 }, themeColors);

                                // Label
                                ctx.font = makeFont(fontFamily, styleTot);
                                ctx.fillStyle = colorFor(item, styleTot.color);
                                ctx.textAlign = "left";
                                ctx.textBaseline = "middle";
                                ctx.fillText(Util.getLangText(item.label || ""), leftPad, y + rowHeight / 2);

                                // Value (dispOp ignored on totals)
                                ctx.fillStyle = colorFor(item, styleTot.color);
                                ctx.textAlign = "right";
                                var totalValX = leftPad + labelW + opW + valueW;
                                ctx.fillText(formatNumber(Math.abs(runningTotal), totalFormat), totalValX, y + rowHeight / 2);

                                rowHitMap.push({ y1: y, y2: y + rowHeight, item: item, index: index });
                                y += rowHeight;

                                firstInGroup = true;
                                // runningTotal = 0;
                            }

                            // ---- NORMAL MATH ROW ----
                            else {
                                var op = item.op || "+";
                                var val = parseFloat(item.value) || 0;

                                // dispOp = display string (row only, falls back to op)
                                var dispOp = (item.dispOp !== undefined) ? item.dispOp : op;
                                var sign = /*firstInGroup ? "" :*/ dispOp;

                                var styleRow = resolveStyle(item.style, { bold: false, fontSize: 13 }, themeColors);
                                var styleOp = resolveStyle(item.styleOp, { bold: true, fontSize: 14, color: themeColors.labelColor }, themeColors);

                                ctx.textBaseline = "middle";

                                // Label
                                ctx.font = makeFont(fontFamily, styleRow);
                                ctx.fillStyle = colorFor(item, styleRow.color);
                                ctx.textAlign = "left";
                                ctx.fillText(Util.getLangText(item.label || ""), leftPad, y + rowHeight / 2);

                                // Operator
                                if (sign) {
                                    ctx.font = makeFont(fontFamily, styleOp);
                                    ctx.fillStyle = colorFor(item, styleOp.color);
                                    ctx.textAlign = "right";
                                    var opX = leftPad + labelW + opW;
                                    ctx.fillText(sign, opX, y + rowHeight / 2);
                                }

                                // Value
                                ctx.font = makeFont(fontFamily, styleRow);
                                ctx.fillStyle = colorFor(item, styleRow.color);
                                ctx.textAlign = "right";
                                var valX = leftPad + labelW + opW + valueW;
                                ctx.fillText(formatNumber(Math.abs(val), item.format), valX, y + rowHeight / 2);

                                rowHitMap.push({ y1: y, y2: y + rowHeight, item: item, index: index });
                                y += rowHeight;

                                firstInGroup = false;
                            }
                        });
                    }

                    // ---------------------------------------------------------------
                    // Click / hover
                    // ---------------------------------------------------------------
                    function isClickableType(item) {
                        var t = item.type || "row";
                        return (t !== "header" && t !== "divider" && t !== "spacer" && t !== "text" && t !== "total");
                    }

                    function handleCanvasClick(event) {
                        if (typeof rowClickHandler !== "function") return;
                        var rect = canvasEl.getBoundingClientRect();
                        var clickY = event.clientY - rect.top;
                        for (var i = 0; i < rowHitMap.length; i++) {
                            var hit = rowHitMap[i];
                            if (clickY >= hit.y1 && clickY < hit.y2 && isClickableType(hit.item)) {
                                rowClickHandler(hit.item, hit.item.hiddenData, event, hit.index);
                                return;
                            }
                        }
                    }

                    function handleCanvasMouseMove(event) {
                        if (typeof rowClickHandler !== "function") return;
                        var rect = canvasEl.getBoundingClientRect();
                        var mouseY = event.clientY - rect.top;
                        var newHover = null;
                        for (var i = 0; i < rowHitMap.length; i++) {
                            var hit = rowHitMap[i];
                            if (mouseY >= hit.y1 && mouseY < hit.y2 && isClickableType(hit.item)) {
                                newHover = hit.item;
                                break;
                            }
                        }
                        if (newHover !== hoveredItem) {
                            hoveredItem = newHover;
                            canvasEl.style.cursor = hoveredItem ? "pointer" : "default";
                            drawContent();
                        }
                    }

                    function handleCanvasMouseLeave() {
                        if (hoveredItem !== null) {
                            hoveredItem = null;
                            if (canvasEl) canvasEl.style.cursor = "default";
                            drawContent();
                        }
                    }

                    // ---------------------------------------------------------------
                    // Canvas control
                    // ---------------------------------------------------------------
                    function createCanvasControl() {
                        return new sap.ui.core.HTML({
                            content: '<canvas id="' + canvasId + '" ' +
                                'style="display:block;width:' + cardWidth + ';pointer-events:auto;' +
                                (rowClickHandler ? 'cursor:pointer;' : 'cursor:default;') + '"></canvas>'
                        });
                    }

                    // ---------------------------------------------------------------
                    // Render canvas
                    // ---------------------------------------------------------------
                    function renderCanvas() {
                        canvasEl = document.getElementById(canvasId);
                        if (!canvasEl) return;
                        currentItemsCache = currentItems;
                        drawContent();

                        if (canvasEl._canvasClick) canvasEl.removeEventListener("click", canvasEl._canvasClick);
                        if (typeof rowClickHandler === "function") {
                            canvasEl._canvasClick = handleCanvasClick;
                            canvasEl.addEventListener("click", handleCanvasClick);

                            canvasEl._canvasMove = handleCanvasMouseMove;
                            canvasEl.addEventListener("mousemove", handleCanvasMouseMove);

                            canvasEl._canvasLeave = handleCanvasMouseLeave;
                            canvasEl.addEventListener("mouseleave", handleCanvasMouseLeave);
                        }
                    }

                    // ---------------------------------------------------------------
                    // Header
                    // ---------------------------------------------------------------
                    function buildHeader() {
                        var oHeader = new sap.m.HBox({
                            width: "100%",
                            alignItems: "Center",
                            justifyContent: "SpaceBetween",
                            items: [
                                new sap.m.Text({
                                    text: Util.getLangText(title),
                                    wrapping: false
                                }).addStyleClass("cardTitle"),
                                showSettings ? new sap.m.Button({
                                    icon: "sap-icon://settings",
                                    tooltip: "Change parameters",
                                    press: function () {
                                        if (typeof onSettings === "function") onSettings(oCard, currentItems, sett);
                                        else sap.m.MessageToast.show("No settings handler defined.");
                                    }
                                }).addStyleClass("sapUiTinyMarginBegin") : null
                            ].filter(function (i) { return i !== null; })
                        }).addStyleClass("cardHeaderBar");
                        oHeader.setLayoutData(new sap.m.FlexItemData({ growFactor: 0, shrinkFactor: 0 }));
                        return oHeader;
                    }

                    // ---------------------------------------------------------------
                    // Build card
                    // ---------------------------------------------------------------
                    function buildCard() {
                        var oHeader = buildHeader();
                        oCanvas = createCanvasControl();
                        oCanvas.setLayoutData(new sap.m.FlexItemData({
                            growFactor: 1, /*shrinkFactor: 1, minHeight: "0"*/
                        }));

                        var card = new sap.m.VBox({
                            width: cardWidth,
                            alignItems: "Stretch",
                            items: [oHeader, oCanvas]
                        }).addStyleClass("gaugeCard customCard canvasCustomCard");

                        card._canvas = oCanvas;
                        card._header = oHeader;

                        card.addEventDelegate({
                            onAfterRendering: function () {
                                renderCanvas();
                                var domRef = card.getDomRef();
                                if (domRef && sap.ui.core.ResizeHandler) {
                                    if (resizeHandlerId) sap.ui.core.ResizeHandler.deregister(resizeHandlerId);
                                    resizeHandlerId = sap.ui.core.ResizeHandler.register(domRef, function () {
                                        drawContent();
                                    });
                                }
                            },
                            onExit: function () {
                                if (resizeHandlerId) {
                                    sap.ui.core.ResizeHandler.deregister(resizeHandlerId);
                                    resizeHandlerId = null;
                                }
                                if (spinnerTimer) {
                                    clearInterval(spinnerTimer);
                                    spinnerTimer = null;
                                }
                                if (canvasEl) {
                                    if (canvasEl._canvasClick) canvasEl.removeEventListener("click", canvasEl._canvasClick);
                                    if (canvasEl._canvasMove) canvasEl.removeEventListener("mousemove", canvasEl._canvasMove);
                                    if (canvasEl._canvasLeave) canvasEl.removeEventListener("mouseleave", canvasEl._canvasLeave);
                                }
                            }
                        });

                        return card;
                    }

                    // ---------------------------------------------------------------
                    // Initial build (lazy loading)
                    // ---------------------------------------------------------------
                    if (typeof loadData === "function") {
                        isLoading = true;
                        currentItems = [];
                        currentItemsCache = [];
                        oCard = buildCard();

                        loadData().then(function (data) {
                            isLoading = false;
                            if (spinnerTimer) { clearInterval(spinnerTimer); spinnerTimer = null; }
                            currentItems = data.slice();
                            currentItemsCache = currentItems;
                            renderCanvas();
                        }).catch(function (err) {
                            isLoading = false;
                            if (spinnerTimer) { clearInterval(spinnerTimer); spinnerTimer = null; }
                            sap.m.MessageToast.show("Error: " + err.message);
                            currentItems = [
                                {
                                    type: "text", text: "Error loading data",
                                    style: { color: "#c0392b" }
                                }
                            ];
                            currentItemsCache = currentItems;
                            renderCanvas();
                        });
                    } else {
                        currentItemsCache = currentItems;
                        oCard = buildCard();
                    }

                    // ---------------------------------------------------------------
                    // Update methods
                    // ---------------------------------------------------------------
                    oCard.updateData = function (newItems) {
                        if (!newItems) return;
                        isLoading = false;
                        if (spinnerTimer) { clearInterval(spinnerTimer); spinnerTimer = null; }
                        currentItems = newItems.slice();
                        currentItemsCache = currentItems;
                        hoveredItem = null;
                        renderCanvas();
                    };

                    oCard.updateSettings = function (newSettings) {
                        if (!newSettings) return;
                        for (var key in newSettings) {
                            if (newSettings.hasOwnProperty(key)) sett[key] = newSettings[key];
                        }
                        if (sett.width) { cardWidth = sett.width; oCard.setWidth(cardWidth); }
                        if (sett.minHeight !== undefined) minHeight = sett.minHeight;
                        if (sett.rowHeight) rowHeight = sett.rowHeight;
                        if (sett.headerHeight) headerHeight = sett.headerHeight;
                        if (sett.padding) padding = sett.padding;

                        if (newSettings.showSettings !== undefined) {
                            showSettings = newSettings.showSettings;
                            var oldHeader = oCard.getItems()[0];
                            var newHeader = buildHeader();
                            oCard.removeItem(oldHeader);
                            oCard.insertItem(newHeader, 0);
                            oldHeader.destroy();
                            oCard._header = newHeader;
                        }
                        setTimeout(drawContent, 50);
                    };

                    oCard.getData = function () { return currentItems; };
                    oCard.getSettings = function () { return sett; };
                    oCard.isLoading = function () { return isLoading; };
                    oCard.redraw = renderCanvas;

                    return oCard;
                },
                statusBarText: function (msg, blink, blinkTime, showtoast) {

                    if (Util.nvl(msg, "") != "")
                        UtilGen.DBView.txtStatus.setText(msg);
                    else {
                        UtilGen.DBView.txtStatus.setText(msg);
                        UtilGen.DBView.txtStatus.removeStyleClass("blinking");
                        if (showtoast != undefined) {
                            if ($(".sapMMessageToast") != undefined &&
                                $(".sapMMessageToast").length > 0)
                                $(".sapMMessageToast").remove();
                        }
                        return;
                    }
                    if (Util.nvl(showtoast, undefined) != undefined && typeof showtoast == "function")
                        showtoast(msg);

                    if (Util.nvl(showtoast, undefined) != undefined && typeof showtoast != "function" && showtoast)
                        sap.m.MessageToast.show(msg);

                    UtilGen.DBView.txtStatus.removeStyleClass("blinking")

                    if (Util.nvl(blink, false)) {
                        UtilGen.DBView.txtStatus.addStyleClass("blinking")
                        setTimeout(() => {
                            UtilGen.DBView.txtStatus.removeStyleClass("blinking")
                        }, Util.nvl(blinkTime, 2500))
                    }
                    setTimeout(() => {
                        // if (msg == UtilGen.DBView.txtStatus.getText() == msg) {
                        UtilGen.DBView.txtStatus.removeStyleClass("blinking")
                        UtilGen.DBView.txtStatus.setText("");
                        // }
                    }, 8000)

                }
            },
            Security: {
                canEdit: function (grp, form, pForceful) {
                    var forceful = Util.nvl(pForceful, false);
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    if (!forceful && Util.nvl(sett[grp + "_" + form + "_editable"], 'TRUE') != "TRUE")
                        return false;
                    if (forceful && Util.nvl(sett[grp + "_" + form + "_editable"], 'FALSE') != "TRUE")
                        return false;

                    return true;

                },
                canDelete: function (grp, form, pForceful) {
                    var forceful = Util.nvl(pForceful, false);
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    if (!forceful && Util.nvl(sett[grp + "_" + form + "_deletable"], 'TRUE') != "TRUE")
                        return false;
                    if (forceful && Util.nvl(sett[grp + "_" + form + "_deletable"], 'FALSE') != "TRUE")
                        return false;

                    return true;

                },
                isReadOnly: function (grp, form, pForceful) {
                    var forceful = Util.nvl(pForceful, false);
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    if (!forceful && Util.nvl(sett[grp + "_" + form + "_readonly"], 'TRUE') != "TRUE")
                        return false;
                    if (forceful && Util.nvl(sett[grp + "_" + form + "_readonly"], 'FALSE') != "TRUE")
                        return true;
                    return false;
                },
                setLocatonEdit: function (form, ploc, throwErr, pDefaultLoc) {
                    var loc = Util.nvl(ploc, "qry1.location_code");
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var can_edit_loc = Util.getSetupVal("formsecure_change_location", "TRUE", true) == "TRUE" ? true : false;

                    if (!can_edit_loc) try {
                        form.frm.objs[loc].insert_allowed = false;
                        form.frm.objs[loc].edit_allowed = false;
                        form.frm.objs[loc].obj.setEditable(false);
                        if (Util.nvl(pDefaultLoc, false)) form.frm.setFieldValue(loc, sett["DEFAULT_LOCATION"], sett["DEFAULT_LOCATION"], false);
                    } catch (e) { if (Util.nvl(throwErr, false)) throw e; else console.log(e); }
                },
                setStoreEdit: function (form, pstore, throwErr, pDefaultStr) {
                    var str = Util.nvl(pstore, "qry1.stra");
                    var can_edit_store = Util.getSetupVal("formsecure_change_store", "TRUE", true) == "TRUE" ? true : false;
                    if (!can_edit_store) try {
                        form.frm.objs[str].insert_allowed = false;
                        form.frm.objs[str].insert_allowed = false;
                        form.frm.objs[str].obj.setEditable(false);
                        if (Util.nvl(pDefaultStr, false)) form.frm.setFieldValue(str, sett["DEFAULT_LOCATION"], sett["DEFAULT_STORE"], false);
                    } catch (e) { if (Util.nvl(throwErr, false)) throw e; else console.log(e); }
                },
                setLocatonEditRV: function (form, ploc, throwErr, pDefaultLoc) {
                    var thatRV = form;
                    var rptNo = Util.nvl(undefined, UtilGen.getControlValue(thatRV.lstRep));

                    var repCode = thatRV.reports[rptNo].code;
                    var loc = repCode + "@" + Util.nvl(ploc, "parameter.ploc");
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var can_edit_loc = Util.getSetupVal("formsecure_change_location", "TRUE", true) == "TRUE" ? true : false;

                    if (!can_edit_loc) try {
                        // var parent = form.view.byId("rep" + rptNo + "_" + (Util.nvl(ploc, "parameter.ploc") + form.timeInLong).replaceAll(".", ""));
                        // var para = form.view.byId("rep" + rptNo + "_" + (Util.nvl(ploc, "parameter.ploc") + "Para" + form.timeInLong).replaceAll(".", ""));

                        // parent.setEditable(false);
                        // para.setEditable(false);
                        // para.setEnabled(false);
                        // parent.setEnabled(false);
                        // form.objs[loc].obj.setEnabled(false);
                        form.objs[loc].obj.setEditable(false);
                        // form.objs[loc].obj.paraObj.setEnabled(false);
                        form.objs[loc].obj.paraObj.setEditable(false);
                        // form.objs[loc].obj.mainObj.setEnabled(false);
                        form.objs[loc].obj.mainObj.setEditable(false);
                        console.log('disabling......');

                        if (Util.nvl(pDefaultLoc, false)) form.setFieldValue(loc, sett["DEFAULT_LOCATION"], sett["DEFAULT_LOCATION"], false);
                    } catch (e) { if (Util.nvl(throwErr, false)) throw e; else console.log(e); }
                },
                setStoreEditRV: function (form, pstore, throwErr, pDefaultStr) {
                    var thatRV = form;
                    var rptNo = Util.nvl(undefined, UtilGen.getControlValue(thatRV.lstRep));

                    var repCode = thatRV.reports[rptNo].code;
                    var str = repCode + "@" + Util.nvl(pstore, "parameter.strno");
                    var sett = sap.ui.getCore().getModel("settings").getData();
                    var can_edit_store = Util.getSetupVal("formsecure_change_location", "TRUE", true) == "TRUE" ? true : false;

                    if (!can_edit_store) try {
                        // form.objs[str].obj.setEnabled(false);
                        form.objs[str].obj.setEditable(false);
                        // form.objs[str].obj.paraObj.setEnabled(false);
                        form.objs[str].obj.paraObj.setEditable(false);
                        // form.objs[str].obj.mainObj.setEnabled(false);
                        form.objs[str].obj.mainObj.setEditable(false);

                        if (Util.nvl(pDefaultStr, false)) form.setFieldValue(str, sett["DEFAULT_STORE"], sett["DEFAULT_STORE"], false);
                    } catch (e) { if (Util.nvl(throwErr, false)) throw e; else console.log(e); }
                }

            },

        };

        return UtilGen;
    });