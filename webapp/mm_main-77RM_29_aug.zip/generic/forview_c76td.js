img_response_1:images/responsive_1.png
img_hr_1:images/img1.png
img_fin_1:images/screen1.png

gl= الحسابات العامة
loginName=اسم المستخدم:
loginPwd=كلمه السر :
loginDatabase=قاعدة البيانات :
loginCmd=دخول
execute_query=معاينة الاستعلام
action=عمل
refresh=ت. الشاشة
refreshTip=تحديث الشاشة
loginMsg1=نجح تسجيل الدخول !
lastVouEntry=آخر سند تاريخ

cmdClose=خروج
soaTxt=ك. الحساب
saveRec=حفظ
delRec=حذف
editRec=تعديل
listRec=قائمة
newRec=جديد
printRec=طباعة

accNo=رقم حساب
titleTxt=إسم الحساب
titleTxt2=إسم الحساب2
parentAc=الحساب الرئيسي
parentTxt=الرئيسي
closeAc=الحسابات الختامية 
isBankCash=بنك / نقدا
lockAc=ايقاف حساب
startDate=تاريخ البدء
currencyCode=العملة
costCent=مركز تكلفة


newAc=إنشاء حساب
auditedTxt= الترحيل عمليات
executeTxt=تحميل
executeTooltip=تنفيذ والحصول على البيانات
showQuery=عرض الاستعلام
unAudited=قبل الترحيل
templTxt=النماذج

fromDate=من التاريخ
toDate=حتى تاريخ
levelNo=المستوى
inclRP=الذمم م./ د.
exclZero=بدون اصفار
showAboveCreditLimit=إظهار الحد الائتماني الأعلى

openBal=الرصيد الافتتاحي
debitTxt=مدين
creditTxt=دائن

transTxt=حركة الفترة الحالية
closeBal=الميزان
balanceTxt=الرصيد
summaryBalTxt=إجمالي الأرصدة

showMain=الشاشة الرئيسة

msgLastRepSaved=تم حفظ آخر تقرير تم تنفيذه ، هل تريد الاسترداد من الرئيسي؟


reportCaption1=اختر أي تقرير عن

trialBalance=ميزان المراجعة
resetTxt=إعادة

profitAndLoss=الربح والخسارة
plTit1=الربح والخسارة حسب الحسابات والمستويات
monthPL=الربح والخسارة الشهرية
monthPL1=الربح والخسارة الشهرية حسب المستويات ومركز التكلفة

exportPrint=التصدير / الطباعة


itemTxt=الأصناف
storeNo=رقم المخزن
txtTotIn=إجمالى. الداخل
txtTotOut=إجمالى. الخارج
transDate=تاريخ العملية
transNo=رقم العملية
transType=نوع العملية
noTxt=الرقم
qtyIn=الدخل 
qtyOut=خارج
itemPackD=وصف الشد
itemPack=الشد
itemUnitD=وحدة
itemCode=كود صناف
descrTxt=الوصف
refCode=الكود العميل
refName=اسم العميل

stockAgeingTxt=اعمار الأصناف
b30Txt=0-30 أيام
b60Txt=31-60 أيام
b90Txt=61-90 أيام
b120Txt=91-120 أيام
b150Txt=121-150 أيام

stockAgeingCostTxt= اعمار الأصناف مع التكلفة

stkCardRepTit=كارت صنف مخزون
stkCardRepTit2=كارت صنف مخزون
stkCardRep1=بطاقة صنف المخزون بالكمية
stkCardRep1Descr=بطاقة بيانات المخزون التاريخية مع الكمية فقط

stkCardRep2=بطاقة صنف المخزون التكلفة
stkCardRep2Descr=بطاقة بيانات المخزون التاريخية مع التكلفة

sbRepTit=رصيد المخزن
sbRepName1=رصيد المخزن بالكمية
sbRepDescr1=رصيد المخزن حسب الاصناف بالكمية

parentItemDescr=صنف رئيسى
itemPackQty=الكمية بالشد
itemPackCost=تكلفة الشد
itemCostAmt=اجمالى التكلفة
itemUnitQty=الكمية وحدة

inCost=قيمة الداخل
outCost=قيمة الخارج

sbRepName2=رصيد المخزن بالتكلفة
sbRepDescr2=رمز الصنف والوصف والكمية وقيمة التكلفة في المخزون.


sbRepName3=قيم المخزون حسب الأصناف الأم
sbRepDescr3=شجرة للأصناف الرئيسية رمز العنصر والوصف والكمية وقيمة التكلفة في المتجر.


ssRepTit=تقرير ملخص المخزون
ssRep1Name=ملخص المخزون حسب مجموعة الأصناف
ssRep1Descr=تقرير الشجرة مع الكود والتكلفة الدخول والخروج والكمية الصافية

incQty=في كمية
avgCost=متوسط التكلفة
netQty=صافي الكمية
avgCostAmt=متوسط قيمة التكلفة

masterAccHelp=اضغط على F2 لتحديد مكيف هواء أصلي جديد ورقم جديد أثناء إدخال مكيف الهواء الجديد

isRepTit=عملية المخزون
isRepName1=عملية المخزون
isRepDescr1=تقرير دوري ملخص الحركات بواسطة القسائم.

stkVouType=نوع الإيصال
grpByTxt=مجموعة من
locName=اسم الموقع
memoTxt=بيان
amountTxt=مبلغ

isRepName2=إيصال المخزون حسب الأصناف (التفاصيل)
isRepDescr2=تفاصيل حركة التقرير الدوري حسب الأصناف.

saRep1Tit=اعمار المخزون
saRepName1=اعمار المخزون
saRepDescr1=اعمار المخزون


totalTxt=الإجمالية
totalCost=التكلفة الإجمالية
totalQty=الكمية الإجمالية

iaRepName1=ملخص تكلفة تجميع حسب الأصناف
iaRepDescr1=التقرير الدوري ملخص تجميع الأصناف والتكاليفا


dateTxt=تاريخ
branchNoTxt=رقم الموقع
branchNmTxt=اسم الموقع
orderQtyTxt=كمية امر الشراء
dlvQtyTxt=كمية الانتاج
dueQtyTxt=كمية المتبقية
locationTxt=قسم
rcptDateTxt=البضائع المستلمة

lastDlv=آخر توصيل
timeTxt=وقت


custBalance=رصيد العميل
crdLimit=الحد الائتماني
pumpTxt=مضخات
mixerTxt=خلاطات
activeTxt=مشغول
availTxt=متوفرة
vehiclesTxt=مركبات

qlAllAccs=أرصدة الحسابات..
qlAllRPs=كل الشركاء..
qlAllCBs=جميع النقدية / البنوك..
qlAllCCs=جميع مراكز التكلفة..

quickEntries=إدخالات سريعة
commisionTxt=عمولة

finStat1=التقارير المالية
finStat1Descr=المجموع الفرعي للتقارير المالية
finStat=التقارير المالية

periodicBalanceTxt=الرصيد الفترة
ytdBalanceTxt=الرصيد من البداية
ytdRateTxt=نسبة الفترة%


rvnPRate=نسبة الفترة من الحساب الإجمالي
rvnYRate=بداية النسبة من الحساب الإجمالي
totAccNo=الحساب الإجمالي
ratioAccNo=حساب النسبة من الإجمالي



txtValue=القيمة
prodQty=كمية الإنتاج 
totPurchase=مشتريات مواد أولية
totCogs=إجمالي تكلفة البضائع
txtCom1=تكلفة المتر من المواد الأولية
inExp=المصاريف الغير مباشرة
txtCom2=تكلفة المتر من المصاريف الغير مباشرة
diExp=المصاريف المباشرة
txtCom3= تكلفة المتر من المصاريف المباشرة
txtCom4= إجمالي تكلفة المتر المصاريف
totSales=إجمالي قيمة المبيعات
totDisc=الخصم المسموح به
netSales=صافي المبيعات
avgSales=متوسط سعر بيع المتر
netCostm3=متوسط تكلفة المتر المكعب
netMargin=صافي الربح / الخسارة بالمتر
netMarginp=صافي الربح / الخسارة بالمتر %

rptCcpPhQty=الكمية حسب الفورمولا
rptCcpIssQty=الكمية الصادرة الفعلية
rptCcpVarQty=فرق الكمية بالزيادة/النقص
rptCcpVarRate=فرق الكمية بالزيادة/النقص %

finStat3Descr=Comparision Profit and loss by Yearly
finStat3=Year wise PL


agrRate= متوسط معدل النمو %

txtAvg=المتوسط

txtCust=العميل

purchaseReceipt=إيصالات الشراء
rcptDate=Receipt Date
rcptNo= رقم استلام 
txtDriver=سائق
truckNo=رقم الشاحنة
truckSize=الشاحنة مقاس
txtBranch=الفرع
txtProd=مواد أولية

txtTel=الهاتف
txtOrdType=نوع الفاتورة
ordDate=تاريخ الطلب
closeDate=تاريخ الإغلاق
closedBy=تم الإغلاق بواسطة

txtDriverNo=رقم السائق
txtDriverName=اسم السائق
txtDriverName2=اسم السائق 2
txtVehicleNo=رقم السيارة
txtMobile=الهاتف

newDriverText=السائق الجديد
txtDisc=الخصم
txtAddAmt=اضافة
txtGrossAmt=المبلغ الإجمالي
txtNetAmt=المبلغ الصافي
selectTxt=اختر
newCustomer=عميل جديد
newBranch=فرع جديد
dlvNoteBR=إيصال استلام-المبيعات
pdlvNoteBR=إيصال استلام-المشتريات
pdlvNotePO=استلام البضائع : PO

txtInvNo=رقم الفاتورة
txtInvDate=تاريخ الفاتورة
updateInv=تحديث الفاتورة
updatePrice=تحديث السعر

msgBRMustEnterOrdType=يجب إدخال نوع الفاتورة / المشتريات
msgBRMustEnterOrdRef=يجب أن يكون لحقل العميل قيمة 
msgBRMustEnterBranch=يجب أن يكون لحقل الفرع قيمة!!

msgMustSelectPOShipment=يجب تحديد طلب الشراء والشحن!

msgSaveFormData=هل تريد حفظ التغييرات في هذا النموذج؟

nameDailyItemSales=مبيعات أصناف اليومية
descrDailyItemSales=مبيعات أصناف اليومية
titDailyItemSales=مبيعات أصناف اليومية

nameCustItemSales=مبيعات أصناف مع العميل
descrcustItemSales=مبيعات أصناف مع العميل
titCustItemSales=مبيعات أصناف مع العميل
nameCustBranchSales=تقرير العملاء والمواقع بواسطة m3

txtBRTitleDashBoard=الاستعلام عن فواتير المبيعات
paraInclUnpost=يملك غير مُرحل



titlePostVou=Posting Vouchers
vouType=Voucher Type
vouNo=Vou No
vouDate=Vou Date
postVou=Post Vouchers
createdUser=Created By
createdOn=Created On
titNewCustBranch=New customer
txtBranches=Branches

titleSlsum=Sales Summary
titlePursum=Purchase Summary

txtNo=No
txtAddr=Address

recheckPrice=Re-Check prices
txtPrice=السعر
txtChkPrice=checked Price
txtItemPartNo=رقم القطعة
txtItemPower=الطاقة

titPurOrd=طلب شراء
titPurShipping=معلومات الشحن

poApprove=موافقة

referenceNo=مرجع
msgSaved=تم الحفظ...
titPurWzd=إنشاء المشتريات من التسليم - المعالج
titSalWzd=إنشاء المبيعات من التسليم - المعالج
txtSupplier=المورد
txtCustSupp=العميل/المورد
txtDaysOff=الفواتير الاخيرة
iAsmTit=تجميع الاصناف
rawMaterialStore=Raw Mat Str
finishedProdStore=Prod Str
itemDescr=الوصف

nameDlvAfterInvs=ملخص البرنامج اليومى  ( بعد اصدار الفواتير )
descrDlvAfterInvs=ملخص البرنامج اليومى  ( بعد اصدار الفواتير )
titDlvAfterInvs=ملخص البرنامج اليومى  ( بعد اصدار الفواتير )

nameDlvDetails=حركة سندات تسليم المبيعات
descrDlvDetails=حركة سندات تسليم المبيعات
titDlvDetails=حركة سندات تسليم المبيعات

nameDlvBeforeInvs=ملخص البرنامج اليومى ( قبل اصدار الفواتير )
descrDlvBeforeInvs=ملخص البرنامج اليومى ( قبل اصدار الفواتير )
titDlvBeforeInvs=ملخص البرنامج اليومى ( قبل اصدار الفواتير )

namePdlvDetails=حركة سندات تسليم المشتريات
descrPdlvDetails=حركة سندات تسليم المشتريات
titPdlvDetails=حركة سندات تسليم المشتريات

nameDlvDetailsTon=حركة سندات تسليم المبيعات  (TON & M3)
descrDlvDetailsTon=حركة سندات تسليم المبيعات (TON & M3)
titDlvDetailsTon=حركة سندات تسليم المبيعات (TON & M3)

titDriverTrips=دروب السائقين

titCSOA=كشف حساب العميل

txtNofDlv=عدد التسليم
txtNoOf=عدد
cmdDone=موافق

txtBranches=الفروع
custItems=أصناف العقد
cmdFetchFormula=حساب تلقائي..

sOrdBR=امر الشراء - المبيعات

invItems=العناصر الرئيسية
txtLock=قفل ?
txtNonStk=غير مخزون
txtProdCode=رمز المنتج
txtBarcode=الرمز الشريطي
txtDescr1=وصف 1
txtDescr2=الوصف 2
txtRemark=الشرح
txtPrice1=السعر 1
txtLsPrice=أقل سعر للبيع
txtPurPrice=سعر الشراء

rawItems=تجميع الاصناف
titRawItems=المواد الأولية


allBalance=كل الرصيد
unpostedBal=رصيد غير مُرحل
titRcvBalance=أرصدة المستحقين
msgDeleted=تم حذف البيانات...

addDlvToInv=إضافة سند التسليم
removeDlvToInv=حذف سند التسليم


qryPriceTon=Query to Input TON QTY & Price
txtQtyTon=الكمية طن
txtPriceTon=سعر الطن
dlvQty=الكمية المسلمة


dbQuickList=القائمة السريعة

dbActivityTxt= المعاملات
dbARTxt=المدينون
dbAPTxt=الدائنون
dbCashBankTxt=النقد/البنك

dbNetProfitTxt=صافي الربح
dbNetLossTxt=صافي الخسارة

dbPerformanceTxt= الأداء
dbNetSalesTxt=صافي المبيعات
dbOtherIncomeTxt=دخل آخر
dbCogsTxt=تكلفة البضائع
dbOtherExpTxt=نفقات أخرى
dbGPTxt=إجمالي الربح


db2CustSalesSum=ملخص مبيعات العملاء
db2CustItemsSalesSum=ملخص مبيعات العملاء مع الاصناف
db2ItemsCustSalesSum=مبيعات الاصناف مع ملخص العميل
db2DlvAfterSales=ملخص - بعد اصدار
db2DlvBeforeales=ملخص - قبل اصدار
db2CustBalances=أرصدة العملاء
db2CustAge=كشف اعمار الذمم
db2CustCollection=تقرير التحصيلات
db2CustPayments=المدفوعات
db2ExpensesFromAcc=المصروفات من النقد/البنك
db2CustReports=تقارير العملاء
db2SuppReports=تقارير المورد


db2SuppPurSum=ملخص شراء الموردين
db2PurItemsPurSum=ملخص مبيعات الموردين مع العناصر
db2ItemsSuppPurSum=ملخص مبيعات العناصر مع الموردين
db2PurDlvDetails=تسليم تفاصيل الشراء
db2SuppAge=تقرير تقادم الموردين
db2SuppPayments=مدفوعات المورد

txtCode=كود
m3Qty=M3 الكمية
tonQty=طن الكمية

txtNoOfDlv=عدد الإيصال.

txtCountCust=عميل
txtCountDate=يوم
txtCountInvs=الفاتورة
ordByTxt=حسب ترتيب 
txtByOrdNo=حسب رقم الإيصال
txtByDate=حسب تاريخ 
txtByCust=حسب كود العميل
txtShowTrucks=عرض الشاحنات
txtCountsTrips=عدد الدروب
reportType=نوع التقرير
custContract=العقد

titNotificationForm=الإشعارات

txtAddAmtDescr=اضافة
txtDiscAmtDescr=خصم


msgPrintOptions1=اختر تنسيقًا لطباعة الفاتورة

repTBTrans=ملخص المعاملات
repTBBal=الأرصدة فقط

transactionTxt=المعاملات
bfBal=الرصيد الافتتاحي

tbName1=ميزان المراجعة

txtSummary=ملخص حسب السائقين
txtDriverWithTruckSite=تفاصيل الشاحنة والموقع
txtSummarySite=ملخص مع المواقع

txtSalesPerson=مبيعات مندوب
txtOrdNo=طلب رقم


paraInclUnpostDlv=Include D.N.

txtShowAllBal=إظهار الكل
txtShowDebit=مدين فقط
txtShowCredit=دائن فقط

txtName=الاسم
txtName=الاسم 2


menuLogOff=تسجيل الخروج
menuAutoHide=إخفاء القوائم تلقائيًا
menuExpandAll=توسيع الكل
menuCollapseAll=طي الكل
menuChangePassword=تعيين كلمة المرور
mainMenus=القوائم الرئيسية
repMonthlySupDescr=المشتريات الشهرية للموردين

repImo1Descr=تقرير مبيعات أصناف الشهرية

titSalesManAna=مندوب مبيعات، المبيعات والتحصيل
txtSellAmt=قيمة المبيعات
txtCollAmt=التحصيلات
txtAvgSalesM3=متوسط ​​المبيعات/م3

txtSalm3Qty=كمية المبيعات م3
msgDeniedInputDlg=يجب أن تكون القيمة صالحة!
txtNewCtg=مجموعة جديدة

txtOverCrditDue=تجاوز الحد

txtInclInvoiceNo=تضمين الفاتورة

txtUserRepNo=كشف رقم

puShiptripno=رقم الرحلة
puShiparrivaldateport=وصول الباخرة
puShipType=نوع الشحنة
puShipName=اسم الباخرة
puShipdischargestartdate=تاريخ بدأالتفريغ
puShipdischargeenddate=تاريخ انتهاء التفريغ
puShipsaildate=تاريخ الابحار
puShipshipload=حمولة الباخرة الفعلية
puShiptotalpaths=اجالى الدروب
puShipunloadstore=مخزن التفريغ
puShipfreshwater=المياه العذبة
puShipnofroads=مصاريف اخرى
puShipnofdischarge=دروب الاجازات الجمعة
puShipsignoff=دروب الاجازات السبت
puShipstartfrom=عدد ايام التفريغ
puShipendto=قيمة عدد ايام التفريغ
puShipcarco=الشركة الناقلة
puShipenterberth=دخول الباخرة
puShiptonport=حمولة الباخرة حسب الميناء
puShipsignoff=دروب الاجازات السبت
puShipsignin=تسجيل الدخول
puShipfromdlv=سندات تبدأ من
puShiptodlv=سندات تنتهى ب
puShipsignoff2=تسجيل خروج

puMsgSelectPO=اختر طلب الشراء....

txtPOLCaddCosting=Add Spending

txtDescren=الوصف EN
txtDescrar=الوصف ع
txtExpenseAc=حساب المصروفات

txtInventoryAc=حساب المخزون


txtRecvdP=تم الاستلام %
landingCostShort=تكلفة الوصول
txtVariance=التفاوت
goodsRecieved=البضائع المستلمة


txtGrAc=استلام البضاعة

titPoClose=معالج إغلاق طلب الشراء

txtAttn=إلى عناية

txtEmp=الموظف

dlvDate=التسليم

itemRcvdQty=الكمية المستلمة

txtOpNo=المشغل

txtDlvPlantLeave=وقت الخروج
txtDlvPlantArrive=الوصول للموقع
txtDlvStartBatch=بدء الخلط
txtDlvTimeSite=مغادرة الموقع
txtDlvTimeSiteArrive=وقت الوصول

txtCounts=عدد

newRecord=New Record

txtCustUnderLegal=تحت القانونية
txtCustStopped=عملاء متوقفون
txtCustActive=عملاء متحركون
txtAll=كل

titDailyProduction=الإنتاج اليومي
titMonthlyProduction=الانتاج الشهري

txtTarget=مستهدف
txtYesterday=أمس
txtLastMonth=الشهر الماضي

wzdSepDate=عرض التسليمات اليومية

txtAddInvoice=رسوم خاصة

flagAskLock=توقف ؟
isCust=هو العميل
isSupp=هوالمورد
txtType=النوع
crdLimitRestrict=تقييد الائتمان
sellingType=نوع البيع
currentStatus=الوضع الحالي
custAgeDueDays=أيام حد الائتمان

showOverDue=إظهار الرصيد المتأخر
overDue=الرصيد المتأخر


addShipment=أضف رحلات
closePO=إغلاق PO
addGr=إضافة استلام البضائع

txtNone=تحت الموافقة
titSalesOrder=طلب المبيعات
issueDeliver=سند تسليم بضاعة
itemDlvQty=الكمية المسلمة
txtStrBalance=رصيد المخزن
txtIssueAction=إصدار العمل
closeSO=إقفال طلب
saleInvs=فاتورة المبيعات

msgCloseSO=هل تريد إغلاق هذا الطلب؟

sdlvNoteSO=إيصال التسليم SO
slsOrdN=SO No

txtLsPriceShort=Lowest Price
txtLsAmtShort=Lowest Selling
txtTotLS=Total Lowest
txtTotCost=Total Cost
txtRsrvStock=Reserved stock

txtReferSymbol=#

purInvs=فاتورة المشتريات
issueRV=سند استلام بضاعة

txtStatus=الحالة

ttMsgNewPurNoOnSO=إنشاء فاتورة مبيعات جديدة رقم / رقم التسليم
ttMsgNewPurNoOnPO=إنشاء رقم جديد لإغلاق عملية الشراء / استلام البضائع

txtAttachment=مرفقات
txtSelected=مختارة

txtOrdNo=رقم الطلب

soCmdAddSales=إضافة عملية بيع
soCmdShowSales=عرض عمليات البيع

showDlvToInv=عرض التسليم

txtDeliver=تسليم  
txtSold=مباع

txtTitSalesBrowser=تصفح الفواتير المبيعات
titSalesReturnRequest=طلب مردودات المبيعات
soCmdShowSR=عرض مرتجع 
soCmdAddSR=إضافة مرتجع مبيعات
closeSR=إغلاق SR
msgCloseSR=هل تريد إغلاق طلب مرتجع المبيعات؟
txtReturned=تم الإرجاع
txtReceived=مستلم

itemInfoColSet=تخصيص الأعمدة

titStrTranserVoucher=Store Transfer Voucher
txtStoreOut=Store Out
txtStoreIn=Store In
menuCopyItemDetailsFrom=نسخ تفاصيل الصنف من...

txtPurAccs=حسابات المشتريات  
txtStore=المخزن  
txtSalesAccs=حسابات المبيعات  
txtSales=المبيعات  
txtSalesRet=مرتجعات المبيعات  
txtSalesDisc=خصم المبيعات  
txtSalesAdd=إضافة المبيعات 

titStrIssueVoucher=سند صرف البضاعة

txtIssueType=Issue Type

titStrReceiptVoucher=سند استلام البضاعة

chkShowCost=عرض التكلفة

txtAvgCost1=متوسط التكلفة
txtCostPrice=سعر التكلفة

txtPoSO=PO / SO
txtDlvNo=رقم التسليم
txtQty=الكمية

joCmdReserveStock=المخزون الاحتياطي
joCmdShowStock=عرض المخزون
joCmdUpdDesign=تحديث التصميم
joCmdUpdateDye=تحديث الصبغة
joCmdShowDye=عرض الصبغة
joCmdProdSteps=خطوات الإنتاج
joCmdShowProdSteps=عرض الإنتاج
joCmdAddSales=إضافة المبيعات والتسليم
joCmdShowSales=عرض المبيعات والتسليم
joCmdShowDlv=عرض التسليمات  
joCmdAddDlv=إضافة التسليمات
closeJO=إغلاق JO
showCloseJo=Show Closing

dueDate=تاريخ استحقاق
txtJoActiveDays=يوم التشغيل
txtJoActiveFrom=نشط من

db2JONotApproved=أوامر العمل قيد الموافقة (1)
db2JONotActive=أوامر العمل غير نشطة (2)
db2JOActive=أوامر العمل النشطة (2)
db2JOProdDone=أوامر العمل بعد الإنتاج لم تكتمل المبيعات (0)
db2JOSoldComplete=مبيعات أوامر العمل المكتملة
db2JOClose=أوامر العمل المغلقة