/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package com.generic;

/**
 *
 * @author yusuf
 */
public interface rowTriggerListner {
    public void onCalc(int cursorNo);
}
