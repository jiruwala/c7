package com.tools.queries;

public class SimpleQuery {

}
